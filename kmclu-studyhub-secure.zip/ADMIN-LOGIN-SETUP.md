# KMCLU StudyHub secure login setup

## 1. Configure the private admin
1. Copy `.env.example` to `.env` in the project root.
2. Set `ADMIN_EMAIL` and a unique `ADMIN_PASSWORD` of at least 12 characters. Do not share or commit `.env`.
3. Start the app with `npm.cmd run dev`. The first admin account is created on first server start. Admin signup is not available on the public registration form.

## 2. Login
- Open `http://localhost:3000`.
- Use the credentials configured in `.env` to sign in as admin.
- Students use **Student Sign Up** to create student accounts.
- Admin user list and successful login activity are only served by endpoints that verify the server-side session and admin role.

## 3. Important deployment notes
- This patch uses a local JSON file (`data/auth-store.json`) and in-memory sessions. It is intended for local development/single-instance testing, not multi-instance/serverless production. Use a managed database and persistent session store before public deployment.
- Set `NODE_ENV=production` only behind HTTPS, because the session cookie then requires Secure.
- Login activity stores IP addresses. Publish a privacy notice and set a retention policy before using with real students.
- Existing academic document data and moderation actions in the current project are still primarily frontend state. Before public launch, move document records and approve/reject/delete actions into persistent storage with server-side admin middleware too.

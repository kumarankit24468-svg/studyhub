import test from 'node:test';
import assert from 'node:assert/strict';
import {
  filterDocuments,
  detectPotentialDuplicates,
  processDocumentApproval,
  calculateAcademicStats,
  calculateQuizScore,
} from './studyhub-logic.ts';
import type { DocumentItem, QuizQuestion } from './studyhub-logic.ts';

const mockDocs: DocumentItem[] = [
  {
    id: 'doc-1',
    title: 'Operating Systems End-Sem PYQ 2024',
    facultyId: 'FET',
    facultyName: 'Engineering & Technology',
    department: 'Computer Science',
    course: 'B.Tech',
    branch: 'CSE',
    semester: 5,
    subject: 'Operating Systems',
    subjectCode: 'BCS-501',
    documentType: 'PYQ',
    examYear: 2024,
    uploadedBy: { id: 'u1', name: 'Aman Khan', faculty: 'FET', course: 'B.Tech' },
    status: 'approved',
    createdAt: '2025-01-10T10:00:00.000Z',
    downloads: 142,
    views: 310,
    tags: ['deadlock', 'paging', 'scheduling'],
  },
  {
    id: 'doc-2',
    title: 'Financial Management MBA Mid-Sem 2024',
    facultyId: 'COMMERCE',
    facultyName: 'Commerce & Management',
    department: 'Business Administration',
    course: 'MBA',
    branch: 'Finance',
    semester: 2,
    subject: 'Financial Management',
    subjectCode: 'MBA-101',
    documentType: 'Mid-Sem',
    examYear: 2024,
    uploadedBy: { id: 'u2', name: 'Areeba Siddiqui', faculty: 'Commerce & Management', course: 'MBA' },
    status: 'approved',
    createdAt: '2025-02-12T10:00:00.000Z',
    downloads: 95,
    views: 180,
    tags: ['capital budgeting', 'npv', 'irr'],
  },
  {
    id: 'doc-3',
    title: 'Constitutional Law Handwritten Notes',
    facultyId: 'LAW',
    facultyName: 'Faculty of Law',
    department: 'Constitutional Law',
    course: 'LL.B',
    branch: 'Law',
    semester: 3,
    subject: 'Constitutional Law',
    subjectCode: 'LAW-101',
    documentType: 'Notes',
    examYear: 2024,
    uploadedBy: { id: 'u3', name: 'Rahul Mishra', faculty: 'Faculty of Law', course: 'LL.B' },
    status: 'pending',
    createdAt: '2025-03-01T10:00:00.000Z',
    downloads: 0,
    views: 4,
    tags: ['article 21', 'basic structure', 'writs'],
  },
];

test('filterDocuments filters by branch, faculty, and approvedOnly', () => {
  const result = filterDocuments(mockDocs, {
    branch: 'CSE',
    facultyId: 'FET',
    onlyApproved: true,
  });
  assert.equal(result.length, 1);
  assert.equal(result[0].id, 'doc-1');
});

test('filterDocuments filters by course (e.g. MBA in Commerce faculty)', () => {
  const result = filterDocuments(mockDocs, {
    course: 'MBA',
    facultyId: 'COMMERCE',
  });
  assert.equal(result.length, 1);
  assert.equal(result[0].id, 'doc-2');
});

test('filterDocuments search query finds matching tags across faculties', () => {
  const result = filterDocuments(mockDocs, {
    searchQuery: 'capital budgeting',
  });
  assert.equal(result.length, 1);
  assert.equal(result[0].id, 'doc-2');
});

test('detectPotentialDuplicates flags duplicate PYQ submissions with same subject, year and sem', () => {
  const candidate: Partial<DocumentItem> = {
    subject: 'Operating Systems',
    documentType: 'PYQ',
    examYear: 2024,
    semester: 5,
    branch: 'CSE',
  };
  const check = detectPotentialDuplicates(candidate, mockDocs);
  assert.equal(check.isDuplicateCandidate, true);
  assert.equal(check.duplicates.length, 1);
  assert.equal(check.duplicates[0].id, 'doc-1');
});

test('detectPotentialDuplicates allows new subjects or different years', () => {
  const candidate: Partial<DocumentItem> = {
    subject: 'Operating Systems',
    documentType: 'PYQ',
    examYear: 2022, // Different year
    semester: 5,
    branch: 'CSE',
  };
  const check = detectPotentialDuplicates(candidate, mockDocs);
  assert.equal(check.isDuplicateCandidate, false);
});

test('processDocumentApproval correctly approves document, generates audit log & notification', () => {
  const doc = mockDocs[2]; // pending doc
  const admin = { id: 'admin-1', name: 'Prof. Alok Verma' };
  const { updatedDocument, notification, auditLog } = processDocumentApproval(
    doc,
    admin,
    'approve'
  );

  assert.equal(updatedDocument.status, 'approved');
  assert.equal(updatedDocument.reviewedBy, 'Prof. Alok Verma');
  assert.equal(notification.type, 'success');
  assert.equal(notification.userId, doc.uploadedBy.id);
  assert.equal(auditLog.action, 'APPROVED_DOCUMENT');
});

test('processDocumentApproval correctly rejects document with specific reason', () => {
  const doc = mockDocs[2];
  const admin = { id: 'admin-1', name: 'Prof. Alok Verma' };
  const reason = 'Document scan is blurry and pages 3-5 are missing.';
  const { updatedDocument, notification, auditLog } = processDocumentApproval(
    doc,
    admin,
    'reject',
    reason
  );

  assert.equal(updatedDocument.status, 'rejected');
  assert.equal(updatedDocument.reviewReason, reason);
  assert.equal(notification.type, 'danger');
  assert.match(notification.message, /blurry/i);
  assert.equal(auditLog.action, 'REJECTED_DOCUMENT');
});

test('calculateAcademicStats computes correct totals, downloads, and branch counts', () => {
  const stats = calculateAcademicStats(mockDocs);
  assert.equal(stats.total, 3);
  assert.equal(stats.approved, 2);
  assert.equal(stats.pending, 1);
  assert.equal(stats.totalDownloads, 237);
  assert.equal(stats.branchCounts['CSE'], 1);
  assert.equal(stats.branchCounts['Finance'], 1);
  assert.equal(stats.facultyCounts['FET'], 1);
  assert.equal(stats.facultyCounts['COMMERCE'], 1);
});

test('calculateQuizScore computes correct percentages and KMCLU grade classifications', () => {
  const questions: QuizQuestion[] = [
    {
      id: 'q1',
      subject: 'OS',
      question: 'What is a deadlock condition?',
      options: ['Mutual Exclusion', 'Hold & Wait', 'No Preemption', 'All of the above'],
      correctOptionIndex: 3,
      explanation: 'All 4 Coffman conditions must hold for deadlock.',
      difficulty: 'easy',
      topic: 'Deadlocks',
    },
    {
      id: 'q2',
      subject: 'OS',
      question: 'Which page replacement algorithm suffers from Belady anomaly?',
      options: ['LRU', 'FIFO', 'Optimal', 'Clock'],
      correctOptionIndex: 1,
      explanation: 'FIFO suffers from Belady anomaly.',
      difficulty: 'medium',
      topic: 'Virtual Memory',
    },
  ];

  const fullScore = calculateQuizScore(questions, { q1: 3, q2: 1 });
  assert.equal(fullScore.correct, 2);
  assert.equal(fullScore.percentage, 100);
  assert.match(fullScore.grade, /A\+/);

  const halfScore = calculateQuizScore(questions, { q1: 3, q2: 0 });
  assert.equal(halfScore.correct, 1);
  assert.equal(halfScore.wrong, 1);
  assert.equal(halfScore.percentage, 50);
});

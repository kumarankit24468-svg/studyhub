/**
 * KMCLU StudyHub - Pure Core Logic Module
 * Decoupled, fully unit-testable business logic for search, moderation, stats, and quiz.
 */

export interface DocumentItem {
  id: string;
  title: string;
  facultyId: string; // 'FET' | 'COMMERCE' | 'SCIENCE' | 'LAW' | 'HUMANITIES' | 'JOURNALISM' | 'PHARMACY' | 'EDUCATION' | 'ALL'
  facultyName: string;
  department: string;
  course: string; // 'B.Tech' | 'BCA' | 'MCA' | 'BBA' | 'MBA' | 'B.Com' | 'B.Sc' | 'M.Sc' | 'BA' | 'MA' | 'LL.B' | 'BA-LL.B' | 'BA-JMC' | 'B.Pharm' | 'B.Ed' | 'ALL'
  branch: string; // Specialization / Branch (e.g., 'CSE', 'Marketing', 'Corporate Law', 'Physics', 'General')
  semester: number; // 1 - 10
  subject: string;
  subjectCode: string;
  documentType: 'PYQ' | 'Mid-Sem' | 'Notes' | 'Syllabus';
  examYear: number;
  uploadedBy: {
    id: string;
    name: string;
    rollNo?: string;
    avatar?: string;
    faculty?: string;
    course?: string;
  };
  fileKey?: string;
  fileUrl?: string;
  fileSize?: string;
  pageCount?: number;
  status: 'pending' | 'approved' | 'rejected';
  reviewedBy?: string;
  reviewReason?: string;
  reviewedAt?: string;
  createdAt: string;
  downloads: number;
  views: number;
  rating?: number;
  tags: string[];
  contentSummary?: string;
  sampleQuestions?: string[];
  isFeatured?: boolean;
}

export interface DocumentFilterCriteria {
  facultyId?: string;
  department?: string;
  course?: string;
  branch?: string;
  semester?: number | 'all';
  documentType?: 'all' | 'PYQ' | 'Mid-Sem' | 'Notes' | 'Syllabus';
  examYear?: number | 'all';
  searchQuery?: string;
  status?: 'all' | 'pending' | 'approved' | 'rejected';
  onlyApproved?: boolean;
}

export interface QuizQuestion {
  id: string;
  subject: string;
  question: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
  topic: string;
}

/**
 * Filter documents according to multi-dimensional criteria
 */
export function filterDocuments(
  documents: DocumentItem[],
  criteria: DocumentFilterCriteria
): DocumentItem[] {
  return documents.filter((doc) => {
    // Status check
    if (criteria.onlyApproved && doc.status !== 'approved') {
      return false;
    }
    if (criteria.status && criteria.status.toLowerCase() !== 'all' && doc.status !== criteria.status) {
      return false;
    }

    // Faculty filter
    if (criteria.facultyId && criteria.facultyId.toLowerCase() !== 'all' && doc.facultyId !== 'ALL' && doc.facultyId !== criteria.facultyId) {
      return false;
    }

    // Course filter (e.g. B.Tech, MBA, LL.B, B.Sc)
    if (criteria.course && criteria.course.toLowerCase() !== 'all' && doc.course !== 'ALL' && doc.course !== criteria.course) {
      return false;
    }

    // Department filter
    if (criteria.department && criteria.department.toLowerCase() !== 'all' && doc.department !== 'ALL' && doc.department !== criteria.department) {
      return false;
    }

    // Branch / Specialization filter
    if (criteria.branch && criteria.branch.toLowerCase() !== 'all' && doc.branch !== 'ALL' && doc.branch !== criteria.branch) {
      return false;
    }

    // Semester filter
    if (criteria.semester && criteria.semester !== 'all' && doc.semester !== criteria.semester) {
      return false;
    }

    // Document type filter
    if (criteria.documentType && criteria.documentType.toLowerCase() !== 'all' && doc.documentType !== criteria.documentType) {
      return false;
    }

    // Exam year filter
    if (criteria.examYear && criteria.examYear !== 'all' && doc.examYear !== criteria.examYear) {
      return false;
    }

    // Search query matching against title, subject, code, tags, and summary
    if (criteria.searchQuery && criteria.searchQuery.trim() !== '') {
      const q = criteria.searchQuery.toLowerCase().trim();
      const matchTitle = doc.title.toLowerCase().includes(q);
      const matchSubject = doc.subject.toLowerCase().includes(q);
      const matchCode = doc.subjectCode.toLowerCase().includes(q);
      const matchTags = doc.tags.some((t) => t.toLowerCase().includes(q));
      const matchSummary = (doc.contentSummary || '').toLowerCase().includes(q);

      if (!matchTitle && !matchSubject && !matchCode && !matchTags && !matchSummary) {
        return false;
      }
    }

    return true;
  });
}

/**
 * Detect potential duplicate submissions based on subject, year, type, and branch
 */
export function detectPotentialDuplicates(
  candidate: Partial<DocumentItem>,
  existingDocs: DocumentItem[]
): { isDuplicateCandidate: boolean; duplicates: DocumentItem[]; reason?: string } {
  if (!candidate.subject || !candidate.documentType) {
    return { isDuplicateCandidate: false, duplicates: [] };
  }

  const candSubjectNorm = candidate.subject.toLowerCase().replace(/[^a-z0-9]/g, '');
  const candYear = candidate.examYear;
  const candType = candidate.documentType;
  const candSem = candidate.semester;

  const matches = existingDocs.filter((existing) => {
    if (existing.id === candidate.id) return false;

    const existSubjectNorm = existing.subject.toLowerCase().replace(/[^a-z0-9]/g, '');
    const subjectMatches =
      existSubjectNorm === candSubjectNorm ||
      existSubjectNorm.includes(candSubjectNorm) ||
      candSubjectNorm.includes(existSubjectNorm);

    // Exact duplicate for PYQ or Mid-Sem: same subject, same year, same semester, same documentType
    if (
      (candType === 'PYQ' || candType === 'Mid-Sem') &&
      candType === existing.documentType &&
      candYear === existing.examYear &&
      candSem === existing.semester &&
      subjectMatches
    ) {
      return true;
    }

    // Close title match
    if (candidate.title && existing.title) {
      const t1 = candidate.title.toLowerCase().replace(/[^a-z0-9]/g, '');
      const t2 = existing.title.toLowerCase().replace(/[^a-z0-9]/g, '');
      if (t1.length > 5 && (t1 === t2 || (t1.includes(t2) && t2.length > 8))) {
        return true;
      }
    }

    return false;
  });

  return {
    isDuplicateCandidate: matches.length > 0,
    duplicates: matches,
    reason:
      matches.length > 0
        ? `A ${matches[0].documentType} paper for ${matches[0].subject} (${matches[0].examYear}) already exists in the library.`
        : undefined,
  };
}

/**
 * State transition for reviewing a document by Admin
 */
export function processDocumentApproval(
  document: DocumentItem,
  adminUser: { id: string; name: string },
  decision: 'approve' | 'reject',
  rejectionReason?: string
): {
  updatedDocument: DocumentItem;
  notification: {
    id: string;
    userId: string;
    title: string;
    message: string;
    type: 'success' | 'danger' | 'info';
    documentId: string;
    createdAt: string;
  };
  auditLog: {
    id: string;
    adminName: string;
    adminId: string;
    action: string;
    documentTitle: string;
    timestamp: string;
    details: string;
  };
} {
  const timestamp = new Date().toISOString();
  const isApproved = decision === 'approve';

  const updatedDocument: DocumentItem = {
    ...document,
    status: isApproved ? 'approved' : 'rejected',
    reviewedBy: adminUser.name,
    reviewReason: isApproved ? undefined : (rejectionReason || 'Uploaded document does not meet university repository standards.'),
    reviewedAt: timestamp,
  };

  const notification = {
    id: 'notif_' + Math.random().toString(36).substring(2, 9),
    userId: document.uploadedBy.id,
    title: isApproved ? 'Document Approved! 🎉' : 'Document Submission Rejected',
    message: isApproved
      ? `Your submission "${document.title}" has been verified and published to the KMCLU StudyHub library.`
      : `Your submission "${document.title}" was not approved. Reason: ${rejectionReason || 'Incomplete metadata or illegible document.'}`,
    type: isApproved ? ('success' as const) : ('danger' as const),
    documentId: document.id,
    createdAt: timestamp,
  };

  const auditLog = {
    id: 'audit_' + Math.random().toString(36).substring(2, 9),
    adminName: adminUser.name,
    adminId: adminUser.id,
    action: isApproved ? 'APPROVED_DOCUMENT' : 'REJECTED_DOCUMENT',
    documentTitle: document.title,
    timestamp,
    details: isApproved
      ? `Published to public repository under ${document.branch} Sem ${document.semester} (${document.subject}).`
      : `Rejected submission. Stated reason: ${rejectionReason || 'No specific reason provided.'}`,
  };

  return { updatedDocument, notification, auditLog };
}

/**
 * Calculate high-level platform statistics
 */
export function calculateAcademicStats(documents: DocumentItem[]) {
  const total = documents.length;
  const approved = documents.filter((d) => d.status === 'approved').length;
  const pending = documents.filter((d) => d.status === 'pending').length;
  const rejected = documents.filter((d) => d.status === 'rejected').length;

  const totalDownloads = documents.reduce((acc, curr) => acc + (curr.downloads || 0), 0);
  const totalViews = documents.reduce((acc, curr) => acc + (curr.views || 0), 0);

  // Group by branch & faculty
  const branchCounts: Record<string, number> = {};
  const facultyCounts: Record<string, number> = {};
  const courseCounts: Record<string, number> = {};

  // Group by document type
  const typeCounts: Record<string, number> = {
    PYQ: 0,
    'Mid-Sem': 0,
    Notes: 0,
    Syllabus: 0,
  };

  documents.forEach((d) => {
    if (d.status === 'approved') {
      branchCounts[d.branch] = (branchCounts[d.branch] || 0) + 1;
      facultyCounts[d.facultyId] = (facultyCounts[d.facultyId] || 0) + 1;
      courseCounts[d.course] = (courseCounts[d.course] || 0) + 1;
      if (typeCounts[d.documentType] !== undefined) {
        typeCounts[d.documentType]++;
      }
    }
  });

  return {
    total,
    approved,
    pending,
    rejected,
    totalDownloads,
    totalViews,
    branchCounts,
    facultyCounts,
    courseCounts,
    typeCounts,
  };
}

/**
 * Calculate Quiz score and KMCLU grading analysis
 */
export function calculateQuizScore(
  questions: QuizQuestion[],
  answers: Record<string, number>
) {
  let correct = 0;
  let wrong = 0;
  let unattempted = 0;

  questions.forEach((q) => {
    const selected = answers[q.id];
    if (selected === undefined || selected === -1) {
      unattempted++;
    } else if (selected === q.correctOptionIndex) {
      correct++;
    } else {
      wrong++;
    }
  });

  const total = questions.length;
  const percentage = total > 0 ? Math.round((correct / total) * 100) : 0;

  let grade = 'F';
  let remark = 'Needs Revision';

  if (percentage >= 85) {
    grade = 'A+ (Exemplary)';
    remark = 'Excellent mastery of B.Tech curriculum standards.';
  } else if (percentage >= 70) {
    grade = 'A (Good)';
    remark = 'Solid conceptual grasp. Review mistaken questions.';
  } else if (percentage >= 50) {
    grade = 'B (Satisfactory)';
    remark = 'Average preparation. Practice more PYQ papers.';
  } else {
    grade = 'C / Needs Work';
    remark = 'Focus on high-weightage topics and lecture notes.';
  }

  return {
    total,
    correct,
    wrong,
    unattempted,
    percentage,
    grade,
    remark,
  };
}

import React, { useState, useEffect } from 'react';
import {
  Navbar,
} from './components/Navbar';
import { HeroBanner } from './components/HeroBanner';
import { BranchExplorer } from './components/BranchExplorer';
import { DocumentCard } from './components/DocumentCard';
import { PDFViewerModal } from './components/PDFViewerModal';
import { UploadModal } from './components/UploadModal';
import { AdminPanel } from './components/AdminPanel';
import { AIAssistantModal } from './components/AIAssistantModal';
import { PYQPracticeMode } from './components/PYQPracticeMode';
import { ExamPlanner } from './components/ExamPlanner';
import { StudentDashboard } from './components/StudentDashboard';
import { QuickSearchModal } from './components/QuickSearchModal';
import { ReportModal } from './components/ReportModal';
import { AuthGate } from './components/AuthGate';
import { AdminSecurityPanel } from './components/AdminSecurityPanel';

import {
  DEMO_USERS,
  INITIAL_DOCUMENTS,
  BRANCHES,
  UserProfile,
} from './data/mockData';
import {
  DocumentItem,
  filterDocuments,
  processDocumentApproval,
} from './utils/studyhub-logic';
import {
  Filter,
  GraduationCap,
  Sparkles,
  BookOpen,
  FileText,
  Layers,
  CheckCircle,
  HelpCircle,
  ShieldCheck,
  AlertCircle,
  Upload,
} from 'lucide-react';

type AuthenticatedUser = UserProfile & { createdAt?: string; lastLoginAt?: string };

export default function App() {
  return <AuthGate>{(authenticatedUser, logout) => <StudyHubApp authenticatedUser={authenticatedUser} onLogout={logout} />}</AuthGate>;
}

function StudyHubApp({ authenticatedUser, onLogout }: { authenticatedUser: AuthenticatedUser; onLogout: () => Promise<void> }) {
  // The user identity and role come from the server-verified HttpOnly session, not a client-side switcher.
  const [users, setUsers] = useState<UserProfile[]>([authenticatedUser]);
  const [currentUser] = useState<UserProfile>(authenticatedUser);

  useEffect(() => {
    if (authenticatedUser.role !== 'admin') return;
    let cancelled = false;
    fetch('/api/admin/users', { credentials: 'same-origin' }).then(async response => {
      if (!response.ok) return null;
      return response.json();
    }).then(data => {
      if (!cancelled && data?.users) setUsers(data.users as UserProfile[]);
    }).catch(() => {});
    return () => { cancelled = true; };
  }, [authenticatedUser.id, authenticatedUser.role]);

  // Document Library State
  const [documents, setDocuments] = useState<DocumentItem[]>(INITIAL_DOCUMENTS);
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(['doc-kmclu-001', 'doc-kmclu-003']);

  // Navigation and Filter States
  const [activeTab, setActiveTab] = useState<string>('explore');
  const [selectedFaculty, setSelectedFaculty] = useState<string>('ALL');
  const [selectedCourse, setSelectedCourse] = useState<string>('ALL');
  const [selectedBranch, setSelectedBranch] = useState<string>('ALL');
  const [selectedSemester, setSelectedSemester] = useState<number | 'all'>('all');
  const [selectedType, setSelectedType] = useState<'all' | 'PYQ' | 'Mid-Sem' | 'Notes' | 'Syllabus'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Notifications
  const [notifications, setNotifications] = useState<
    Array<{
      id: string;
      title: string;
      message: string;
      type: 'success' | 'danger' | 'info';
      createdAt: string;
      read?: boolean;
    }>
  >([
    {
      id: 'notif-1',
      title: 'Welcome to KMCLU StudyHub! 🎓',
      message: 'Explore verified question papers, mid-sem exam papers, notes and syllabus across all 8 KMCLU faculties and departments.',
      type: 'info',
      createdAt: new Date().toISOString(),
      read: false,
    },
  ]);

  // Reports
  const [reports, setReports] = useState<
    Array<{
      id: string;
      documentId: string;
      documentTitle: string;
      reportedBy: string;
      reason: string;
      createdAt: string;
      status: 'open' | 'resolved';
    }>
  >([]);

  // Audit Logs
  const [auditLogs, setAuditLogs] = useState<
    Array<{
      id: string;
      adminName: string;
      adminId: string;
      action: string;
      documentTitle: string;
      timestamp: string;
      details: string;
    }>
  >([
    {
      id: 'audit-init-1',
      adminName: 'Verified Academic Admin',
      adminId: 'user-admin',
      action: 'APPROVED_DOCUMENT',
      documentTitle: 'Operating Systems End-Semester Regular Paper 2024',
      timestamp: '2024-06-15T11:20:00Z',
      details: 'Verified syllabus alignment for BCS-401.',
    },
  ]);

  // Modals state
  const [viewerDoc, setViewerDoc] = useState<DocumentItem | null>(null);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [quickSearchOpen, setQuickSearchOpen] = useState(false);
  const [aiAssistantOpen, setAiAssistantOpen] = useState(false);
  const [aiContextDoc, setAiContextDoc] = useState<DocumentItem | null>(null);
  const [reportDoc, setReportDoc] = useState<DocumentItem | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Sync tab changes with filter shortcuts
  useEffect(() => {
    if (activeTab === 'pyqs') {
      setSelectedType('PYQ');
    } else if (activeTab === 'midsem') {
      setSelectedType('Mid-Sem');
    }
  }, [activeTab]);

  // Global Keyboard Shortcut: Cmd/Ctrl + K for search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setQuickSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const pendingCount = documents.filter((d) => d.status === 'pending').length;

  const showToast = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(null), 3500);
  };

  // Toggle Bookmark
  const handleToggleBookmark = (docId: string) => {
    setBookmarkedIds((prev) =>
      prev.includes(docId) ? prev.filter((id) => id !== docId) : [...prev, docId]
    );
  };

  // Download Handler (increments download count and triggers text/simulated PDF download)
  const handleDownload = (doc: DocumentItem) => {
    setDocuments((prev) =>
      prev.map((d) => (d.id === doc.id ? { ...d, downloads: (d.downloads || 0) + 1 } : d))
    );

    const docContent = `======================================================================
KHWAJA MOINUDDIN CHISHTI LANGUAGE UNIVERSITY, LUCKNOW
Faculty: ${doc.facultyName.toUpperCase()} • Department: ${doc.department}
Degree: ${doc.course} (${doc.branch}) Examination • Semester ${doc.semester}
----------------------------------------------------------------------
SUBJECT: ${doc.subject.toUpperCase()} [CODE: ${doc.subjectCode}]
DOCUMENT TYPE: ${doc.documentType} (Academic Year: ${doc.examYear})
REVIEWED & VERIFIED BY: ${doc.reviewedBy || 'KMCLU Examination Controller'}
======================================================================

NOTE:
1. Attempt all sections. If any data is missing, assume suitably.
2. Standard university evaluation guidelines apply.

SUMMARY OF TOPICS COVERED:
${doc.contentSummary || 'Full university syllabus covered.'}

SAMPLE EXAMINATION QUESTIONS:
${(doc.sampleQuestions || [])
  .map((q, idx) => `${idx + 1}. ${q}`)
  .join('\n\n')}

----------------------------------------------------------------------
Downloaded from KMCLU StudyHub - Official Academic Student Portal
======================================================================`;

    const blob = new Blob([docContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${doc.subjectCode}_${doc.documentType}_${doc.examYear}_KMCLU.txt`;
    link.click();
    URL.revokeObjectURL(url);
    showToast(`Downloaded "${doc.title}"!`);
  };

  // Student Upload Submission
  const handleUploadSubmit = (newDoc: DocumentItem) => {
    setDocuments((prev) => [newDoc, ...prev]);

    // Update uploader stats
    setUsers((prev) =>
      prev.map((u) =>
        u.id === currentUser.id ? { ...u, uploadsCount: u.uploadsCount + 1 } : u
      )
    );

    // Notify student
    const studentNotif = {
      id: 'notif_' + Date.now().toString(36),
      title: 'PDF Uploaded to Pending Queue ⏳',
      message: `Your document "${newDoc.title}" has been submitted for Admin Verification. You will be notified once reviewed.`,
      type: 'info' as const,
      createdAt: new Date().toISOString(),
      read: false,
    };
    setNotifications((prev) => [studentNotif, ...prev]);
    showToast('Document uploaded successfully! Awaiting Admin approval.');
  };

  // Admin Approval
  const handleAdminApprove = (doc: DocumentItem) => {
    const adminUser = { id: currentUser.id, name: currentUser.name };
    const { updatedDocument, notification, auditLog } = processDocumentApproval(
      doc,
      adminUser,
      'approve'
    );

    setDocuments((prev) => prev.map((d) => (d.id === doc.id ? updatedDocument : d)));
    setNotifications((prev) => [notification, ...prev]);
    setAuditLogs((prev) => [auditLog, ...prev]);

    // Reward student with reputation points
    setUsers((prev) =>
      prev.map((u) =>
        u.id === doc.uploadedBy.id
          ? {
              ...u,
              approvedCount: u.approvedCount + 1,
              reputationPoints: u.reputationPoints + 50,
            }
          : u
      )
    );

    showToast(`Approved & published: "${doc.title}"`);
  };

  // Admin Rejection
  const handleAdminReject = (doc: DocumentItem, reason: string) => {
    const adminUser = { id: currentUser.id, name: currentUser.name };
    const { updatedDocument, notification, auditLog } = processDocumentApproval(
      doc,
      adminUser,
      'reject',
      reason
    );

    setDocuments((prev) => prev.map((d) => (d.id === doc.id ? updatedDocument : d)));
    setNotifications((prev) => [notification, ...prev]);
    setAuditLogs((prev) => [auditLog, ...prev]);
    showToast(`Submission rejected. Feedback notified to student.`);
  };

  // Admin Delete Document
  const handleDeleteDocument = (docId: string) => {
    const docToDelete = documents.find((d) => d.id === docId);
    setDocuments((prev) => prev.filter((d) => d.id !== docId));
    if (docToDelete) {
      setAuditLogs((prev) => [
        {
          id: 'audit_del_' + Date.now().toString(36),
          adminName: currentUser.name,
          adminId: currentUser.id,
          action: 'DELETED_DOCUMENT',
          documentTitle: docToDelete.title,
          timestamp: new Date().toISOString(),
          details: `Document removed from repository by Admin.`,
        },
        ...prev,
      ]);
      showToast(`Removed "${docToDelete.title}" from library.`);
    }
  };

  // Admin User Suspension Toggle
  const handleToggleSuspendUser = (userId: string) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, isSuspended: !u.isSuspended } : u))
    );
    showToast('User account status updated.');
  };

  // Student Report Document
  const handleReportDocument = (docId: string, reason: string) => {
    const target = documents.find((d) => d.id === docId);
    if (!target) return;
    const newReport = {
      id: 'rep_' + Date.now().toString(36),
      documentId: docId,
      documentTitle: target.title,
      reportedBy: currentUser.name,
      reason,
      createdAt: new Date().toISOString(),
      status: 'open' as const,
    };
    setReports((prev) => [newReport, ...prev]);
    showToast('Report filed with academic administration.');
  };

  const handleDismissReport = (reportId: string) => {
    setReports((prev) => prev.filter((r) => r.id !== reportId));
    showToast('Report dismissed.');
  };

  // Open AI with context
  const handleOpenAIWithDoc = (doc?: DocumentItem) => {
    setAiContextDoc(doc || null);
    setAiAssistantOpen(true);
  };

  // Filtered Approved Documents for the Public Library
  const displayedDocuments = filterDocuments(documents, {
    facultyId: selectedFaculty !== 'ALL' ? selectedFaculty : undefined,
    course: selectedCourse !== 'ALL' ? selectedCourse : undefined,
    branch: selectedBranch !== 'ALL' ? selectedBranch : undefined,
    semester: selectedSemester,
    documentType: selectedType,
    searchQuery,
    onlyApproved: true, // IMPORTANT: Unapproved / Pending PDFs are never visible in public library!
  });

  const totalApproved = documents.filter((d) => d.status === 'approved').length;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900 selection:bg-blue-600 selection:text-white">
      {/* Toast Notification */}
      {successToast && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl text-xs font-semibold flex items-center space-x-2 border border-slate-700 animate-in fade-in slide-in-from-bottom-2">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{successToast}</span>
        </div>
      )}

      {/* Top Navigation */}
      <Navbar
        currentUser={currentUser}
        onLogout={onLogout}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenUpload={() => setUploadModalOpen(true)}
        onOpenSearch={() => setQuickSearchOpen(true)}
        pendingCount={pendingCount}
        notifications={notifications}
        onClearNotifications={() => setNotifications([])}
        bookmarkedCount={bookmarkedIds.length}
        onOpenBookmarks={() => setActiveTab('dashboard')}
        onOpenAI={() => handleOpenAIWithDoc()}
      />

      {/* MAIN VIEW CONTROLLER */}
      <main className="flex-1">
        {/* VIEW 1: EXPLORE / LIBRARY (Default Home) */}
        {(activeTab === 'explore' || activeTab === 'pyqs' || activeTab === 'midsem') && (
          <div className="space-y-8 pb-16">
            {/* Hero Section */}
            <HeroBanner
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              selectedFaculty={selectedFaculty}
              setSelectedFaculty={setSelectedFaculty}
              selectedCourse={selectedCourse}
              setSelectedCourse={setSelectedCourse}
              selectedBranch={selectedBranch}
              setSelectedBranch={setSelectedBranch}
              selectedSemester={selectedSemester}
              setSelectedSemester={setSelectedSemester}
              selectedType={selectedType}
              setSelectedType={setSelectedType}
              onOpenUpload={() => setUploadModalOpen(true)}
              totalApproved={totalApproved}
            />

            {/* Max-Width Content Container */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
              {/* University Faculty & Department Explorer */}
              <BranchExplorer
                selectedFaculty={selectedFaculty}
                onSelectFaculty={setSelectedFaculty}
                selectedBranch={selectedBranch}
                onSelectBranch={setSelectedBranch}
                selectedCourse={selectedCourse}
                onSelectCourse={setSelectedCourse}
              />

              {/* Semester & Filters Strip */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-4">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-xs font-bold text-slate-500 mr-2 flex items-center gap-1">
                    <Filter className="w-3.5 h-3.5" />
                    Semester:
                  </span>
                  <button
                    onClick={() => setSelectedSemester('all')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                      selectedSemester === 'all'
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    All Semesters
                  </button>
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((sem) => (
                    <button
                      key={sem}
                      onClick={() => setSelectedSemester(sem)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors ${
                        selectedSemester === sem
                          ? 'bg-blue-600 text-white font-bold'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      Sem {sem}
                    </button>
                  ))}
                </div>

                <div className="text-xs text-slate-500 font-medium">
                  Showing <strong className="text-slate-900">{displayedDocuments.length}</strong> verified academic documents
                </div>
              </div>

              {/* Document Cards Grid */}
              {displayedDocuments.length === 0 ? (
                <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
                  <BookOpen className="w-12 h-12 text-slate-300 mx-auto" />
                  <h3 className="text-base font-bold text-slate-800">No documents found matching current filters</h3>
                  <p className="text-xs text-slate-500 max-w-md mx-auto">
                    Try selecting "All Faculties", clear your search keywords, or be the first student to upload a PDF for this subject!
                  </p>
                  <button
                    onClick={() => {
                      setSelectedFaculty('ALL');
                      setSelectedCourse('ALL');
                      setSelectedBranch('ALL');
                      setSelectedSemester('all');
                      setSelectedType('all');
                      setSearchQuery('');
                    }}
                    className="px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700"
                  >
                    Reset All Filters
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                  {displayedDocuments.map((doc) => (
                    <DocumentCard
                      key={doc.id}
                      document={doc}
                      isBookmarked={bookmarkedIds.includes(doc.id)}
                      onToggleBookmark={handleToggleBookmark}
                      onPreview={(d) => {
                        // Increment view count
                        setDocuments((prev) =>
                          prev.map((item) => (item.id === d.id ? { ...item, views: item.views + 1 } : item))
                        );
                        setViewerDoc(d);
                      }}
                      onDownload={handleDownload}
                      onAskAI={(d) => handleOpenAIWithDoc(d)}
                      onReport={(d) => setReportDoc(d)}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* VIEW 2: PYQ PRACTICE QUIZ MODE */}
        {activeTab === 'practice' && <PYQPracticeMode />}

        {/* VIEW 3: EXAM PLANNER & TIMETABLE */}
        {activeTab === 'planner' && <ExamPlanner />}

        {/* VIEW 4: STUDENT DASHBOARD (My Uploads & Bookmarks) */}
        {activeTab === 'dashboard' && (
          <StudentDashboard
            currentUser={currentUser}
            documents={documents}
            bookmarkedIds={bookmarkedIds}
            onToggleBookmark={handleToggleBookmark}
            onPreviewDoc={(d) => setViewerDoc(d)}
            onOpenUpload={() => setUploadModalOpen(true)}
          />
        )}

        {/* VIEW 5: ADMIN PANEL (Full Moderation Suite) */}
        {activeTab === 'admin' && currentUser.role === 'admin' && (
          <>
          <AdminSecurityPanel />
          <AdminPanel
            currentUser={currentUser}
            documents={documents}
            users={users}
            reports={reports}
            auditLogs={auditLogs}
            onApprove={handleAdminApprove}
            onReject={handleAdminReject}
            onDeleteDocument={handleDeleteDocument}
            onToggleSuspendUser={handleToggleSuspendUser}
            onPreviewDoc={(d) => setViewerDoc(d)}
            onDismissReport={handleDismissReport}
          />
          </>
        )}
      </main>

      {/* FOOTER */}
      <footer className="bg-slate-900 text-slate-400 text-xs py-8 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white">
                <GraduationCap className="w-5 h-5" />
              </div>
              <span className="font-bold text-white text-sm">
                KMCLU StudyHub
              </span>
              <span className="text-slate-500">|</span>
              <span className="text-[11px] text-slate-400">
                Khwaja Moinuddin Chishti Language University, Lucknow
              </span>
            </div>

            <div className="flex items-center space-x-4 text-xs">
              <button
                onClick={() => setActiveTab('explore')}
                className="hover:text-white"
              >
                Library
              </button>
              <button
                onClick={() => setActiveTab('practice')}
                className="hover:text-white"
              >
                PYQ Quiz
              </button>
              <button
                onClick={() => setActiveTab('planner')}
                className="hover:text-white"
              >
                Exam Timetable
              </button>
              {currentUser.role === 'admin' && <button onClick={() => setActiveTab('admin')} className="text-amber-400 hover:text-amber-300 font-semibold">Admin Panel ({pendingCount})</button>}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800/80 text-[11px] text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
            <p>
              KMCLU StudyHub is an academic resource repository created for B.Tech engineering students. All uploaded question papers and lecture notes are student-contributed and moderated by academic coordinators.
            </p>
            <p className="shrink-0">
              © {new Date().getFullYear()} Faculty of Engineering & Technology, KMCLU.
            </p>
          </div>
        </div>
      </footer>

      {/* MODALS */}

      {/* 1. PDF Viewer Modal */}
      <PDFViewerModal
        document={viewerDoc}
        onClose={() => setViewerDoc(null)}
        isBookmarked={viewerDoc ? bookmarkedIds.includes(viewerDoc.id) : false}
        onToggleBookmark={handleToggleBookmark}
        onAskAI={(doc) => handleOpenAIWithDoc(doc)}
        onReport={(doc) => setReportDoc(doc)}
        onDownload={handleDownload}
      />

      {/* 2. PDF Upload Modal */}
      <UploadModal
        currentUser={currentUser}
        existingDocuments={documents}
        isOpen={uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
        onSubmitUpload={handleUploadSubmit}
      />

      {/* 3. Global Quick Search Modal */}
      <QuickSearchModal
        isOpen={quickSearchOpen}
        onClose={() => setQuickSearchOpen(false)}
        documents={documents}
        onSelectDoc={(doc) => setViewerDoc(doc)}
      />

      {/* 4. AI Study Assistant Modal */}
      <AIAssistantModal
        isOpen={aiAssistantOpen}
        onClose={() => setAiAssistantOpen(false)}
        activeDocument={aiContextDoc}
      />

      {/* 5. Report Grievance Modal */}
      <ReportModal
        document={reportDoc}
        isOpen={!!reportDoc}
        onClose={() => setReportDoc(null)}
        onSubmitReport={handleReportDocument}
      />
    </div>
  );
}

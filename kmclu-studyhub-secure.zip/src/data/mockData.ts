import { DocumentItem, QuizQuestion } from '../utils/studyhub-logic';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'admin';
  rollNo?: string;
  facultyId: string;
  facultyName: string;
  department: string;
  course: string;
  branch: string;
  semester: number;
  avatar: string;
  designation?: string;
  reputationPoints: number;
  uploadsCount: number;
  approvedCount: number;
  isSuspended?: boolean;
}

export interface FacultyInfo {
  id: string;
  name: string;
  fullName: string;
  icon: string;
  color: string;
  badge: string;
  description: string;
  departments: string[];
  courses: string[];
}

export interface SubjectOutline {
  code: string;
  name: string;
  facultyId: string;
  facultyName: string;
  department: string;
  course: string;
  semester: number;
  branch: string;
  credits: number;
  units: string[];
}

export const KMCLU_FACULTIES: FacultyInfo[] = [
  {
    id: 'FET',
    name: 'Engineering & Technology',
    fullName: 'Faculty of Engineering & Technology (FET)',
    icon: 'Cpu',
    color: 'from-blue-600 to-indigo-700',
    badge: 'bg-blue-100 text-blue-800 border-blue-200',
    description: 'B.Tech (CSE, AI&DS, AI&ML, Civil, Mechanical), BCA, MCA Programs.',
    departments: ['Computer Science & Engineering', 'Artificial Intelligence', 'Civil Engineering', 'Mechanical Engineering', 'Computer Applications'],
    courses: ['B.Tech', 'BCA', 'MCA'],
  },
  {
    id: 'COMMERCE',
    name: 'Commerce & Management',
    fullName: 'Faculty of Commerce & Business Studies',
    icon: 'Briefcase',
    color: 'from-amber-600 to-orange-700',
    badge: 'bg-amber-100 text-amber-800 border-amber-200',
    description: 'BBA, MBA, B.Com (Hons), M.Com, Business Analytics & Finance.',
    departments: ['Business Administration', 'Commerce & Accounting', 'Finance & Marketing'],
    courses: ['BBA', 'MBA', 'B.Com', 'M.Com'],
  },
  {
    id: 'LAW',
    name: 'Faculty of Law',
    fullName: 'Faculty of Law & Legal Studies',
    icon: 'Scale',
    color: 'from-purple-600 to-indigo-800',
    badge: 'bg-purple-100 text-purple-800 border-purple-200',
    description: 'LL.B (3 Years), B.A. LL.B (5 Years Integrated), LL.M in Corporate & Constitutional Law.',
    departments: ['Constitutional Law', 'Criminal Law', 'Corporate & Commercial Law'],
    courses: ['LL.B', 'BA-LL.B', 'LL.M'],
  },
  {
    id: 'SCIENCE',
    name: 'Science & Computing',
    fullName: 'Faculty of Science',
    icon: 'FlaskConical',
    color: 'from-emerald-600 to-teal-700',
    badge: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    description: 'B.Sc & M.Sc in Physics, Chemistry, Mathematics, Biotechnology, Zoology & Botany.',
    departments: ['Physics', 'Chemistry', 'Mathematics', 'Biotechnology', 'Life Sciences'],
    courses: ['B.Sc', 'M.Sc'],
  },
  {
    id: 'HUMANITIES',
    name: 'Humanities & Languages',
    fullName: 'Faculty of Humanities, Social Sciences & Languages',
    icon: 'Languages',
    color: 'from-rose-600 to-pink-700',
    badge: 'bg-rose-100 text-rose-800 border-rose-200',
    description: 'BA & MA in Urdu, Arabic, Persian, English, Hindi, History, Political Science & Economics.',
    departments: ['Urdu & Persian', 'Arabic & Islamic Studies', 'English & Foreign Languages', 'Hindi & Modern Indian Languages', 'Political Science', 'Economics'],
    courses: ['BA', 'MA'],
  },
  {
    id: 'JOURNALISM',
    name: 'Journalism & Media',
    fullName: 'Faculty of Journalism & Mass Communication (FJMC)',
    icon: 'Newspaper',
    color: 'from-sky-600 to-cyan-700',
    badge: 'bg-sky-100 text-sky-800 border-sky-200',
    description: 'BA-JMC, MA-JMC, Broadcast Journalism, Digital Media & Advertising.',
    departments: ['Print & Broadcast Journalism', 'New Media & Communication', 'Advertising & PR'],
    courses: ['BA-JMC', 'MA-JMC'],
  },
  {
    id: 'PHARMACY',
    name: 'Pharmacy & Health',
    fullName: 'Faculty of Pharmacy',
    icon: 'Pill',
    color: 'from-teal-600 to-emerald-700',
    badge: 'bg-teal-100 text-teal-800 border-teal-200',
    description: 'B.Pharm, D.Pharm, Pharmacology & Pharmaceutical Chemistry.',
    departments: ['Pharmaceutics', 'Pharmacology', 'Pharmaceutical Chemistry'],
    courses: ['B.Pharm', 'D.Pharm'],
  },
  {
    id: 'EDUCATION',
    name: 'Faculty of Education',
    fullName: 'Faculty of Education & Pedagogy',
    icon: 'GraduationCap',
    color: 'from-violet-600 to-purple-800',
    badge: 'bg-violet-100 text-violet-800 border-violet-200',
    description: 'B.Ed, M.Ed, Teacher Training & Educational Psychology.',
    departments: ['Teacher Education', 'Educational Technology', 'Special Education'],
    courses: ['B.Ed', 'M.Ed'],
  },
];

// Helper to keep backwards compatibility for BRANCHES
export const BRANCHES = [
  { id: 'CSE', name: 'Computer Science (B.Tech)', fullName: 'B.Tech Computer Science & Engineering', icon: 'Terminal', color: 'from-blue-600 to-indigo-700', badge: 'bg-blue-100 text-blue-800', description: 'Systems, DSA, AI, Networks', totalSubjects: 44 },
  { id: 'AI & DS', name: 'AI & Data Science (B.Tech)', fullName: 'B.Tech AI & Data Science', icon: 'Brain', color: 'from-purple-600 to-pink-700', badge: 'bg-purple-100 text-purple-800', description: 'Deep Learning, Analytics', totalSubjects: 42 },
  { id: 'MANAGEMENT', name: 'Management & BBA/MBA', fullName: 'Management Studies (BBA/MBA)', icon: 'Briefcase', color: 'from-amber-600 to-orange-700', badge: 'bg-amber-100 text-amber-800', description: 'Finance, Marketing, HR', totalSubjects: 38 },
  { id: 'LAW', name: 'Legal Studies (LL.B)', fullName: 'Faculty of Law (LL.B / BA-LL.B)', icon: 'Scale', color: 'from-indigo-600 to-purple-800', badge: 'bg-indigo-100 text-indigo-800', description: 'Constitution, Torts, IPC', totalSubjects: 36 },
  { id: 'SCIENCE', name: 'Sciences (B.Sc/M.Sc)', fullName: 'Sciences (Physics, Chem, Math)', icon: 'FlaskConical', color: 'from-emerald-600 to-teal-700', badge: 'bg-emerald-100 text-emerald-800', description: 'Pure & Applied Sciences', totalSubjects: 40 },
  { id: 'JOURNALISM', name: 'Media (BA-JMC)', fullName: 'Journalism & Mass Comm', icon: 'Newspaper', color: 'from-sky-600 to-cyan-700', badge: 'bg-sky-100 text-sky-800', description: 'Print, Broadcast, Digital Media', totalSubjects: 32 },
];

export const KMCLU_SUBJECTS: SubjectOutline[] = [
  // 1. FET (Engineering & Tech)
  { code: 'BCS-401', name: 'Operating Systems', facultyId: 'FET', facultyName: 'Engineering & Technology', department: 'Computer Science & Engineering', course: 'B.Tech', semester: 4, branch: 'CSE', credits: 4, units: ['CPU Scheduling', 'Deadlocks', 'Memory & Paging', 'File Systems'] },
  { code: 'BCS-501', name: 'Database Management Systems', facultyId: 'FET', facultyName: 'Engineering & Technology', department: 'Computer Science & Engineering', course: 'B.Tech', semester: 5, branch: 'CSE', credits: 4, units: ['ER Modeling', 'Relational Algebra & SQL', 'Normalization (BCNF)', 'Concurrency Control & ACID'] },
  { code: 'BAI-501', name: 'Machine Learning Fundamentals', facultyId: 'FET', facultyName: 'Engineering & Technology', department: 'Artificial Intelligence', course: 'B.Tech', semester: 5, branch: 'AI & DS', credits: 4, units: ['Regression & Classification', 'Decision Trees', 'SVM & Kernels', 'Unsupervised Clustering'] },
  { code: 'BCA-301', name: 'Web Development & Java', facultyId: 'FET', facultyName: 'Engineering & Technology', department: 'Computer Applications', course: 'BCA', semester: 3, branch: 'General', credits: 4, units: ['HTML5/CSS3', 'JavaScript ES6', 'Java OOP', 'JDBC & Servlets'] },
  { code: 'MCA-201', name: 'Advanced Algorithms & Complexity', facultyId: 'FET', facultyName: 'Engineering & Technology', department: 'Computer Applications', course: 'MCA', semester: 2, branch: 'General', credits: 4, units: ['Dynamic Programming', 'Graph Theory', 'NP-Completeness', 'Approximation Algorithms'] },

  // 2. Commerce & Management
  { code: 'MBA-101', name: 'Financial Management & Accounting', facultyId: 'COMMERCE', facultyName: 'Commerce & Management', department: 'Business Administration', course: 'MBA', semester: 1, branch: 'Finance', credits: 4, units: ['Time Value of Money', 'Capital Budgeting', 'Cost of Capital', 'Working Capital Management'] },
  { code: 'MBA-202', name: 'Marketing Management & Consumer Behavior', facultyId: 'COMMERCE', facultyName: 'Commerce & Management', department: 'Business Administration', course: 'MBA', semester: 2, branch: 'Marketing', credits: 4, units: ['Marketing Mix (4Ps)', 'Market Segmentation & Targeting', 'Consumer Decision Journey', 'Brand Positioning'] },
  { code: 'BBA-301', name: 'Business Law & Regulatory Framework', facultyId: 'COMMERCE', facultyName: 'Commerce & Management', department: 'Business Administration', course: 'BBA', semester: 3, branch: 'General', credits: 4, units: ['Indian Contract Act 1872', 'Sale of Goods Act', 'Negotiable Instruments Act', 'Consumer Protection Act'] },
  { code: 'BCO-201', name: 'Corporate Accounting & Auditing', facultyId: 'COMMERCE', facultyName: 'Commerce & Management', department: 'Commerce & Accounting', course: 'B.Com', semester: 2, branch: 'Accounting', credits: 4, units: ['Issue of Shares & Debentures', 'Final Accounts of Companies', 'Internal Audit & Standards', 'Valuation of Goodwill'] },

  // 3. Faculty of Law
  { code: 'LAW-101', name: 'Constitutional Law of India - I', facultyId: 'LAW', facultyName: 'Faculty of Law', department: 'Constitutional Law', course: 'LL.B', semester: 1, branch: 'Constitutional Law', credits: 4, units: ['Preamble & Citizenship', 'Fundamental Rights (Art. 14, 19, 21)', 'Directive Principles of State Policy', 'Writ Jurisdiction (Art. 32 & 226)'] },
  { code: 'LAW-202', name: 'Indian Penal Code (Criminal Law)', facultyId: 'LAW', facultyName: 'Faculty of Law', department: 'Criminal Law', course: 'LL.B', semester: 2, branch: 'Criminal Law', credits: 4, units: ['General Exceptions & Mens Rea', 'Offences Against Human Body (Murder vs Culpable Homicide)', 'Offences Against Property (Theft, Extortion, Robbery)', 'Defamation & Criminal Conspiracy'] },
  { code: 'BAL-301', name: 'Law of Torts & Consumer Protection', facultyId: 'LAW', facultyName: 'Faculty of Law', department: 'Constitutional Law', course: 'BA-LL.B', semester: 3, branch: 'General Law', credits: 4, units: ['Principles of Tortious Liability', 'Negligence & Res Ipsa Loquitur', 'Strict & Absolute Liability (Rylands vs Fletcher)', 'Consumer Grievance Redressal'] },

  // 4. Faculty of Science
  { code: 'BSC-201', name: 'Classical Mechanics & Wave Optics', facultyId: 'SCIENCE', facultyName: 'Science & Computing', department: 'Physics', course: 'B.Sc', semester: 2, branch: 'Physics', credits: 4, units: ['Lagrangian Mechanics', 'Central Force Motion', 'Interference & Diffraction', 'Polarization & Laser Optics'] },
  { code: 'BSC-301', name: 'Real Analysis & Calculus', facultyId: 'SCIENCE', facultyName: 'Science & Computing', department: 'Mathematics', course: 'B.Sc', semester: 3, branch: 'Mathematics', credits: 4, units: ['Sequences & Series of Reals', 'Riemann Integration', 'Continuity & Differentiability', 'Uniform Convergence'] },
  { code: 'MSC-101', name: 'Molecular Genetics & Recombinant DNA', facultyId: 'SCIENCE', facultyName: 'Science & Computing', department: 'Biotechnology', course: 'M.Sc', semester: 1, branch: 'Biotechnology', credits: 4, units: ['DNA Replication & Repair', 'Gene Expression & Transcription', 'Cloning Vectors & PCR', 'CRISPR-Cas9 Technologies'] },

  // 5. Faculty of Humanities & Languages
  { code: 'BA-101', name: 'Modern Urdu Literature & Ghazal', facultyId: 'HUMANITIES', facultyName: 'Humanities & Languages', department: 'Urdu & Persian', course: 'BA', semester: 1, branch: 'Urdu', credits: 4, units: ['Dabistan-e-Delhi & Dabistan-e-Lucknow', 'Ghalib and Mir Taqi Mir', 'Evolution of Nazm', 'Urdu Prose & Sir Syed Movement'] },
  { code: 'BA-201', name: 'History of English Literature & Drama', facultyId: 'HUMANITIES', facultyName: 'Humanities & Languages', department: 'English & Foreign Languages', course: 'BA', semester: 2, branch: 'English', credits: 4, units: ['Elizabethan & Shakespearean Tragedy', 'Romantic Poetry (Wordsworth, Keats)', 'Victorian Novel (Dickens)', 'Modernist Movement'] },
  { code: 'MA-201', name: 'Indian Political Thought & Governance', facultyId: 'HUMANITIES', facultyName: 'Humanities & Languages', department: 'Political Science', course: 'MA', semester: 2, branch: 'Political Science', credits: 4, units: ['Kautilya & Arthashastra', 'Gandhi & Satyagraha', 'B.R. Ambedkar & Social Justice', 'Federalism & Coalition Politics'] },

  // 6. Faculty of Journalism (FJMC)
  { code: 'JMC-201', name: 'News Reporting, Editing & Headline Writing', facultyId: 'JOURNALISM', facultyName: 'Journalism & Media', department: 'Print & Broadcast Journalism', course: 'BA-JMC', semester: 2, branch: 'Journalism', credits: 4, units: ['Anatomy of a News Story (Inverted Pyramid)', 'Beat Reporting (Crime, Politics, Education)', 'Copy Editing Symbols & Stylebook', 'Feature Writing & Editorials'] },

  // 7. Faculty of Pharmacy
  { code: 'BPH-101', name: 'Human Anatomy and Physiology - I', facultyId: 'PHARMACY', facultyName: 'Pharmacy & Health', department: 'Pharmaceutics', course: 'B.Pharm', semester: 1, branch: 'Pharmacy', credits: 4, units: ['Cellular Level of Organization', 'Cardiovascular System', 'Lymphatic & Skeletal Systems', 'Hemodynamics & Blood Clotting'] },

  // 8. Faculty of Education
  { code: 'BED-101', name: 'Philosophical & Sociological Foundations of Education', facultyId: 'EDUCATION', facultyName: 'Faculty of Education', department: 'Teacher Education', course: 'B.Ed', semester: 1, branch: 'Education', credits: 4, units: ['Idealism, Naturalism & Pragmatism', 'Education as an Instrument of Social Change', 'National Education Policy (NEP 2020)', 'Value Education & Human Rights'] },
];

export const DEMO_USERS: UserProfile[] = [
  {
    id: 'user-ankit',
    name: 'Ankit Sharma',
    email: 'ankit.cse22@kmclu.ac.in',
    role: 'student',
    rollNo: '220180010042',
    facultyId: 'FET',
    facultyName: 'Engineering & Technology',
    department: 'Computer Science & Engineering',
    course: 'B.Tech',
    branch: 'CSE',
    semester: 5,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80',
    reputationPoints: 340,
    uploadsCount: 6,
    approvedCount: 5,
  },
  {
    id: 'user-areeba',
    name: 'Areeba Siddiqui',
    email: 'areeba.mba23@kmclu.ac.in',
    role: 'student',
    rollNo: '230180030012',
    facultyId: 'COMMERCE',
    facultyName: 'Commerce & Management',
    department: 'Business Administration',
    course: 'MBA',
    branch: 'Finance',
    semester: 2,
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=256&q=80',
    reputationPoints: 210,
    uploadsCount: 4,
    approvedCount: 4,
  },
  {
    id: 'user-rahul-law',
    name: 'Rahul Mishra',
    email: 'rahul.law22@kmclu.ac.in',
    role: 'student',
    rollNo: '220180050028',
    facultyId: 'LAW',
    facultyName: 'Faculty of Law',
    department: 'Constitutional Law',
    course: 'LL.B',
    branch: 'Law',
    semester: 3,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=256&q=80',
    reputationPoints: 280,
    uploadsCount: 5,
    approvedCount: 4,
  },
  {
    id: 'user-zainab-sci',
    name: 'Zainab Fatima',
    email: 'zainab.bsc23@kmclu.ac.in',
    role: 'student',
    rollNo: '230180070008',
    facultyId: 'SCIENCE',
    facultyName: 'Science & Computing',
    department: 'Physics',
    course: 'B.Sc',
    branch: 'Physics',
    semester: 2,
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=256&q=80',
    reputationPoints: 175,
    uploadsCount: 3,
    approvedCount: 3,
  },
  {
    id: 'user-farhan-hum',
    name: 'Mohammad Farhan',
    email: 'farhan.ba23@kmclu.ac.in',
    role: 'student',
    rollNo: '230180090014',
    facultyId: 'HUMANITIES',
    facultyName: 'Humanities & Languages',
    department: 'Urdu & Persian',
    course: 'BA',
    branch: 'Urdu',
    semester: 1,
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=256&q=80',
    reputationPoints: 190,
    uploadsCount: 3,
    approvedCount: 3,
  },
  {
    id: 'user-priya-jmc',
    name: 'Priya Verma',
    email: 'priya.jmc23@kmclu.ac.in',
    role: 'student',
    rollNo: '230180110022',
    facultyId: 'JOURNALISM',
    facultyName: 'Journalism & Media',
    department: 'Print & Broadcast Journalism',
    course: 'BA-JMC',
    branch: 'Journalism',
    semester: 2,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80',
    reputationPoints: 230,
    uploadsCount: 4,
    approvedCount: 4,
  },
  {
    id: 'user-aman-pharm',
    name: 'Aman Yadav',
    email: 'aman.pharm24@kmclu.ac.in',
    role: 'student',
    rollNo: '240180130005',
    facultyId: 'PHARMACY',
    facultyName: 'Pharmacy & Health',
    department: 'Pharmaceutics',
    course: 'B.Pharm',
    branch: 'Pharmacy',
    semester: 1,
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=256&q=80',
    reputationPoints: 140,
    uploadsCount: 2,
    approvedCount: 2,
  },

];

export const INITIAL_DOCUMENTS: DocumentItem[] = [
  // 1. Engineering - Operating Systems End Sem PYQ
  {
    id: 'doc-kmclu-001',
    title: 'Operating Systems End-Semester Regular Paper 2024',
    facultyId: 'FET',
    facultyName: 'Engineering & Technology',
    department: 'Computer Science & Engineering',
    course: 'B.Tech',
    branch: 'CSE',
    semester: 4,
    subject: 'Operating Systems',
    subjectCode: 'BCS-401',
    documentType: 'PYQ',
    examYear: 2024,
    uploadedBy: {
      id: 'user-ankit',
      name: 'Ankit Sharma',
      rollNo: '220180010042',
      faculty: 'Engineering & Technology',
      course: 'B.Tech (CSE)',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80',
    },
    fileSize: '2.4 MB',
    pageCount: 3,
    status: 'approved',
    reviewedBy: 'Verified Academic Admin',
    reviewedAt: '2024-06-15T11:20:00Z',
    createdAt: '2024-06-14T09:15:00Z',
    downloads: 412,
    views: 940,
    rating: 4.8,
    tags: ['BCS-401', 'Bankers Algorithm', 'Paging', 'Deadlock', 'B.Tech CSE'],
    contentSummary: 'Official KMCLU B.Tech 4th semester regular end-sem examination paper for Operating Systems with complete 3-section layout.',
    sampleQuestions: [
      'Q1(a) Distinguish between preemptive and non-preemptive scheduling with suitable timeline diagrams.',
      'Q1(b) State the four necessary Coffman conditions required for a deadlock to occur.',
      'Q2 Explain Banker\'s Algorithm for deadlock avoidance with a 5-process allocation matrix.',
      'Q3 Calculate total page faults using FIFO, LRU, and Optimal page replacement with 3 frames.'
    ],
    isFeatured: true,
  },

  // 2. Commerce & Management - MBA Financial Management
  {
    id: 'doc-kmclu-mba-001',
    title: 'Financial Management & Capital Budgeting Mid-Sem Paper 2024',
    facultyId: 'COMMERCE',
    facultyName: 'Commerce & Management',
    department: 'Business Administration',
    course: 'MBA',
    branch: 'Finance',
    semester: 1,
    subject: 'Financial Management & Accounting',
    subjectCode: 'MBA-101',
    documentType: 'Mid-Sem',
    examYear: 2024,
    uploadedBy: {
      id: 'user-areeba',
      name: 'Areeba Siddiqui',
      rollNo: '230180030012',
      faculty: 'Commerce & Management',
      course: 'MBA',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=256&q=80',
    },
    fileSize: '1.9 MB',
    pageCount: 3,
    status: 'approved',
    reviewedBy: 'Verified Academic Admin',
    reviewedAt: '2024-11-05T10:00:00Z',
    createdAt: '2024-11-03T14:30:00Z',
    downloads: 320,
    views: 680,
    rating: 4.9,
    tags: ['MBA-101', 'Capital Budgeting', 'NPV vs IRR', 'Cost of Capital', 'Management'],
    contentSummary: 'KMCLU Faculty of Commerce & Business Studies MBA 1st semester mid-sem test paper on Capital Budgeting, NPV, IRR, and Working Capital cycle.',
    sampleQuestions: [
      'Q1 Explain why Net Present Value (NPV) is theoretically superior to Internal Rate of Return (IRR) in mutually exclusive projects.',
      'Q2 A company is considering two alternative machines with initial outlay of Rs. 5,00,000. Calculate NPV at 10% discount rate.',
      'Q3 Describe the determinants of Working Capital for a manufacturing company in India.'
    ],
    isFeatured: true,
  },

  // 3. Faculty of Law - LL.B Constitutional Law PYQ
  {
    id: 'doc-kmclu-law-001',
    title: 'Constitutional Law of India - I End-Semester PYQ 2023',
    facultyId: 'LAW',
    facultyName: 'Faculty of Law',
    department: 'Constitutional Law',
    course: 'LL.B',
    branch: 'Constitutional Law',
    semester: 1,
    subject: 'Constitutional Law of India - I',
    subjectCode: 'LAW-101',
    documentType: 'PYQ',
    examYear: 2023,
    uploadedBy: {
      id: 'user-rahul-law',
      name: 'Rahul Mishra',
      rollNo: '220180050028',
      faculty: 'Faculty of Law',
      course: 'LL.B',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=256&q=80',
    },
    fileSize: '3.1 MB',
    pageCount: 4,
    status: 'approved',
    reviewedBy: 'Verified Academic Admin',
    reviewedAt: '2023-12-18T16:00:00Z',
    createdAt: '2023-12-15T11:20:00Z',
    downloads: 510,
    views: 1120,
    rating: 5.0,
    tags: ['LAW-101', 'Article 21', 'Basic Structure', 'Fundamental Rights', 'Writ Petitions'],
    contentSummary: 'KMCLU Faculty of Law examination paper covering Article 14 Equality doctrine, Article 21 Right to Life (Maneka Gandhi precedent), and Kesavananda Bharati basic structure.',
    sampleQuestions: [
      'Q1 Critically evaluate the scope of "Procedure established by law" versus "Due process of law" under Article 21 post Maneka Gandhi v. Union of India.',
      'Q2 Discuss the doctrine of Reasonable Classification under Article 14 with landmark judicial pronouncements.',
      'Q3 Explain the various prerogative writs issued by the Supreme Court of India under Article 32.'
    ],
    isFeatured: true,
  },

  // 4. Faculty of Science - B.Sc Physics Notes
  {
    id: 'doc-kmclu-sci-001',
    title: 'Wave Optics & Laser Physics Complete Handwritten Notes',
    facultyId: 'SCIENCE',
    facultyName: 'Science & Computing',
    department: 'Physics',
    course: 'B.Sc',
    branch: 'Physics',
    semester: 2,
    subject: 'Classical Mechanics & Wave Optics',
    subjectCode: 'BSC-201',
    documentType: 'Notes',
    examYear: 2024,
    uploadedBy: {
      id: 'user-zainab-sci',
      name: 'Zainab Fatima',
      rollNo: '230180070008',
      faculty: 'Science & Computing',
      course: 'B.Sc (Physics)',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=256&q=80',
    },
    fileSize: '7.8 MB',
    pageCount: 36,
    status: 'approved',
    reviewedBy: 'Verified Academic Admin',
    reviewedAt: '2024-05-10T12:00:00Z',
    createdAt: '2024-05-08T09:40:00Z',
    downloads: 380,
    views: 810,
    rating: 4.8,
    tags: ['BSC-201', 'Interference', 'Diffraction', 'He-Ne Laser', 'B.Sc Physics'],
    contentSummary: 'Clean handwritten diagrams of Fresnel and Fraunhofer diffraction, Newton\'s Rings derivation with ring radius formula, and Helium-Neon laser pumping energy diagram.',
    sampleQuestions: [
      'Topic: Derivation of radius of nth dark ring in Newton\'s rings experiment by reflected light.',
      'Topic: Condition for sustained interference of light and fringe width formula beta = D*lambda / d.'
    ],
    isFeatured: false,
  },

  // 5. Faculty of Humanities - BA Urdu Ghazal PYQ
  {
    id: 'doc-kmclu-hum-001',
    title: 'Modern Urdu Literature & Classical Ghazal End-Sem PYQ 2023',
    facultyId: 'HUMANITIES',
    facultyName: 'Humanities & Languages',
    department: 'Urdu & Persian',
    course: 'BA',
    branch: 'Urdu',
    semester: 1,
    subject: 'Modern Urdu Literature & Ghazal',
    subjectCode: 'BA-101',
    documentType: 'PYQ',
    examYear: 2023,
    uploadedBy: {
      id: 'verified-admin',
      name: 'Verified Academic Admin',
      faculty: 'Humanities & Languages',
      course: 'University Repository',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=256&q=80',
    },
    fileSize: '2.0 MB',
    pageCount: 3,
    status: 'approved',
    reviewedBy: 'Verified Academic Admin',
    reviewedAt: '2023-11-20T10:00:00Z',
    createdAt: '2023-11-18T15:00:00Z',
    downloads: 290,
    views: 650,
    rating: 4.9,
    tags: ['BA-101', 'Mir Taqi Mir', 'Ghalib', 'Dabistan-e-Lucknow', 'Urdu Ghazal'],
    contentSummary: 'KMCLU Faculty of Languages examination paper containing ghazal tashreeh, comparison between Dabistan-e-Delhi and Dabistan-e-Lucknow, and Mir Taqi Mir\'s poetic aesthetics.',
    sampleQuestions: [
      'Q1 Dabistan-e-Lucknow aur Dabistan-e-Delhi ke tarz-e-sukhan ka tafseeli muqabla kijiye.',
      'Q2 Mirza Ghalib ki fikr-o-fun par roshni daliye aur unke kalam ki khusoosiyat bayan kijiye.',
      'Q3 Darj zail ashaar ki ba-hawala tashreeh kijiye.'
    ],
    isFeatured: true,
  },

  // 6. Faculty of Journalism - BA-JMC Reporting PYQ
  {
    id: 'doc-kmclu-jmc-001',
    title: 'News Reporting & Inverted Pyramid Technique Mid-Sem 2024',
    facultyId: 'JOURNALISM',
    facultyName: 'Journalism & Media',
    department: 'Print & Broadcast Journalism',
    course: 'BA-JMC',
    branch: 'Journalism',
    semester: 2,
    subject: 'News Reporting, Editing & Headline Writing',
    subjectCode: 'JMC-201',
    documentType: 'Mid-Sem',
    examYear: 2024,
    uploadedBy: {
      id: 'user-areeba',
      name: 'Areeba Siddiqui',
      rollNo: '230180030012',
      faculty: 'Journalism & Media',
      course: 'BA-JMC',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=256&q=80',
    },
    fileSize: '1.7 MB',
    pageCount: 2,
    status: 'approved',
    reviewedBy: 'Verified Academic Admin',
    reviewedAt: '2024-04-12T11:00:00Z',
    createdAt: '2024-04-10T16:20:00Z',
    downloads: 215,
    views: 470,
    rating: 4.7,
    tags: ['JMC-201', 'Inverted Pyramid', '5W1H', 'Headline Writing', 'Media Ethics'],
    contentSummary: 'KMCLU FJMC test paper on structural layout of hard news, writing strong leads using 5Ws and 1H, and headline rules for print newspapers.',
    sampleQuestions: [
      'Q1 Explain the Inverted Pyramid formula of news writing with an illustrated diagram and reason for its prevalence.',
      'Q2 What is the role of 5 Ws and 1 H in crafting an impactful newspaper lead paragraph?'
    ],
    isFeatured: false,
  },

  // 7. Faculty of Pharmacy - B.Pharm Human Anatomy PYQ
  {
    id: 'doc-kmclu-pharm-001',
    title: 'Human Anatomy & Physiology - I End-Semester PYQ 2024',
    facultyId: 'PHARMACY',
    facultyName: 'Pharmacy & Health',
    department: 'Pharmaceutics',
    course: 'B.Pharm',
    branch: 'Pharmacy',
    semester: 1,
    subject: 'Human Anatomy and Physiology - I',
    subjectCode: 'BPH-101',
    documentType: 'PYQ',
    examYear: 2024,
    uploadedBy: {
      id: 'user-aman-pharm',
      name: 'Aman Yadav',
      rollNo: '240180130005',
      faculty: 'Pharmacy & Health',
      course: 'B.Pharm',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=256&q=80',
    },
    fileSize: '3.4 MB',
    pageCount: 4,
    status: 'approved',
    reviewedBy: 'Verified Academic Admin',
    reviewedAt: '2024-07-10T14:30:00Z',
    createdAt: '2024-07-08T10:15:00Z',
    downloads: 340,
    views: 720,
    rating: 4.9,
    tags: ['BPH-101', 'Cardiovascular System', 'Blood Clotting', 'Cardiac Cycle', 'B.Pharm'],
    contentSummary: 'KMCLU Faculty of Pharmacy 1st semester paper covering cardiac conduction system, intrinsic blood coagulation cascade, and autonomic nervous system receptors.',
    sampleQuestions: [
      'Q1 Draw a neat, labelled diagram of the human heart showing internal structures and trace blood flow.',
      'Q2 Explain the extrinsic and intrinsic pathways of blood coagulation with clotting factors involved.'
    ],
    isFeatured: true,
  },

  // 8. Faculty of Education - B.Ed Foundations of Education Notes
  {
    id: 'doc-kmclu-edu-001',
    title: 'Foundations of Education & NEP 2020 Complete Syllabus Notes',
    facultyId: 'EDUCATION',
    facultyName: 'Faculty of Education',
    department: 'Teacher Education',
    course: 'B.Ed',
    branch: 'Education',
    semester: 1,
    subject: 'Philosophical & Sociological Foundations of Education',
    subjectCode: 'BED-101',
    documentType: 'Notes',
    examYear: 2024,
    uploadedBy: {
      id: 'verified-admin',
      name: 'Verified Academic Admin',
      faculty: 'Faculty of Education',
      course: 'University Repository',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=256&q=80',
    },
    fileSize: '4.8 MB',
    pageCount: 32,
    status: 'approved',
    reviewedBy: 'Verified Academic Admin',
    reviewedAt: '2024-08-15T11:00:00Z',
    createdAt: '2024-08-12T09:20:00Z',
    downloads: 280,
    views: 610,
    rating: 4.8,
    tags: ['BED-101', 'NEP 2020', 'Pragmatism', 'Idealism', 'B.Ed Notes'],
    contentSummary: 'Complete curriculum notes on Indian philosophical schools (Vedanta, Buddhist, Islamic), Western philosophies, and National Education Policy (NEP 2020) curricular reforms.',
    sampleQuestions: [
      'Topic: Compare Idealism and Pragmatism with respect to aims of education, curriculum, and role of teacher.',
      'Topic: Key recommendations of NEP 2020 for multidisciplinary higher education and teacher training.'
    ],
    isFeatured: false,
  },

  // ========================================================
  // PENDING UPLOADS ACROSS DEPARTMENTS (For Admin Testing!)
  // ========================================================
  {
    id: 'doc-pending-mba-001',
    title: 'Marketing Management & Consumer Analytics Mid-Sem Paper 2025',
    facultyId: 'COMMERCE',
    facultyName: 'Commerce & Management',
    department: 'Business Administration',
    course: 'MBA',
    branch: 'Marketing',
    semester: 2,
    subject: 'Marketing Management & Consumer Behavior',
    subjectCode: 'MBA-202',
    documentType: 'Mid-Sem',
    examYear: 2025,
    uploadedBy: {
      id: 'user-areeba',
      name: 'Areeba Siddiqui',
      rollNo: '230180030012',
      faculty: 'Commerce & Management',
      course: 'MBA (Marketing)',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=256&q=80',
    },
    fileSize: '2.1 MB',
    pageCount: 2,
    status: 'pending',
    createdAt: '2026-10-19T10:15:00Z',
    downloads: 0,
    views: 4,
    tags: ['MBA-202', 'Consumer Journey', 'STP Model', 'Mid-Sem 2025'],
    contentSummary: 'Fresh mid-sem paper from Faculty of Commerce MBA exams with questions on Segmentation, Targeting, and Positioning (STP) analysis.',
    sampleQuestions: [
      'Q1 Analyze the Consumer Decision-Making process for high-involvement durable goods.',
      'Q2 Differentiate between Push vs Pull marketing strategies with Indian FMCG sector examples.'
    ],
  },
  {
    id: 'doc-pending-law-001',
    title: 'Law of Torts & Consumer Protection Notes (Handwritten)',
    facultyId: 'LAW',
    facultyName: 'Faculty of Law',
    department: 'Constitutional Law',
    course: 'BA-LL.B',
    branch: 'General Law',
    semester: 3,
    subject: 'Law of Torts & Consumer Protection',
    subjectCode: 'BAL-301',
    documentType: 'Notes',
    examYear: 2024,
    uploadedBy: {
      id: 'user-rahul-law',
      name: 'Rahul Mishra',
      rollNo: '220180050028',
      faculty: 'Faculty of Law',
      course: 'BA-LL.B',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=256&q=80',
    },
    fileSize: '5.4 MB',
    pageCount: 24,
    status: 'pending',
    createdAt: '2026-10-19T14:40:00Z',
    downloads: 0,
    views: 3,
    tags: ['BAL-301', 'Strict Liability', 'Vicarious Liability', 'Tort Law'],
    contentSummary: 'Comprehensive class notes with landmark case summaries (Rylands v. Fletcher, M.C. Mehta v. Union of India) and tort defenses.',
    sampleQuestions: [
      'Topic: Strict liability vs Absolute liability principles established in Shriram Gas Leak case.',
      'Topic: Defenses in tort: Volenti non fit injuria and Act of God.'
    ],
  },
  {
    id: 'doc-pending-cse-001',
    title: 'Compiler Design LL(1) Parsing Handwritten Lecture Notes',
    facultyId: 'FET',
    facultyName: 'Engineering & Technology',
    department: 'Computer Science & Engineering',
    course: 'B.Tech',
    branch: 'CSE',
    semester: 6,
    subject: 'Compiler Design',
    subjectCode: 'BCS-601',
    documentType: 'Notes',
    examYear: 2024,
    uploadedBy: {
      id: 'user-ankit',
      name: 'Ankit Sharma',
      rollNo: '220180010042',
      faculty: 'Engineering & Technology',
      course: 'B.Tech (CSE)',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80',
    },
    fileSize: '6.2 MB',
    pageCount: 28,
    status: 'pending',
    createdAt: '2026-10-19T08:15:00Z',
    downloads: 0,
    views: 5,
    tags: ['BCS-601', 'Lexical Analysis', 'LL(1) Parser', 'First & Follow'],
    contentSummary: 'Detailed class notes with First and Follow computation tables and Predictive Parsing Table construction.',
    sampleQuestions: [
      'Topic: Computing First and Follow sets for context-free grammar with epsilon productions.',
      'Topic: Construction of LL(1) parse table and handling shift-reduce ambiguities.'
    ],
  },
  {
    id: 'doc-pending-hum-001',
    title: 'Modern Persian Poetry & Classical Prose Notes (Urdu Translation)',
    facultyId: 'HUMANITIES',
    facultyName: 'Humanities & Languages',
    department: 'Urdu & Persian',
    course: 'BA',
    branch: 'Urdu',
    semester: 1,
    subject: 'Modern Urdu Literature & Ghazal',
    subjectCode: 'BA-101',
    documentType: 'Notes',
    examYear: 2024,
    uploadedBy: {
      id: 'user-farhan-hum',
      name: 'Mohammad Farhan',
      rollNo: '230180090014',
      faculty: 'Humanities & Languages',
      course: 'BA (Urdu)',
      avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=256&q=80',
    },
    fileSize: '3.9 MB',
    pageCount: 18,
    status: 'pending',
    createdAt: '2026-10-19T16:20:00Z',
    downloads: 0,
    views: 2,
    tags: ['BA-101', 'Urdu Prose', 'Ghalibiyat', 'Dabistan Lucknow'],
    contentSummary: 'Handwritten analytical commentary on Mirza Ghalib letters and evolution of Lucknow school of Urdu ghazal.',
    sampleQuestions: [
      'Topic: Ghalib ke khutoot ki adabi ehmiyat aur unka aam fahm tarz-e-tehreer.',
      'Topic: Dabistan-e-Lucknow ke shora ki nazuk-khayali.'
    ],
  },
  {
    id: 'doc-pending-pharm-001',
    title: 'Pharmaceutical Chemistry & Volumetric Analysis Lab Manual',
    facultyId: 'PHARMACY',
    facultyName: 'Pharmacy & Health',
    department: 'Pharmaceutics',
    course: 'B.Pharm',
    branch: 'Pharmacy',
    semester: 1,
    subject: 'Human Anatomy and Physiology - I',
    subjectCode: 'BPH-101',
    documentType: 'Syllabus',
    examYear: 2024,
    uploadedBy: {
      id: 'user-aman-pharm',
      name: 'Aman Yadav',
      rollNo: '240180130005',
      faculty: 'Pharmacy & Health',
      course: 'B.Pharm',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=256&q=80',
    },
    fileSize: '4.5 MB',
    pageCount: 22,
    status: 'pending',
    createdAt: '2026-10-19T18:10:00Z',
    downloads: 0,
    views: 3,
    tags: ['BPH-101', 'Acid-Base Titration', 'Lab Manual', 'KMCLU Pharmacy'],
    contentSummary: 'Standard laboratory procedures for acid-base titrations, standardization of 0.1N NaOH, and limit tests for chloride and sulphate.',
    sampleQuestions: [
      'Topic: Principle and procedure for Limit test for Iron according to Indian Pharmacopoeia.',
      'Topic: Preparation and standardization of 0.1 M Potassium Permanganate solution.'
    ],
  },
];

export const PRACTICE_QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 'quiz-os-01',
    subject: 'Operating Systems (Engineering)',
    question: 'In the Banker\'s Algorithm for deadlock avoidance, if a system can allocate resources to each process in some order without entering deadlock, the state is termed as:',
    options: ['Deadlock-free state', 'Safe state', 'Preempted state', 'Starvation state'],
    correctOptionIndex: 1,
    explanation: 'A state is "safe" if there exists a safe execution sequence of processes P1, P2, ... Pn such that resource needs can be met by available resources plus resources held by prior processes.',
    difficulty: 'easy',
    topic: 'Deadlock Avoidance',
  },
  {
    id: 'quiz-law-01',
    subject: 'Constitutional Law (Faculty of Law)',
    question: 'Which landmark Supreme Court judgment introduced the doctrine of "Basic Structure" of the Indian Constitution, limiting parliamentary power to amend the constitution under Article 368?',
    options: [
      'Golaknath v. State of Punjab (1967)',
      'Kesavananda Bharati v. State of Kerala (1973)',
      'Minerva Mills v. Union of India (1980)',
      'Maneka Gandhi v. Union of India (1978)'
    ],
    correctOptionIndex: 1,
    explanation: 'The 13-judge bench in Kesavananda Bharati (1973) held by a 7-6 majority that while Parliament can amend any part of the Constitution, it cannot alter its Basic Structure.',
    difficulty: 'medium',
    topic: 'Constitutional Law',
  },
  {
    id: 'quiz-mba-01',
    subject: 'Financial Management (Commerce & Management)',
    question: 'In Capital Budgeting, which evaluation technique strictly accounts for the Time Value of Money and reinvestment at the firm\'s cost of capital?',
    options: [
      'Payback Period Method',
      'Accounting Rate of Return (ARR)',
      'Net Present Value (NPV)',
      'Benefit-Cost Ratio without discounting'
    ],
    correctOptionIndex: 2,
    explanation: 'NPV discounts all incoming and outgoing cash flows at the firm\'s cost of capital, making it the most theoretically sound method for shareholder wealth maximization.',
    difficulty: 'medium',
    topic: 'Capital Budgeting',
  },
  {
    id: 'quiz-sci-01',
    subject: 'Physics & Optics (Faculty of Science)',
    question: 'In Newton\'s Rings experiment by reflected light, the central spot is always dark because:',
    options: [
      'Light is completely absorbed by the glass plate',
      'A phase change of pi (180 degrees) occurs upon reflection from the denser medium',
      'The film thickness at the point of contact is infinity',
      'Diffraction cancels the central ray'
    ],
    correctOptionIndex: 1,
    explanation: 'According to Stokes treatment, reflection at the surface of an optically denser medium introduces an extra path difference of lambda/2 (equivalent to pi phase change), creating destructive interference at zero film thickness.',
    difficulty: 'medium',
    topic: 'Wave Optics',
  },
  {
    id: 'quiz-jmc-01',
    subject: 'Journalism & Mass Comm (FJMC)',
    question: 'In traditional print news reporting, the structure where the most critical facts (5 Ws and 1 H) are placed at the very top is known as:',
    options: [
      'Chronological Order',
      'Inverted Pyramid Structure',
      'Narrative Arc Method',
      'Diamond Structure'
    ],
    correctOptionIndex: 1,
    explanation: 'The Inverted Pyramid places the lead (who, what, when, where, why, how) first, followed by supporting details, allowing editors to trim from the bottom without losing crucial facts.',
    difficulty: 'easy',
    topic: 'News Reporting',
  },
];

export const UPCOMING_EXAMS = [
  {
    id: 'exam-1',
    subject: 'Operating Systems (BCS-401)',
    faculty: 'Faculty of Engineering & Technology',
    course: 'B.Tech (CSE)',
    branch: 'CSE',
    date: '2026-11-12',
    time: '10:00 AM - 01:00 PM',
    venue: 'Block B, Hall 304, FET KMCLU',
    syllabusCovered: 'All 5 Units (CPU Scheduling, Memory, Deadlocks, File Systems, Security)',
    daysLeft: 23,
    status: 'urgent',
  },
  {
    id: 'exam-2',
    subject: 'Constitutional Law - I (LAW-101)',
    faculty: 'Faculty of Law',
    course: 'LL.B',
    branch: 'Law',
    date: '2026-11-14',
    time: '10:00 AM - 01:00 PM',
    venue: 'Law Faculty Building, Moot Court Hall, KMCLU',
    syllabusCovered: 'Preamble, Fundamental Rights (Art 14-32), Directive Principles',
    daysLeft: 25,
    status: 'urgent',
  },
  {
    id: 'exam-3',
    subject: 'Financial Management (MBA-101)',
    faculty: 'Faculty of Commerce & Management',
    course: 'MBA',
    branch: 'Finance & Marketing',
    date: '2026-11-18',
    time: '02:00 PM - 05:00 PM',
    venue: 'Management Block, Seminar Hall 1, KMCLU',
    syllabusCovered: 'Capital Budgeting, Cost of Capital, Working Capital Management',
    daysLeft: 29,
    status: 'upcoming',
  },
  {
    id: 'exam-4',
    subject: 'Classical Mechanics & Optics (BSC-201)',
    faculty: 'Faculty of Science',
    course: 'B.Sc',
    branch: 'Physics & Maths',
    date: '2026-11-22',
    time: '10:00 AM - 01:00 PM',
    venue: 'Science Block, Physics Lecture Hall 2, KMCLU',
    syllabusCovered: 'Lagrangian Mechanics, Interference, Newton Rings, Lasers',
    daysLeft: 33,
    status: 'upcoming',
  },
];

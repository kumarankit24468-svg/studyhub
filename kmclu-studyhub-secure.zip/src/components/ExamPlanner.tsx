import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  MapPin,
  CheckCircle2,
  Circle,
  Plus,
  BookOpen,
  AlertCircle,
  Sparkles,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';
import { UPCOMING_EXAMS } from '../data/mockData';

interface TaskItem {
  id: string;
  subject: string;
  topic: string;
  unit: number;
  completed: boolean;
}

export const ExamPlanner: React.FC = () => {
  const [tasks, setTasks] = useState<TaskItem[]>([
    { id: 't1', subject: 'Operating Systems', topic: 'Banker\'s Algorithm & Deadlock recovery', unit: 3, completed: true },
    { id: 't2', subject: 'Operating Systems', topic: 'Virtual Memory & Page Replacement (LRU/FIFO)', unit: 4, completed: true },
    { id: 't3', subject: 'Operating Systems', topic: 'Disk Scheduling Algorithms (SSTF, SCAN, C-LOOK)', unit: 5, completed: false },
    { id: 't4', subject: 'Database Management', topic: 'Boyce-Codd Normal Form (BCNF) decomposition proofs', unit: 3, completed: false },
    { id: 't5', subject: 'Machine Learning', topic: 'Soft Margin SVM derivation & Slack variables', unit: 2, completed: false },
  ]);

  const [newTopic, setNewTopic] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('Operating Systems');

  const toggleTask = (id: string) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t))
    );
  };

  const addTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTopic.trim()) return;
    const newTask: TaskItem = {
      id: 'task_' + Date.now().toString(36),
      subject: selectedSubject,
      topic: newTopic.trim(),
      unit: 1,
      completed: false,
    };
    setTasks((prev) => [...prev, newTask]);
    setNewTopic('');
  };

  const completedCount = tasks.filter((t) => t.completed).length;
  const progressPct = tasks.length > 0 ? Math.round((completedCount / tasks.length) * 100) : 0;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="bg-amber-400 text-slate-950 font-bold px-2 py-0.5 rounded text-[10px] uppercase tracking-wide">
              Academic Calendar 2024-2025
            </span>
            <span className="text-xs text-blue-200">KMCLU Examination Controller</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold mt-1 text-white">
            Semester Examination Timetable & Revision Planner
          </h1>
          <p className="text-xs text-blue-200 mt-1 max-w-xl">
            Keep track of official B.Tech examination slots, countdown timers, and check off unit-wise syllabus goals.
          </p>
        </div>

        {/* Overall Revision Completion Gauge */}
        <div className="bg-white/10 border border-white/10 rounded-xl p-4 shrink-0 w-full md:w-56 space-y-1.5">
          <div className="flex justify-between text-xs text-slate-200 font-medium">
            <span>Revision Completion</span>
            <span className="font-bold text-amber-300">{progressPct}%</span>
          </div>
          <div className="w-full h-2.5 bg-black/30 rounded-full overflow-hidden">
            <div
              style={{ width: `${progressPct}%` }}
              className="h-full bg-gradient-to-r from-amber-400 to-emerald-400 rounded-full transition-all duration-300"
            ></div>
          </div>
          <span className="text-[10px] text-slate-300 block">
            {completedCount} of {tasks.length} high-yield topics mastered
          </span>
        </div>
      </div>

      {/* Official Exam Timetable Cards */}
      <div className="space-y-3">
        <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <Calendar className="w-4 h-4 text-blue-600" />
          <span>Upcoming B.Tech End-Semester Examination Schedule</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {UPCOMING_EXAMS.map((exam) => (
            <div
              key={exam.id}
              className="bg-white rounded-xl border border-slate-200 shadow-xs hover:shadow-md p-5 transition-all space-y-3 relative overflow-hidden"
            >
              <div
                className={`absolute top-0 left-0 right-0 h-1.5 ${
                  exam.status === 'urgent' ? 'bg-rose-500' : 'bg-blue-600'
                }`}
              ></div>

              <div className="flex justify-between items-start pt-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  {exam.branch}
                </span>
                <span
                  className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                    exam.daysLeft <= 25
                      ? 'bg-rose-100 text-rose-800 animate-pulse'
                      : 'bg-blue-100 text-blue-800'
                  }`}
                >
                  {exam.daysLeft} Days Left
                </span>
              </div>

              <div>
                <h3 className="text-sm font-bold text-slate-900 leading-snug">
                  {exam.subject}
                </h3>
                <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
                  {exam.syllabusCovered}
                </p>
              </div>

              <div className="space-y-1.5 text-xs text-slate-600 pt-2 border-t border-slate-100">
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span className="font-semibold">{exam.date}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>{exam.time}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span className="truncate">{exam.venue}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Unit-Wise Revision Checklist */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Personalized Revision Checklist
            </h3>
            <p className="text-xs text-slate-500">
              Check off concepts as you solve questions from the PYQ and Notes library.
            </p>
          </div>

          <form onSubmit={addTask} className="flex items-center space-x-2 w-full sm:w-auto">
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-700 font-medium"
            >
              <option value="Operating Systems">Operating Systems</option>
              <option value="Database Management">Database Management</option>
              <option value="Machine Learning">Machine Learning</option>
              <option value="Data Structures">Data Structures</option>
            </select>
            <input
              type="text"
              placeholder="Add revision topic..."
              value={newTopic}
              onChange={(e) => setNewTopic(e.target.value)}
              className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800 placeholder-slate-400 focus:outline-hidden focus:border-blue-500"
            />
            <button
              type="submit"
              className="p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shrink-0"
              title="Add Topic"
            >
              <Plus className="w-4 h-4" />
            </button>
          </form>
        </div>

        <div className="space-y-2 pt-2">
          {tasks.map((task) => (
            <div
              key={task.id}
              onClick={() => toggleTask(task.id)}
              className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                task.completed
                  ? 'bg-slate-50 border-slate-200 text-slate-400 line-through'
                  : 'bg-white border-slate-200 hover:border-blue-300 text-slate-800'
              }`}
            >
              <div className="flex items-center space-x-3">
                {task.completed ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                ) : (
                  <Circle className="w-4 h-4 text-slate-300 shrink-0" />
                )}
                <div>
                  <span className="text-xs font-bold mr-2 text-blue-700 not-sr-only">
                    [{task.subject}]
                  </span>
                  <span className="text-xs font-medium">{task.topic}</span>
                </div>
              </div>
              <span className="text-[10px] font-mono bg-slate-100 text-slate-600 px-2 py-0.5 rounded">
                Unit {task.unit}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

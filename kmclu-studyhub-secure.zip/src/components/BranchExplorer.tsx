import React from 'react';
import { KMCLU_FACULTIES } from '../data/mockData';
import {
  Cpu,
  Briefcase,
  Scale,
  FlaskConical,
  Languages,
  Newspaper,
  Pill,
  GraduationCap,
  ChevronRight,
  Sparkles,
  Building2,
  Check,
} from 'lucide-react';

interface BranchExplorerProps {
  selectedFaculty: string;
  onSelectFaculty: (facultyId: string) => void;
  selectedBranch: string;
  onSelectBranch: (branchId: string) => void;
  selectedCourse?: string;
  onSelectCourse?: (course: string) => void;
}

export const BranchExplorer: React.FC<BranchExplorerProps> = ({
  selectedFaculty,
  onSelectFaculty,
  selectedBranch,
  onSelectBranch,
  selectedCourse = 'ALL',
  onSelectCourse,
}) => {
  const getFacultyIcon = (iconName: string, isSelected: boolean) => {
    const iconClass = `w-5 h-5 transition-transform ${isSelected ? 'text-white scale-110' : 'text-slate-700'}`;
    switch (iconName) {
      case 'Cpu':
        return <Cpu className={iconClass} />;
      case 'Briefcase':
        return <Briefcase className={iconClass} />;
      case 'Scale':
        return <Scale className={iconClass} />;
      case 'FlaskConical':
        return <FlaskConical className={iconClass} />;
      case 'Languages':
        return <Languages className={iconClass} />;
      case 'Newspaper':
        return <Newspaper className={iconClass} />;
      case 'Pill':
        return <Pill className={iconClass} />;
      case 'GraduationCap':
        return <GraduationCap className={iconClass} />;
      default:
        return <GraduationCap className={iconClass} />;
    }
  };

  const activeFacultyObj = KMCLU_FACULTIES.find((f) => f.id === selectedFaculty);

  return (
    <div className="space-y-4">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-100">
              <Building2 className="w-3.5 h-3.5" />
              University Departments & Faculties
            </span>
            <span className="text-xs text-slate-400">•</span>
            <span className="text-xs text-slate-500 font-medium">
              KMCLU लखनऊ के सभी संकाय एवं विभाग
            </span>
          </div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 mt-1">
            Browse Study Material by Department & Degree
          </h2>
          <p className="text-xs text-slate-500">
            Select your faculty to view verified PYQs, Mid-Sem test papers, notes and syllabus curated by departmental academic moderators.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {selectedFaculty !== 'ALL' && (
            <button
              onClick={() => {
                onSelectFaculty('ALL');
                onSelectBranch('ALL');
                if (onSelectCourse) onSelectCourse('ALL');
              }}
              className="text-xs text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 border border-blue-200 px-3 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Show All Faculties (सभी विभाग)
            </button>
          )}
        </div>
      </div>

      {/* Grid of All 8 KMCLU Faculties */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-4 gap-3">
        {KMCLU_FACULTIES.map((fac) => {
          const isSelected = selectedFaculty === fac.id;
          return (
            <button
              key={fac.id}
              onClick={() => {
                if (isSelected) {
                  onSelectFaculty('ALL');
                  onSelectBranch('ALL');
                  if (onSelectCourse) onSelectCourse('ALL');
                } else {
                  onSelectFaculty(fac.id);
                  onSelectBranch('ALL');
                  if (onSelectCourse) onSelectCourse('ALL');
                }
              }}
              className={`text-left p-3.5 rounded-2xl border transition-all duration-200 group flex flex-col justify-between relative overflow-hidden ${
                isSelected
                  ? 'border-blue-600 bg-white shadow-md ring-2 ring-blue-500/30'
                  : 'border-slate-200/90 bg-white hover:border-blue-300 hover:shadow-xs'
              }`}
            >
              {isSelected && (
                <div className="absolute top-0 right-0 w-12 h-12 overflow-hidden pointer-events-none">
                  <div className="bg-blue-600 text-white transform rotate-45 translate-x-3 -translate-y-1 w-12 text-center text-[9px] py-0.5 shadow-sm">
                    ✓
                  </div>
                </div>
              )}

              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
                      isSelected
                        ? `bg-gradient-to-br ${fac.color} text-white shadow-sm`
                        : 'bg-slate-100 group-hover:bg-blue-50 text-slate-700'
                    }`}
                  >
                    {getFacultyIcon(fac.icon, isSelected)}
                  </div>
                  <span className="text-[10px] font-bold text-slate-400 bg-slate-50 border border-slate-100 px-1.5 py-0.5 rounded">
                    {fac.courses.slice(0, 2).join(' • ')}
                  </span>
                </div>

                <div>
                  <h3 className={`text-xs sm:text-sm font-bold leading-tight ${isSelected ? 'text-blue-900' : 'text-slate-900'}`}>
                    {fac.name}
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">
                    {fac.description}
                  </p>
                </div>
              </div>

              <div className="pt-2.5 mt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px]">
                <span className="text-slate-500 font-medium">
                  {fac.departments.length} Departments
                </span>
                <span className="inline-flex items-center gap-0.5 font-bold text-blue-600 group-hover:translate-x-0.5 transition-transform text-[11px]">
                  <span>Explore</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Sub-Department and Degree Quick Chips when a faculty is selected */}
      {activeFacultyObj && (
        <div className="bg-gradient-to-r from-blue-50/70 via-indigo-50/50 to-slate-50 p-4 rounded-2xl border border-blue-200/80 shadow-xs space-y-3 animate-in fade-in slide-in-from-top-1">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <div className="flex items-center gap-2">
                <span className={`text-xs font-bold px-2 py-0.5 rounded-full border ${activeFacultyObj.badge}`}>
                  {activeFacultyObj.fullName}
                </span>
                <span className="text-xs text-slate-500">
                  {activeFacultyObj.description}
                </span>
              </div>
            </div>

            <button
              onClick={() => {
                onSelectFaculty('ALL');
                onSelectBranch('ALL');
                if (onSelectCourse) onSelectCourse('ALL');
              }}
              className="text-xs text-slate-500 hover:text-slate-800 font-medium underline"
            >
              Clear Faculty Filter
            </button>
          </div>

          {/* Quick Course / Degree Chips */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">
              Select Degree / Program:
            </span>
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                onClick={() => {
                  if (onSelectCourse) onSelectCourse('ALL');
                }}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition-all ${
                  selectedCourse === 'ALL'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                }`}
              >
                All {activeFacultyObj.name} Degrees
              </button>

              {activeFacultyObj.courses.map((c) => (
                <button
                  key={c}
                  onClick={() => {
                    if (onSelectCourse) onSelectCourse(c);
                  }}
                  className={`px-3 py-1 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                    selectedCourse === c
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                  }`}
                >
                  {selectedCourse === c && <Check className="w-3 h-3 text-white" />}
                  <span>{c}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Departments list in this faculty */}
          <div className="pt-2 border-t border-blue-200/50 flex flex-wrap items-center gap-2 text-xs">
            <span className="text-slate-500 font-semibold text-[11px]">Academic Departments:</span>
            {activeFacultyObj.departments.map((dept) => (
              <span
                key={dept}
                className="bg-white/80 border border-slate-200 px-2.5 py-0.5 rounded-lg text-slate-700 text-[11px] font-medium"
              >
                {dept}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState } from 'react';
import {
  GraduationCap,
  BookOpen,
  FileText,
  Upload,
  Brain,
  CheckCircle2,
  Bell,
  Bookmark,
  ShieldCheck,
  Search,
  Sparkles,
  UserCheck,
  LogOut,
  Calendar,
  Layers,
  ChevronDown,
  Menu,
  X,
  Clock,
  Trash2,
} from 'lucide-react';
import { UserProfile } from '../data/mockData';

interface NavbarProps {
  currentUser: UserProfile;
  onLogout: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenUpload: () => void;
  onOpenSearch: () => void;
  pendingCount: number;
  notifications: Array<{
    id: string;
    title: string;
    message: string;
    type: 'success' | 'danger' | 'info';
    createdAt: string;
    read?: boolean;
  }>;
  onClearNotifications: () => void;
  bookmarkedCount: number;
  onOpenBookmarks: () => void;
  onOpenAI: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  onLogout,
  activeTab,
  setActiveTab,
  onOpenUpload,
  onOpenSearch,
  pendingCount,
  notifications,
  onClearNotifications,
  bookmarkedCount,
  onOpenBookmarks,
  onOpenAI,
}) => {
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifs, setShowNotifs] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const unreadNotifs = notifications.filter((n) => !n.read).length;

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      {/* Top University Announcement Bar */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white text-xs py-1.5 px-4 font-medium flex items-center justify-between">
        <div className="flex items-center space-x-2 truncate">
          <span className="bg-amber-400 text-slate-950 font-bold px-1.5 py-0.5 rounded text-[10px] tracking-wide uppercase">
            KMCLU Lucknow
          </span>
          <span className="text-slate-200 truncate hidden sm:inline">
            Khwaja Moinuddin Chishti Language University • All Faculties & Departments Portal (सभी विभाग)
          </span>
          <span className="text-slate-200 truncate sm:hidden">
            KMCLU All Departments
          </span>
        </div>
        <div className="flex items-center space-x-3 text-[11px] shrink-0">
          <span className="flex items-center gap-1 text-emerald-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            Verified Academic Repository
          </span>
          <span className="text-slate-400 hidden md:inline">|</span>
          <button
            onClick={onOpenAI}
            className="hidden md:flex items-center gap-1 text-amber-300 hover:text-amber-200 font-semibold"
          >
            <Sparkles className="w-3.5 h-3.5" />
            AI Study Mentor
          </button>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setActiveTab('explore')}
              className="flex items-center space-x-3 text-left focus:outline-hidden"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-700 via-indigo-600 to-sky-500 p-0.5 shadow-md flex items-center justify-center text-white shrink-0">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div className="flex flex-col justify-center">
                <div className="flex items-center space-x-1.5 leading-none">
                  <span className="text-lg font-bold tracking-tight text-slate-900">
                    KMCLU <span className="text-blue-600">StudyHub</span>
                  </span>
                  <span className="bg-blue-50 text-blue-700 font-semibold text-[10px] px-1.5 py-0.5 rounded border border-blue-200 hidden sm:inline-block">
                    B.Tech
                  </span>
                </div>
                <p className="text-[10px] text-slate-500 font-medium hidden sm:block mt-0.5">
                  PYQs • Mid-Sem • Notes • Syllabus
                </p>
              </div>
            </button>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1">
            <button
              onClick={() => setActiveTab('explore')}
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center space-x-1.5 ${
                activeTab === 'explore'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Library</span>
            </button>

            <button
              onClick={() => setActiveTab('pyqs')}
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center space-x-1.5 ${
                activeTab === 'pyqs'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>PYQs</span>
            </button>

            <button
              onClick={() => setActiveTab('midsem')}
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center space-x-1.5 ${
                activeTab === 'midsem'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>Mid-Sem</span>
            </button>

            <button
              onClick={() => setActiveTab('practice')}
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center space-x-1.5 ${
                activeTab === 'practice'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Brain className="w-4 h-4 text-purple-600" />
              <span>PYQ Quiz</span>
            </button>

            <button
              onClick={() => setActiveTab('planner')}
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center space-x-1.5 ${
                activeTab === 'planner'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Calendar className="w-4 h-4" />
              <span>Planner</span>
            </button>

            {currentUser.role === 'admin' && (
              <button
                onClick={() => setActiveTab('admin')}
                className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center space-x-1.5 relative ${
                  activeTab === 'admin'
                    ? 'bg-amber-100 text-amber-900 border border-amber-300'
                    : 'text-amber-800 hover:bg-amber-50'
                }`}
              >
                <ShieldCheck className="w-4 h-4 text-amber-600" />
                <span>Admin Panel</span>
                {pendingCount > 0 && (
                  <span className="ml-1 px-1.5 py-0.2 rounded-full text-[11px] font-bold bg-amber-500 text-white animate-pulse">
                    {pendingCount}
                  </span>
                )}
              </button>
            )}

          </nav>

          {/* Right Action Icons & User Switcher */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Global Search Button */}
            <button
              onClick={onOpenSearch}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-1.5 text-xs font-medium border border-slate-200"
              title="Search documents (Cmd+K)"
            >
              <Search className="w-4 h-4" />
              <span className="hidden md:inline text-slate-500">Search</span>
              <kbd className="hidden md:inline px-1 py-0.5 text-[10px] bg-slate-100 border border-slate-300 rounded text-slate-500">
                ⌘K
              </kbd>
            </button>

            {/* AI Assistant Button */}
            <button
              onClick={onOpenAI}
              className="px-2.5 py-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs flex items-center gap-1 transition-all"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">AI Study</span>
            </button>

            {/* Upload PDF Button (Hero Call to Action) */}
            <button
              onClick={onOpenUpload}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow-xs hover:shadow-md flex items-center gap-1.5 transition-all active:scale-95"
            >
              <Upload className="w-4 h-4" />
              <span>Upload PDF</span>
            </button>

            {/* Bookmarks */}
            <button
              onClick={onOpenBookmarks}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors relative"
              title="My Bookmarks"
            >
              <Bookmark className="w-4 h-4" />
              {bookmarkedCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center">
                  {bookmarkedCount}
                </span>
              )}
            </button>

            {/* Notifications Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowNotifs(!showNotifs)}
                className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors relative"
                title="Notifications"
              >
                <Bell className="w-4 h-4" />
                {unreadNotifs > 0 && (
                  <span className="absolute top-1 right-1 w-2.5 h-2.5 rounded-full bg-rose-500 ring-2 ring-white"></span>
                )}
              </button>

              {showNotifs && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-xl shadow-xl border border-slate-200 p-3 z-50 text-slate-800">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                    <span className="font-bold text-sm text-slate-900">
                      Notifications ({notifications.length})
                    </span>
                    <button
                      onClick={onClearNotifications}
                      className="text-xs text-slate-400 hover:text-rose-600 flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      Clear all
                    </button>
                  </div>
                  <div className="mt-2 max-h-72 overflow-y-auto space-y-2">
                    {notifications.length === 0 ? (
                      <p className="text-xs text-slate-500 text-center py-6">
                        No notifications yet. You'll receive updates when your uploaded PDFs are approved or reviewed!
                      </p>
                    ) : (
                      notifications.map((n) => (
                        <div
                          key={n.id}
                          className={`p-2.5 rounded-lg border text-xs ${
                            n.type === 'success'
                              ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                              : n.type === 'danger'
                              ? 'bg-rose-50/70 border-rose-200 text-rose-900'
                              : 'bg-blue-50/70 border-blue-200 text-blue-900'
                          }`}
                        >
                          <div className="font-semibold">{n.title}</div>
                          <p className="mt-0.5 text-slate-600 leading-relaxed">
                            {n.message}
                          </p>
                          <div className="mt-1 text-[10px] text-slate-400 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(n.createdAt).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Quick Demo User Switcher */}
            <div className="relative">
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center space-x-2 pl-2 pr-1.5 py-1 rounded-lg border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-colors"
                title="Account profile"
              >
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-7 h-7 rounded-full object-cover ring-1 ring-slate-300"
                />
                <div className="text-left hidden sm:block">
                  <div className="text-xs font-bold text-slate-800 leading-tight truncate max-w-[100px]">
                    {currentUser.name}
                  </div>
                  <div className="text-[10px] text-slate-500 capitalize">
                    {currentUser.role === 'admin' ? '🛡️ Admin' : `${currentUser.branch} Sem ${currentUser.semester}`}
                  </div>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {showUserMenu && (
                <div className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-slate-200 p-2 z-50 text-slate-800">
                  <div className="p-2 border-b border-slate-100 bg-slate-50 rounded-lg mb-2">
                    <div className="flex items-center space-x-2">
                      <img
                        src={currentUser.avatar}
                        alt={currentUser.name}
                        className="w-9 h-9 rounded-full object-cover"
                      />
                      <div>
                        <div className="text-sm font-bold text-slate-900">
                          {currentUser.name}
                        </div>
                        <div className="text-xs text-slate-500">
                          {currentUser.email}
                        </div>
                        {currentUser.rollNo && (
                          <div className="text-[10px] text-blue-600 font-mono mt-0.5">
                            Roll: {currentUser.rollNo}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between px-1">
                    <button
                      onClick={() => {
                        setActiveTab('dashboard');
                        setShowUserMenu(false);
                      }}
                      className="text-xs text-blue-600 hover:underline font-semibold flex items-center gap-1"
                    >
                      <UserCheck className="w-3.5 h-3.5" />
                      My Submissions & Stats
                    </button>
                    <button
                      onClick={() => { setShowUserMenu(false); onLogout(); }}
                      className="text-xs text-rose-600 hover:underline font-semibold flex items-center gap-1"
                    >
                      <LogOut className="w-3.5 h-3.5" /> Sign out
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 lg:hidden text-slate-600 hover:text-slate-900"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-2 pb-4 space-y-1 shadow-lg">
          <button
            onClick={() => {
              setActiveTab('explore');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 rounded-md text-sm font-medium text-slate-700 hover:bg-slate-100"
          >
            Library Overview
          </button>
          <button
            onClick={() => {
              setActiveTab('pyqs');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 rounded-md text-sm font-medium text-slate-700 hover:bg-slate-100"
          >
            Previous Year Papers (PYQs)
          </button>
          <button
            onClick={() => {
              setActiveTab('midsem');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 rounded-md text-sm font-medium text-slate-700 hover:bg-slate-100"
          >
            Mid-Semester Exam Papers
          </button>
          <button
            onClick={() => {
              setActiveTab('practice');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 rounded-md text-sm font-medium text-slate-700 hover:bg-slate-100"
          >
            PYQ Practice Quiz
          </button>
          <button
            onClick={() => {
              setActiveTab('planner');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 rounded-md text-sm font-medium text-slate-700 hover:bg-slate-100"
          >
            Exam Planner & Timetable
          </button>
          <button
            onClick={() => {
              setActiveTab('dashboard');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 rounded-md text-sm font-medium text-slate-700 hover:bg-slate-100"
          >
            Student Dashboard (My Uploads)
          </button>
          {currentUser.role === 'admin' && (
          <button
            onClick={() => {
              setActiveTab('admin');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 rounded-md text-sm font-medium text-amber-800 bg-amber-50 flex items-center justify-between"
          >
            <span>Admin Control Panel</span>
            {pendingCount > 0 && (
              <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-amber-500 text-white">
                {pendingCount} Pending
              </span>
            )}
          </button>
          )}
        </div>
      )}
    </header>
  );
};

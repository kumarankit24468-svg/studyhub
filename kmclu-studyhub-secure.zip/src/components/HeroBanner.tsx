import React from 'react';
import {
  GraduationCap,
  Search,
  BookOpen,
  FileText,
  Layers,
  Sparkles,
  CheckCircle2,
  Upload,
  Building2,
  Users,
} from 'lucide-react';
import { KMCLU_FACULTIES } from '../data/mockData';

interface HeroBannerProps {
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  selectedFaculty: string;
  setSelectedFaculty: (f: string) => void;
  selectedCourse: string;
  setSelectedCourse: (c: string) => void;
  selectedBranch: string;
  setSelectedBranch: (b: string) => void;
  selectedSemester: number | 'all';
  setSelectedSemester: (s: number | 'all') => void;
  selectedType: string;
  setSelectedType: (t: any) => void;
  onOpenUpload: () => void;
  totalApproved: number;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  searchQuery,
  setSearchQuery,
  selectedFaculty,
  setSelectedFaculty,
  selectedCourse,
  setSelectedCourse,
  selectedType,
  setSelectedType,
  onOpenUpload,
  totalApproved,
}) => {
  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-blue-950 via-slate-900 to-slate-950 text-white pt-10 pb-12 px-4 sm:px-6 lg:px-8 border-b border-slate-800">
      {/* Decorative ambient background glows */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-indigo-600/15 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-6xl mx-auto space-y-6 relative z-10 text-center">
        {/* Accreditation pill */}
        <div className="inline-flex flex-wrap items-center justify-center gap-2 bg-blue-500/10 border border-blue-400/20 px-4 py-1.5 rounded-full text-xs text-blue-300 font-medium shadow-xs">
          <span className="flex items-center gap-1.5">
            <GraduationCap className="w-4 h-4 text-blue-400" />
            <span>Khwaja Moinuddin Chishti Language University, Lucknow</span>
          </span>
          <span className="text-slate-500 hidden sm:inline">•</span>
          <span className="text-emerald-300 font-semibold flex items-center gap-1">
            <Building2 className="w-3.5 h-3.5" />
            8 University Faculties & Departments
          </span>
          <span className="text-slate-500 hidden sm:inline">•</span>
          <span className="text-amber-300 font-bold">Admin Verified Repository</span>
        </div>

        {/* Hero Title */}
        <div className="space-y-2 max-w-4xl mx-auto">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-white leading-tight">
            KMCLU <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-sky-300 to-indigo-300">StudyHub</span>
          </h1>
          <p className="text-sm sm:text-base text-slate-300 font-normal leading-relaxed max-w-3xl mx-auto">
            University-wide learning repository for <strong>all KMCLU departments</strong> — Engineering (B.Tech, BCA, MCA), Commerce & Management (BBA, MBA, B.Com), Law (LL.B), Science (B.Sc, M.Sc), Languages & Humanities (Urdu, Arabic, Persian, English, Hindi), Journalism, Pharmacy & Education.
          </p>
        </div>

        {/* Global Search Bar */}
        <div className="max-w-2xl mx-auto">
          <div className="bg-white/10 backdrop-blur-md p-1.5 rounded-2xl border border-white/20 shadow-2xl flex flex-col sm:flex-row items-center gap-2">
            <div className="flex items-center px-3 w-full sm:flex-1">
              <Search className="w-5 h-5 text-blue-400 shrink-0 mr-2" />
              <input
                type="text"
                placeholder="Search across all departments by paper, code (e.g. BCS-401, MBA-101, LAW-101, BA-101)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-transparent text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-hidden py-2"
              />
            </div>

            <div className="flex items-center space-x-2 w-full sm:w-auto shrink-0 justify-end px-2">
              <button
                onClick={onOpenUpload}
                className="w-full sm:w-auto px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center justify-center gap-1.5 active:scale-95 border border-blue-400/30"
              >
                <Upload className="w-4 h-4" />
                <span>Upload PDF (All Depts)</span>
              </button>
            </div>
          </div>
        </div>

        {/* Quick Faculty Picker Strip */}
        <div className="flex flex-wrap items-center justify-center gap-1.5 max-w-4xl mx-auto pt-1">
          <span className="text-[11px] font-semibold text-slate-400 mr-1 hidden sm:inline">
            Quick Faculty:
          </span>
          <button
            onClick={() => {
              setSelectedFaculty('ALL');
              setSelectedCourse('ALL');
            }}
            className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
              selectedFaculty === 'ALL'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
            }`}
          >
            All Faculties (सभी)
          </button>
          {KMCLU_FACULTIES.map((fac) => (
            <button
              key={fac.id}
              onClick={() => {
                setSelectedFaculty(fac.id);
                setSelectedCourse('ALL');
              }}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                selectedFaculty === fac.id
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
              }`}
            >
              {fac.name}
            </button>
          ))}
        </div>

        {/* Filter Pills (Document Types) */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
          {[
            { id: 'all', label: 'All Resources', icon: BookOpen },
            { id: 'PYQ', label: 'Previous Year Papers (PYQs)', icon: FileText },
            { id: 'Mid-Sem', label: 'Mid-Semester Papers', icon: Layers },
            { id: 'Notes', label: 'Handwritten & Class Notes', icon: Sparkles },
            { id: 'Syllabus', label: 'Official Syllabus & Manuals', icon: GraduationCap },
          ].map((type) => {
            const Icon = type.icon;
            const isSelected = selectedType === type.id;
            return (
              <button
                key={type.id}
                onClick={() => setSelectedType(type.id)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
                  isSelected
                    ? 'bg-blue-600 text-white shadow-md ring-2 ring-blue-400/40'
                    : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{type.label}</span>
              </button>
            );
          })}
        </div>

        {/* Quick Highlights / Trust Badges */}
        <div className="pt-4 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-4xl mx-auto text-left">
          <div className="bg-white/5 border border-white/10 rounded-xl p-3 flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-blue-500/20 text-blue-400">
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <div>
              <div className="text-sm font-bold text-white">{totalApproved}+ Verified Papers</div>
              <div className="text-[10px] text-slate-400">100% Moderated by University</div>
            </div>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-xl p-3 flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-purple-500/20 text-purple-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="text-sm font-bold text-white">AI Study Mentor</div>
              <div className="text-[10px] text-slate-400">Answers in Hindi & English</div>
            </div>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-xl p-3 flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
              <Building2 className="w-4 h-4" />
            </div>
            <div>
              <div className="text-sm font-bold text-white">8 University Faculties</div>
              <div className="text-[10px] text-slate-400">All Depts & Degrees</div>
            </div>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-xl p-3 flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <div className="text-sm font-bold text-white">Open Student Uploads</div>
              <div className="text-[10px] text-slate-400">Moderated Quality Flow</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

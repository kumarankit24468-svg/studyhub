import React from 'react';
import {
  FileText,
  Download,
  Eye,
  Bookmark,
  Sparkles,
  Share2,
  CheckCircle,
  Clock,
  AlertTriangle,
  User,
} from 'lucide-react';
import { DocumentItem } from '../utils/studyhub-logic';

interface DocumentCardProps {
  document: DocumentItem;
  isBookmarked: boolean;
  onToggleBookmark: (docId: string) => void;
  onPreview: (doc: DocumentItem) => void;
  onDownload: (doc: DocumentItem) => void;
  onAskAI: (doc: DocumentItem) => void;
  onReport: (doc: DocumentItem) => void;
}

export const DocumentCard: React.FC<DocumentCardProps> = ({
  document,
  isBookmarked,
  onToggleBookmark,
  onPreview,
  onDownload,
  onAskAI,
  onReport,
}) => {
  const getTypeBadge = () => {
    switch (document.documentType) {
      case 'PYQ':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Mid-Sem':
        return 'bg-amber-100 text-amber-900 border-amber-200';
      case 'Notes':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Syllabus':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs hover:shadow-lg transition-all duration-200 flex flex-col justify-between overflow-hidden group">
      {/* Top Banner & Metadata */}
      <div className="p-5 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className={`px-2.5 py-0.5 rounded-md text-[11px] font-bold border ${getTypeBadge()}`}>
              {document.documentType} ({document.examYear})
            </span>
            <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-slate-100 text-slate-700">
              Sem {document.semester}
            </span>
            <span className="px-2 py-0.5 rounded-md text-[11px] font-mono font-bold text-blue-700 bg-blue-50">
              {document.subjectCode}
            </span>
          </div>

          {/* Bookmark Button */}
          <button
            onClick={() => onToggleBookmark(document.id)}
            className={`p-1.5 rounded-lg transition-colors ${
              isBookmarked
                ? 'text-amber-500 hover:text-amber-600 bg-amber-50'
                : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'
            }`}
            title={isBookmarked ? 'Remove Bookmark' : 'Bookmark PDF'}
          >
            <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
          </button>
        </div>

        {/* Title */}
        <div
          onClick={() => onPreview(document)}
          className="cursor-pointer group-hover:text-blue-600 transition-colors"
        >
          <h3 className="text-sm sm:text-base font-bold text-slate-900 leading-snug line-clamp-2">
            {document.title}
          </h3>
          <p className="text-xs text-slate-500 font-medium mt-0.5">
            {document.subject} • {document.course || 'Degree'} {document.branch ? `(${document.branch})` : ''} • <span className="text-blue-600 font-semibold">{document.facultyName || 'KMCLU'}</span>
          </p>
        </div>

        {/* Summary Snippet */}
        <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
          {document.contentSummary || 'Verified university examination material.'}
        </p>

        {/* Tags */}
        <div className="flex flex-wrap gap-1 pt-1">
          {document.tags.slice(0, 3).map((tag, i) => (
            <span
              key={i}
              className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-[10px] font-medium"
            >
              #{tag}
            </span>
          ))}
        </div>
      </div>

      {/* Card Footer */}
      <div className="bg-slate-50/80 px-5 py-3 border-t border-slate-100 flex flex-col space-y-2.5">
        <div className="flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center space-x-1.5 truncate max-w-[160px]">
            <img
              src={document.uploadedBy.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=50'}
              alt={document.uploadedBy.name}
              className="w-4 h-4 rounded-full object-cover shrink-0"
            />
            <span className="truncate text-[11px] font-medium text-slate-700">
              {document.uploadedBy.name}
            </span>
          </div>

          <div className="flex items-center space-x-2 text-[11px] text-slate-400">
            <span>{document.fileSize || '2 MB'}</span>
            <span>•</span>
            <span>{document.downloads} d/l</span>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex items-center justify-between pt-1 gap-1.5">
          <button
            onClick={() => onPreview(document)}
            className="flex-1 py-1.5 px-2 bg-white hover:bg-slate-100 text-slate-800 border border-slate-200 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition-colors shadow-2xs"
          >
            <Eye className="w-3.5 h-3.5 text-blue-600" />
            <span>Read PDF</span>
          </button>

          <button
            onClick={() => onAskAI(document)}
            className="py-1.5 px-2 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition-colors"
            title="Ask AI questions about this paper"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Ask AI</span>
          </button>

          <button
            onClick={() => onDownload(document)}
            className="py-1.5 px-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold flex items-center justify-center transition-colors shadow-2xs"
            title="Download Document"
          >
            <Download className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};

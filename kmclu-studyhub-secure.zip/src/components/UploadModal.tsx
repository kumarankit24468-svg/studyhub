import React, { useState, useId, useEffect } from 'react';
import {
  X,
  Upload,
  FileText,
  AlertCircle,
  CheckCircle,
  HelpCircle,
  ShieldAlert,
  Info,
  Clock,
  Building2,
  GraduationCap,
} from 'lucide-react';
import { KMCLU_FACULTIES, KMCLU_SUBJECTS, UserProfile } from '../data/mockData';
import { DocumentItem, detectPotentialDuplicates } from '../utils/studyhub-logic';

interface UploadModalProps {
  currentUser: UserProfile;
  existingDocuments: DocumentItem[];
  isOpen: boolean;
  onClose: () => void;
  onSubmitUpload: (newDoc: DocumentItem) => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  currentUser,
  existingDocuments,
  isOpen,
  onClose,
  onSubmitUpload,
}) => {
  if (!isOpen) return null;

  const facultyInputId = useId();
  const courseInputId = useId();
  const departmentInputId = useId();
  const branchInputId = useId();
  const semesterInputId = useId();
  const docTypeInputId = useId();
  const examYearInputId = useId();
  const subjectInputId = useId();
  const subjectCodeInputId = useId();
  const titleInputId = useId();
  const descInputId = useId();
  const tagsInputId = useId();
  const fileInputId = useId();
  const guidelinesInputId = useId();

  // State
  const [facultyId, setFacultyId] = useState<string>(currentUser.facultyId || 'FET');
  const [course, setCourse] = useState<string>(currentUser.course || 'B.Tech');
  const [department, setDepartment] = useState<string>(currentUser.department || 'Computer Science & Engineering');
  const [branch, setBranch] = useState<string>(currentUser.branch || 'General');
  const [semester, setSemester] = useState<number>(currentUser.semester > 0 ? currentUser.semester : 1);
  const [documentType, setDocumentType] = useState<'PYQ' | 'Mid-Sem' | 'Notes' | 'Syllabus'>('PYQ');
  const [examYear, setExamYear] = useState<number>(2024);
  const [subject, setSubject] = useState<string>('');
  const [subjectCode, setSubjectCode] = useState<string>('');
  const [title, setTitle] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [tags, setTags] = useState<string>('');
  const [selectedFile, setSelectedFile] = useState<{
    name: string;
    size: string;
    pageCount: number;
    dataUrl?: string;
  } | null>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [agreeGuidelines, setAgreeGuidelines] = useState<boolean>(true);
  const [errorMsg, setErrorMsg] = useState<string>('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  // Selected faculty info
  const selectedFacultyObj = KMCLU_FACULTIES.find((f) => f.id === facultyId) || KMCLU_FACULTIES[0];

  // When faculty changes, update course and department defaults
  const handleFacultyChange = (newFacultyId: string) => {
    setFacultyId(newFacultyId);
    const fac = KMCLU_FACULTIES.find((f) => f.id === newFacultyId);
    if (fac) {
      setCourse(fac.courses[0] || 'Degree');
      setDepartment(fac.departments[0] || 'General');
      setSubject('');
      setSubjectCode('');
    }
  };

  // Filter available subjects based on selected faculty and course
  const availableSubjects = KMCLU_SUBJECTS.filter(
    (s) => s.facultyId === facultyId && (course === 'ALL' || s.course === course)
  );

  const handleSubjectSelect = (subName: string) => {
    setSubject(subName);
    const found = KMCLU_SUBJECTS.find((s) => s.name === subName);
    if (found) {
      setSubjectCode(found.code);
      if (found.department) setDepartment(found.department);
      if (found.course) setCourse(found.course);
      if (found.branch) setBranch(found.branch);
      if (!title) {
        setTitle(`${found.name} ${course} ${documentType} Paper (${examYear})`);
      }
    }
  };

  // Real-time duplicate check
  const duplicateCheck = detectPotentialDuplicates(
    {
      facultyId,
      course,
      subject: subject || undefined,
      semester,
      documentType,
      examYear,
      title: title || undefined,
    },
    existingDocuments
  );

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const processFile = (file: File) => {
    if (file.size > 25 * 1024 * 1024) {
      setErrorMsg('File exceeds 25MB university upload limit. Please compress the PDF.');
      return;
    }
    setErrorMsg('');
    const sizeInMb = (file.size / (1024 * 1024)).toFixed(1) + ' MB';
    const estPages = Math.max(1, Math.min(60, Math.ceil(file.size / 700000)));

    setSelectedFile({
      name: file.name,
      size: sizeInMb,
      pageCount: estPages,
    });

    if (!title) {
      const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
      setTitle(cleanName);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !subject.trim() || !subjectCode.trim()) {
      setErrorMsg('Please complete required fields: Title, Subject, and Course Code.');
      return;
    }
    if (!agreeGuidelines) {
      setErrorMsg('Please agree to the university honor code and sharing guidelines.');
      return;
    }

    const tagList = tags
      ? tags.split(',').map((t) => t.trim()).filter(Boolean)
      : [subjectCode, course, facultyId, `Sem-${semester}`, documentType];

    const newDoc: DocumentItem = {
      id: 'doc-upload-' + Date.now().toString(36),
      title: title.trim(),
      facultyId,
      facultyName: selectedFacultyObj.name,
      department,
      course,
      branch: branch || 'General',
      semester: Number(semester),
      subject: subject.trim(),
      subjectCode: subjectCode.trim().toUpperCase(),
      documentType,
      examYear: Number(examYear),
      uploadedBy: {
        id: currentUser.id,
        name: currentUser.name,
        rollNo: currentUser.rollNo,
        faculty: selectedFacultyObj.name,
        course,
        avatar: currentUser.avatar,
      },
      fileSize: selectedFile?.size || '2.2 MB',
      pageCount: selectedFile?.pageCount || 3,
      status: 'pending', // IMPORTANT: Pending admin verification
      createdAt: new Date().toISOString(),
      downloads: 0,
      views: 1,
      tags: tagList,
      contentSummary: description.trim() || `Uploaded by student ${currentUser.name} for ${course} (${department}) Semester ${semester}. Pending university admin verification.`,
      sampleQuestions: [
        `Question 1: Foundational principles of ${subject}.`,
        `Question 2: Detailed analytical and theoretical derivation.`,
        `Question 3: Practical application and case study analysis.`
      ],
    };

    onSubmitUpload(newDoc);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-purple-800 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-xl bg-white/10 text-white">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold">Upload Academic Document (All KMCLU Departments)</h2>
              <p className="text-xs text-blue-100">
                Engineering • Commerce • Management • Law • Science • Humanities • Media • Pharmacy
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-blue-200 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notice banner */}
        <div className="bg-amber-50 border-b border-amber-200 px-6 py-2.5 flex items-start space-x-2 text-xs text-amber-900">
          <Clock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold">Moderation Notice: </span>
            Students from all KMCLU departments can submit study materials. Uploaded documents remain in <strong>Pending</strong> status until verified by University Admin.
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {errorMsg && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Row 1: Faculty & Course */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor={facultyInputId} className="block text-xs font-bold text-slate-700 mb-1">
                University Faculty / School <span className="text-rose-500">*</span>
              </label>
              <select
                id={facultyInputId}
                value={facultyId}
                onChange={(e) => handleFacultyChange(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-medium text-slate-800 focus:bg-white focus:outline-hidden focus:border-blue-500"
              >
                {KMCLU_FACULTIES.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor={courseInputId} className="block text-xs font-bold text-slate-700 mb-1">
                Degree / Course <span className="text-rose-500">*</span>
              </label>
              <select
                id={courseInputId}
                value={course}
                onChange={(e) => setCourse(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-medium text-slate-800 focus:bg-white focus:outline-hidden focus:border-blue-500"
              >
                {selectedFacultyObj.courses.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Row 2: Department & Semester */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label htmlFor={departmentInputId} className="block text-xs font-bold text-slate-700 mb-1">
                Department / Field of Study <span className="text-rose-500">*</span>
              </label>
              <select
                id={departmentInputId}
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-medium text-slate-800 focus:bg-white focus:outline-hidden focus:border-blue-500"
              >
                {selectedFacultyObj.departments.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor={semesterInputId} className="block text-xs font-bold text-slate-700 mb-1">
                Semester / Year <span className="text-rose-500">*</span>
              </label>
              <select
                id={semesterInputId}
                value={semester}
                onChange={(e) => setSemester(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-medium text-slate-800 focus:bg-white focus:outline-hidden focus:border-blue-500"
              >
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((s) => (
                  <option key={s} value={s}>
                    Semester {s}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Row 3: Document Type & Exam Year */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor={docTypeInputId} className="block text-xs font-bold text-slate-700 mb-1">
                Document Type <span className="text-rose-500">*</span>
              </label>
              <select
                id={docTypeInputId}
                value={documentType}
                onChange={(e) => setDocumentType(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-medium text-slate-800 focus:bg-white focus:outline-hidden focus:border-blue-500"
              >
                <option value="PYQ">Previous Year Question Paper (PYQ)</option>
                <option value="Mid-Sem">Mid-Semester Exam Paper</option>
                <option value="Notes">Lecture Notes / Handwritten Slides</option>
                <option value="Syllabus">Official Syllabus / Lab Manual</option>
              </select>
            </div>

            <div>
              <label htmlFor={examYearInputId} className="block text-xs font-bold text-slate-700 mb-1">
                Academic Year <span className="text-rose-500">*</span>
              </label>
              <select
                id={examYearInputId}
                value={examYear}
                onChange={(e) => setExamYear(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-medium text-slate-800 focus:bg-white focus:outline-hidden focus:border-blue-500"
              >
                {[2025, 2024, 2023, 2022, 2021, 2020].map((y) => (
                  <option key={y} value={y}>
                    Year {y}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Subject Autocomplete / Selection */}
          <div>
            <label htmlFor={subjectInputId} className="block text-xs font-bold text-slate-700 mb-1">
              Subject Name <span className="text-rose-500">*</span>
            </label>
            <input
              id={subjectInputId}
              type="text"
              list="all-dept-subject-datalist"
              placeholder="e.g. Financial Management, Constitutional Law, Real Analysis, Operating Systems..."
              value={subject}
              onChange={(e) => handleSubjectSelect(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-medium text-slate-800 focus:bg-white focus:outline-hidden focus:border-blue-500"
            />
            <datalist id="all-dept-subject-datalist">
              {availableSubjects.map((s) => (
                <option key={s.code} value={s.name}>
                  {s.code} - {s.name} ({s.course})
                </option>
              ))}
            </datalist>
            {availableSubjects.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-2">
                <span className="text-[11px] text-slate-500 font-medium">Suggestions for {course}:</span>
                {availableSubjects.slice(0, 4).map((s) => (
                  <button
                    key={s.code}
                    type="button"
                    onClick={() => handleSubjectSelect(s.name)}
                    className="text-[10px] bg-slate-100 hover:bg-blue-50 hover:text-blue-700 px-2 py-0.5 rounded border border-slate-200 transition-colors"
                  >
                    {s.code} ({s.name})
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Subject Code & Document Title */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label htmlFor={subjectCodeInputId} className="block text-xs font-bold text-slate-700 mb-1">
                Course Code <span className="text-rose-500">*</span>
              </label>
              <input
                id={subjectCodeInputId}
                type="text"
                placeholder="e.g. MBA-101, LAW-101, BCS-401"
                value={subjectCode}
                onChange={(e) => setSubjectCode(e.target.value.toUpperCase())}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-mono font-semibold text-slate-800 focus:bg-white focus:outline-hidden focus:border-blue-500"
              />
            </div>
            <div className="sm:col-span-2">
              <label htmlFor={titleInputId} className="block text-xs font-bold text-slate-700 mb-1">
                Document Title <span className="text-rose-500">*</span>
              </label>
              <input
                id={titleInputId}
                type="text"
                placeholder="e.g. Constitutional Law End-Semester Paper 2024"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs font-medium text-slate-800 focus:bg-white focus:outline-hidden focus:border-blue-500"
              />
            </div>
          </div>

          {/* Duplicate Warning Alert */}
          {duplicateCheck.isDuplicateCandidate && (
            <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl text-amber-900 text-xs flex items-start gap-2.5">
              <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Potential Duplicate Detected! </span>
                {duplicateCheck.reason}
                <div className="mt-1 text-[11px] text-amber-700">
                  Please verify that your upload is not an exact copy of the existing document to avoid rejection.
                </div>
              </div>
            </div>
          )}

          {/* File Upload Area */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Select or Drop PDF File <span className="text-rose-500">*</span>
            </label>
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-5 text-center transition-colors ${
                isDragging
                  ? 'border-blue-500 bg-blue-50/50'
                  : 'border-slate-300 hover:border-slate-400 bg-slate-50/50'
              }`}
            >
              <input
                id={fileInputId}
                type="file"
                accept=".pdf,application/pdf"
                onChange={handleFileChange}
                className="hidden"
              />
              <label htmlFor={fileInputId} className="cursor-pointer">
                {selectedFile ? (
                  <div className="flex items-center justify-center space-x-3 text-left">
                    <div className="p-2.5 rounded-lg bg-emerald-100 text-emerald-700">
                      <FileText className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-800">
                        {selectedFile.name}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {selectedFile.size} • Approx {selectedFile.pageCount} pages
                      </div>
                      <span className="text-[11px] text-blue-600 font-semibold underline mt-0.5 inline-block">
                        Click to replace file
                      </span>
                    </div>
                  </div>
                ) : (
                  <div>
                    <Upload className="w-8 h-8 text-blue-500 mx-auto mb-1.5" />
                    <span className="text-xs font-bold text-slate-700 block">
                      Click to choose PDF or drag & drop here
                    </span>
                    <span className="text-[11px] text-slate-400 block mt-0.5">
                      Max file size: 25MB • Clean, readable university exam scan or notes
                    </span>
                  </div>
                )}
              </label>
            </div>
          </div>

          {/* Description & Tags */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor={descInputId} className="block text-xs font-bold text-slate-700 mb-1">
                Summary / Topics Covered
              </label>
              <textarea
                id={descInputId}
                rows={2}
                placeholder="Mention units covered or key exam topics..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:bg-white focus:outline-hidden focus:border-blue-500"
              />
            </div>
            <div>
              <label htmlFor={tagsInputId} className="block text-xs font-bold text-slate-700 mb-1">
                Search Tags (comma-separated)
              </label>
              <textarea
                id={tagsInputId}
                rows={2}
                placeholder="e.g. End-Sem, Section B, Unit 1, Topper Notes"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:bg-white focus:outline-hidden focus:border-blue-500"
              />
            </div>
          </div>

          {/* Guidelines checkbox */}
          <div className="flex items-start space-x-2 pt-2">
            <input
              type="checkbox"
              id={guidelinesInputId}
              checked={agreeGuidelines}
              onChange={(e) => setAgreeGuidelines(e.target.checked)}
              className="mt-0.5 rounded text-blue-600 focus:ring-blue-500"
            />
            <label htmlFor={guidelinesInputId} className="text-xs text-slate-600 leading-normal">
              I confirm that this document belongs to KMCLU academic curriculum, is clearly legible, and does not violate copyright guidelines.
            </label>
          </div>

          {/* Form Actions */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
            >
              Cancel
            </button>

            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md hover:shadow-lg flex items-center gap-1.5 transition-all"
            >
              <Upload className="w-4 h-4" />
              <span>Submit for Admin Approval</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

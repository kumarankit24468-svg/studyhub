import React, { useState, useEffect } from 'react';
import { Search, X, FileText, ArrowRight, BookOpen, Layers } from 'lucide-react';
import { DocumentItem } from '../utils/studyhub-logic';

interface QuickSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  documents: DocumentItem[];
  onSelectDoc: (doc: DocumentItem) => void;
}

export const QuickSearchModal: React.FC<QuickSearchModalProps> = ({
  isOpen,
  onClose,
  documents,
  onSelectDoc,
}) => {
  if (!isOpen) return null;

  const [query, setQuery] = useState('');

  const filtered = documents.filter((d) => {
    if (d.status !== 'approved') return false;
    if (!query.trim()) return true;
    const q = query.toLowerCase();
    return (
      d.title.toLowerCase().includes(q) ||
      d.subject.toLowerCase().includes(q) ||
      d.subjectCode.toLowerCase().includes(q) ||
      d.branch.toLowerCase().includes(q) ||
      (d.course && d.course.toLowerCase().includes(q)) ||
      (d.department && d.department.toLowerCase().includes(q)) ||
      (d.facultyName && d.facultyName.toLowerCase().includes(q)) ||
      d.tags.some((t) => t.toLowerCase().includes(q))
    );
  }).slice(0, 8);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-start justify-center pt-16 p-4">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden animate-in fade-in zoom-in-95">
        {/* Search Input */}
        <div className="p-3.5 border-b border-slate-200 flex items-center space-x-3">
          <Search className="w-5 h-5 text-blue-600 shrink-0" />
          <input
            type="text"
            autoFocus
            placeholder="Search across all KMCLU departments by paper, code (e.g. BCS-501, MBA-101, LAW-101)..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full text-sm text-slate-800 placeholder-slate-400 focus:outline-hidden"
          />
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results */}
        <div className="max-h-96 overflow-y-auto p-2 divide-y divide-slate-100 text-xs">
          {filtered.length === 0 ? (
            <div className="p-8 text-center text-slate-500">
              No matching verified papers or notes found for "{query}".
            </div>
          ) : (
            filtered.map((doc) => (
              <button
                key={doc.id}
                onClick={() => {
                  onSelectDoc(doc);
                  onClose();
                }}
                className="w-full text-left p-3 rounded-xl hover:bg-blue-50/70 transition-colors flex items-center justify-between group"
              >
                <div className="space-y-0.5 truncate pr-2">
                  <div className="flex items-center space-x-2">
                    <span className="font-mono text-[10px] font-bold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">
                      {doc.subjectCode}
                    </span>
                    <span className="text-[10px] text-slate-500 font-medium">
                      {doc.course || 'Degree'} {doc.branch ? `(${doc.branch})` : ''} • Sem {doc.semester}
                    </span>
                    <span className="text-[10px] font-semibold text-slate-700">
                      {doc.documentType} ({doc.examYear})
                    </span>
                  </div>
                  <div className="text-sm font-bold text-slate-900 truncate group-hover:text-blue-700">
                    {doc.title}
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-blue-600 group-hover:translate-x-0.5 transition-all shrink-0" />
              </button>
            ))
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="bg-slate-50 px-4 py-2 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-400">
          <span>Search KMCLU Library Repository</span>
          <span>Press ESC to close</span>
        </div>
      </div>
    </div>
  );
};

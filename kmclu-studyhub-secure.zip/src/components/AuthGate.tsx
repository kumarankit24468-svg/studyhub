import React, { useEffect, useState } from 'react';
import { GraduationCap, ShieldCheck, UserRound, LogIn, UserPlus, LoaderCircle, AlertCircle } from 'lucide-react';
import type { UserProfile } from '../data/mockData';

type AuthUser = UserProfile & { createdAt?: string; lastLoginAt?: string };
type AuthGateProps = { children: (user: AuthUser, logout: () => Promise<void>) => React.ReactNode };

export const AuthGate: React.FC<AuthGateProps> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [ready, setReady] = useState(false);
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let alive = true;
    fetch('/api/auth/me', { credentials: 'same-origin' })
      .then(async r => r.ok ? r.json() : null)
      .then(data => { if (alive && data?.user) setUser(data.user as AuthUser); })
      .catch(() => {})
      .finally(() => { if (alive) setReady(true); });
    return () => { alive = false; };
  }, []);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault(); setError(''); setBusy(true);
    try {
      const response = await fetch(mode === 'login' ? '/api/auth/login' : '/api/auth/register', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin',
        body: JSON.stringify(mode === 'login' ? { email, password } : { name, email, password }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Authentication failed.');
      setUser(data.user as AuthUser);
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not connect to the server.'); }
    finally { setBusy(false); }
  };

  const logout = async () => {
    try { await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' }); }
    finally { setUser(null); setPassword(''); setMode('login'); }
  };

  if (user) return <>{children(user, logout)}</>;
  if (!ready) return <div className="min-h-screen grid place-items-center bg-slate-950 text-white"><LoaderCircle className="animate-spin w-8 h-8" /><span className="sr-only">Loading session</span></div>;

  return <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-blue-950 flex items-center justify-center p-4">
    <div className="w-full max-w-md overflow-hidden rounded-3xl border border-white/10 bg-white shadow-2xl">
      <div className="bg-gradient-to-r from-blue-800 to-indigo-800 px-8 py-7 text-white">
        <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-white/15"><GraduationCap className="h-7 w-7" /></div>
        <p className="text-xs font-bold uppercase tracking-[0.2em] text-blue-200">KMCLU Lucknow</p>
        <h1 className="mt-1 text-2xl font-extrabold">StudyHub</h1>
        <p className="mt-2 text-sm text-blue-100">Sign in to access the academic library.</p>
      </div>
      <form onSubmit={submit} className="space-y-4 p-8">
        <div className="grid grid-cols-2 gap-2 rounded-xl bg-slate-100 p-1">
          <button type="button" onClick={() => { setMode('login'); setError(''); }} className={`rounded-lg py-2 text-sm font-bold ${mode === 'login' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-500'}`}><LogIn className="mr-1 inline h-4 w-4" /> Login</button>
          <button type="button" onClick={() => { setMode('register'); setError(''); }} className={`rounded-lg py-2 text-sm font-bold ${mode === 'register' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-500'}`}><UserPlus className="mr-1 inline h-4 w-4" /> Student Sign Up</button>
        </div>
        {mode === 'register' && <label className="block text-sm font-semibold text-slate-700">Full name<input required minLength={2} maxLength={80} value={name} onChange={e => setName(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2.5 font-normal outline-none focus:border-blue-500" placeholder="Your full name" /></label>}
        <label className="block text-sm font-semibold text-slate-700">Email<input required type="email" autoComplete="username" value={email} onChange={e => setEmail(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2.5 font-normal outline-none focus:border-blue-500" placeholder="you@example.com" /></label>
        <label className="block text-sm font-semibold text-slate-700">Password<input required type="password" minLength={12} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} value={password} onChange={e => setPassword(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2.5 font-normal outline-none focus:border-blue-500" placeholder="At least 12 characters" /></label>
        {error && <div role="alert" className="flex items-start gap-2 rounded-xl bg-rose-50 p-3 text-sm text-rose-700"><AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />{error}</div>}
        <button disabled={busy} className="w-full rounded-xl bg-blue-700 py-3 font-bold text-white shadow-lg hover:bg-blue-800 disabled:opacity-60">{busy ? 'Please wait…' : mode === 'login' ? 'Secure Login' : 'Create Student Account'}</button>
        <div className="flex items-start gap-2 rounded-xl bg-slate-50 p-3 text-xs leading-5 text-slate-500"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" /><span>Admin accounts cannot be created from this form. The administrator account is configured privately by the server owner.</span></div>
      </form>
    </div>
  </div>;
};

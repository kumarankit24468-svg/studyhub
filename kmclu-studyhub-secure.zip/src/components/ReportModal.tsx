import React, { useState } from 'react';
import { AlertTriangle, X, CheckCircle, ShieldAlert } from 'lucide-react';
import { DocumentItem } from '../utils/studyhub-logic';

interface ReportModalProps {
  document: DocumentItem | null;
  isOpen: boolean;
  onClose: () => void;
  onSubmitReport: (docId: string, reason: string) => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  document,
  isOpen,
  onClose,
  onSubmitReport,
}) => {
  if (!isOpen || !document) return null;

  const [reasonCategory, setReasonCategory] = useState('Blurry or illegible scan');
  const [details, setDetails] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalReason = details.trim()
      ? `${reasonCategory} — ${details.trim()}`
      : reasonCategory;
    onSubmitReport(document.id, finalReason);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95">
        <div className="bg-rose-600 text-white p-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5" />
            <h3 className="font-bold text-sm">Report Academic Document</h3>
          </div>
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="p-8 text-center space-y-2">
            <CheckCircle className="w-10 h-10 text-emerald-500 mx-auto" />
            <h4 className="text-sm font-bold text-slate-800">Report Submitted</h4>
            <p className="text-xs text-slate-500">
              The KMCLU moderation team will review this document promptly.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
            <div>
              <span className="text-slate-500 block">Flagging Document:</span>
              <span className="font-bold text-slate-800 text-sm block mt-0.5 truncate">
                {document.title}
              </span>
              <span className="text-[11px] font-mono text-blue-600">
                {document.subjectCode} • {document.branch} Sem {document.semester}
              </span>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Select Grievance Category:
              </label>
              <select
                value={reasonCategory}
                onChange={(e) => setReasonCategory(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs text-slate-800 focus:bg-white focus:outline-hidden focus:border-rose-500 font-medium"
              >
                <option value="Blurry or illegible scan">Blurry, cut-off, or unreadable scan</option>
                <option value="Wrong subject or semester mapping">Wrong subject code or syllabus mismatch</option>
                <option value="Duplicate document">Duplicate of an existing verified paper</option>
                <option value="Missing pages or incomplete answers">Incomplete paper / missing sections</option>
                <option value="Inappropriate or copyright-infringing content">Copyright or commercial watermark</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Additional Description (Optional):
              </label>
              <textarea
                rows={3}
                placeholder="Describe which pages or questions have issues..."
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs text-slate-800 focus:bg-white focus:outline-hidden focus:border-rose-500"
              />
            </div>

            <div className="pt-2 flex justify-end space-x-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3 py-1.5 rounded-lg text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold"
              >
                Submit Report to Admin
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  ShieldCheck,
  Clock,
  CheckCircle2,
  XCircle,
  FileText,
  AlertTriangle,
  Users,
  BarChart3,
  History,
  FolderOpen,
  Search,
  Eye,
  Trash2,
  Check,
  Ban,
  ArrowUpRight,
  Filter,
  Layers,
  Sparkles,
  Award,
  AlertCircle,
  BookOpen,
} from 'lucide-react';
import { DocumentItem, calculateAcademicStats } from '../utils/studyhub-logic';
import { UserProfile, BRANCHES, KMCLU_FACULTIES } from '../data/mockData';

interface AdminPanelProps {
  currentUser: UserProfile;
  documents: DocumentItem[];
  users: UserProfile[];
  reports: Array<{
    id: string;
    documentId: string;
    documentTitle: string;
    reportedBy: string;
    reason: string;
    createdAt: string;
    status: 'open' | 'resolved';
  }>;
  auditLogs: Array<{
    id: string;
    adminName: string;
    adminId: string;
    action: string;
    documentTitle: string;
    timestamp: string;
    details: string;
  }>;
  onApprove: (doc: DocumentItem) => void;
  onReject: (doc: DocumentItem, reason: string) => void;
  onDeleteDocument: (docId: string) => void;
  onToggleSuspendUser: (userId: string) => void;
  onPreviewDoc: (doc: DocumentItem) => void;
  onDismissReport: (reportId: string) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  currentUser,
  documents,
  users,
  reports,
  auditLogs,
  onApprove,
  onReject,
  onDeleteDocument,
  onToggleSuspendUser,
  onPreviewDoc,
  onDismissReport,
}) => {
  const [activeTab, setActiveTab] = useState<'pending' | 'library' | 'users' | 'reports' | 'analytics' | 'audit'>('pending');
  const [selectedPendingDoc, setSelectedPendingDoc] = useState<DocumentItem | null>(null);
  const [rejectionModalOpen, setRejectionModalOpen] = useState(false);
  const [rejectionDoc, setRejectionDoc] = useState<DocumentItem | null>(null);
  const [rejectionReason, setRejectionReason] = useState('Document scan is blurry or unreadable.');
  const [customRejectionText, setCustomRejectionText] = useState('');
  const [libraryFilter, setLibraryFilter] = useState('');
  const [branchFilter, setBranchFilter] = useState('ALL');

  const pendingDocs = documents.filter((d) => d.status === 'pending');
  const approvedDocs = documents.filter((d) => d.status === 'approved');
  const rejectedDocs = documents.filter((d) => d.status === 'rejected');

  const stats = calculateAcademicStats(documents);

  const openRejectDialog = (doc: DocumentItem) => {
    setRejectionDoc(doc);
    setRejectionReason('Document scan is blurry or unreadable.');
    setCustomRejectionText('');
    setRejectionModalOpen(true);
  };

  const confirmRejection = () => {
    if (!rejectionDoc) return;
    const finalReason = customRejectionText.trim()
      ? `${rejectionReason} — ${customRejectionText.trim()}`
      : rejectionReason;
    onReject(rejectionDoc, finalReason);
    setRejectionModalOpen(false);
    setRejectionDoc(null);
  };

  const filteredLibraryDocs = approvedDocs.filter((d) => {
    const matchBranch = branchFilter === 'ALL' || d.branch === branchFilter;
    const matchSearch =
      d.title.toLowerCase().includes(libraryFilter.toLowerCase()) ||
      d.subject.toLowerCase().includes(libraryFilter.toLowerCase()) ||
      d.subjectCode.toLowerCase().includes(libraryFilter.toLowerCase());
    return matchBranch && matchSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Admin Header with Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-6 text-white shadow-xl border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="bg-amber-400 text-slate-950 font-bold px-2 py-0.5 rounded text-xs uppercase tracking-wide">
              Official Administration
            </span>
            <span className="text-xs text-slate-400">
              Khwaja Moinuddin Chishti Language University
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold mt-1 text-white">
            Academic Moderation & Control Panel
          </h1>
          <p className="text-xs text-slate-300 mt-1">
            Logged in as <span className="font-semibold text-amber-300">{currentUser.name}</span> ({currentUser.designation || 'Chief Academic Moderator'})
          </p>
        </div>

        {/* Quick pending badge banner */}
        <div className="flex items-center space-x-3 bg-white/5 border border-white/10 rounded-xl p-3 shrink-0">
          <div className="p-2.5 rounded-lg bg-amber-500/20 text-amber-400">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <div className="text-2xl font-bold text-amber-300">{pendingDocs.length}</div>
            <div className="text-[11px] text-slate-400 font-medium">Pending Verifications</div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center space-x-1 border-b border-slate-200 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('pending')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 shrink-0 ${
            activeTab === 'pending'
              ? 'bg-amber-500 text-white shadow-md'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>Pending Queue</span>
          {pendingDocs.length > 0 && (
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-white text-amber-900">
              {pendingDocs.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('library')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 shrink-0 ${
            activeTab === 'library'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <FolderOpen className="w-4 h-4" />
          <span>Manage Library ({approvedDocs.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 shrink-0 ${
            activeTab === 'users'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Users ({users.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('reports')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 shrink-0 ${
            activeTab === 'reports'
              ? 'bg-rose-600 text-white shadow-md'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <AlertTriangle className="w-4 h-4" />
          <span>Flagged Reports ({reports.filter((r) => r.status === 'open').length})</span>
        </button>

        <button
          onClick={() => setActiveTab('analytics')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 shrink-0 ${
            activeTab === 'analytics'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Analytics</span>
        </button>

        <button
          onClick={() => setActiveTab('audit')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 shrink-0 ${
            activeTab === 'audit'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Audit Log ({auditLogs.length})</span>
        </button>
      </div>

      {/* TAB 1: PENDING QUEUE */}
      {activeTab === 'pending' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
              Submissions Awaiting Verification ({pendingDocs.length})
            </h2>
            <p className="text-xs text-slate-500">
              Preview content and verify syllabus accuracy before publishing to students.
            </p>
          </div>

          {pendingDocs.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-800">Queue is Clear!</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
                All submitted papers and notes have been reviewed. New student uploads will appear here in real-time.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {pendingDocs.map((doc) => (
                <div
                  key={doc.id}
                  className="bg-white rounded-xl border border-amber-200/80 shadow-xs hover:shadow-md p-5 transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
                >
                  <div className="space-y-1.5 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200">
                        {doc.documentType} ({doc.examYear})
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-900">
                        {doc.course || 'Degree'} {doc.branch ? `(${doc.branch})` : ''} • Sem {doc.semester}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-100 text-purple-900 border border-purple-200">
                        {doc.facultyName || 'Faculty'}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-slate-100 text-slate-800">
                        {doc.subjectCode}
                      </span>
                      <span className="text-xs text-slate-400">
                        Uploaded {new Date(doc.createdAt).toLocaleDateString()}
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-slate-900">
                      {doc.title}
                    </h3>
                    <p className="text-xs text-slate-600 line-clamp-2">
                      {doc.contentSummary || 'No summary provided by student.'}
                    </p>

                    <div className="flex items-center space-x-3 text-xs text-slate-500 pt-1">
                      <div className="flex items-center space-x-1.5">
                        <img
                          src={doc.uploadedBy.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=50'}
                          alt={doc.uploadedBy.name}
                          className="w-5 h-5 rounded-full object-cover"
                        />
                        <span className="font-medium text-slate-700">
                          {doc.uploadedBy.name}
                        </span>
                        {doc.uploadedBy.rollNo && (
                          <span className="text-[10px] font-mono text-slate-400">
                            ({doc.uploadedBy.rollNo})
                          </span>
                        )}
                      </div>
                      <span>•</span>
                      <span>Est. {doc.pageCount || 2} Pages ({doc.fileSize || '2 MB'})</span>
                    </div>
                  </div>

                  {/* Moderation Controls */}
                  <div className="flex items-center space-x-2 shrink-0 w-full md:w-auto pt-2 md:pt-0 border-t md:border-t-0 border-slate-100">
                    <button
                      onClick={() => onPreviewDoc(doc)}
                      className="px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1 transition-colors"
                      title="Inspect paper content"
                    >
                      <Eye className="w-4 h-4 text-slate-600" />
                      <span>Preview</span>
                    </button>

                    <button
                      onClick={() => openRejectDialog(doc)}
                      className="px-3.5 py-2 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold flex items-center gap-1 transition-colors"
                    >
                      <XCircle className="w-4 h-4 text-rose-600" />
                      <span>Reject</span>
                    </button>

                    <button
                      onClick={() => onApprove(doc)}
                      className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs hover:shadow-md flex items-center gap-1.5 transition-all"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Approve & Publish</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: MANAGE LIBRARY */}
      {activeTab === 'library' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center space-x-3 flex-1 min-w-[240px]">
              <Search className="w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search approved documents by title, subject or code..."
                value={libraryFilter}
                onChange={(e) => setLibraryFilter(e.target.value)}
                className="w-full text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden"
              />
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-xs text-slate-500 font-medium">Branch:</span>
              <select
                value={branchFilter}
                onChange={(e) => setBranchFilter(e.target.value)}
                className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 font-medium"
              >
                <option value="ALL">All Branches</option>
                {BRANCHES.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.id}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200 uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="p-3">Document Title</th>
                  <th className="p-3">Branch & Sem</th>
                  <th className="p-3">Type / Year</th>
                  <th className="p-3">Downloads</th>
                  <th className="p-3">Uploaded By</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredLibraryDocs.map((doc) => (
                  <tr key={doc.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3 font-semibold text-slate-800 max-w-xs truncate">
                      <div className="truncate">{doc.title}</div>
                      <div className="text-[10px] text-blue-600 font-mono">{doc.subjectCode}</div>
                    </td>
                    <td className="p-3 text-slate-600">
                      {doc.branch} • Sem {doc.semester}
                    </td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded font-bold bg-blue-50 text-blue-700">
                        {doc.documentType} ({doc.examYear})
                      </span>
                    </td>
                    <td className="p-3 text-slate-600 font-mono">
                      {doc.downloads}
                    </td>
                    <td className="p-3 text-slate-600 truncate max-w-[120px]">
                      {doc.uploadedBy.name}
                    </td>
                    <td className="p-3 text-right space-x-2">
                      <button
                        onClick={() => onPreviewDoc(doc)}
                        className="p-1.5 text-slate-500 hover:text-blue-600 rounded hover:bg-slate-100"
                        title="View"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onDeleteDocument(doc.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded hover:bg-slate-100"
                        title="Delete Document"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: USER MANAGEMENT */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200 uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="p-3">Student Name</th>
                  <th className="p-3">Email & Roll No</th>
                  <th className="p-3">Branch / Sem</th>
                  <th className="p-3">Role</th>
                  <th className="p-3">Uploads</th>
                  <th className="p-3">Reputation</th>
                  <th className="p-3 text-right">Moderation Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3">
                      <div className="flex items-center space-x-2">
                        <img
                          src={u.avatar}
                          alt={u.name}
                          className="w-7 h-7 rounded-full object-cover"
                        />
                        <span className="font-bold text-slate-800">{u.name}</span>
                      </div>
                    </td>
                    <td className="p-3 text-slate-600 font-mono text-[11px]">
                      <div>{u.email}</div>
                      {u.rollNo && <div className="text-slate-400">{u.rollNo}</div>}
                    </td>
                    <td className="p-3 text-slate-600">
                      {u.role === 'admin' ? 'University FET' : `${u.branch} Sem ${u.semester}`}
                    </td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          u.role === 'admin'
                            ? 'bg-amber-100 text-amber-900 border border-amber-300'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {u.role.toUpperCase()}
                      </span>
                    </td>
                    <td className="p-3 text-slate-700 font-medium">
                      {u.uploadsCount} ({u.approvedCount} Approved)
                    </td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 font-bold">
                        {u.reputationPoints} pts
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      {u.role !== 'admin' && (
                        <button
                          onClick={() => onToggleSuspendUser(u.id)}
                          className={`px-2.5 py-1 rounded text-[11px] font-bold transition-colors ${
                            u.isSuspended
                              ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-300'
                              : 'bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-300'
                          }`}
                        >
                          {u.isSuspended ? 'Reactivate Student' : 'Suspend User'}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: FLAGGED REPORTS */}
      {activeTab === 'reports' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-800">
              Student Grievances & Content Reports
            </h2>
            <span className="text-xs text-slate-500">
              Review reports regarding incorrect questions, copyright, or unreadable scans.
            </span>
          </div>

          {reports.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-800">No Open Reports</h3>
              <p className="text-xs text-slate-500 mt-1">
                No students have flagged materials as incorrect or inappropriate.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {reports.map((r) => (
                <div
                  key={r.id}
                  className="bg-white p-4 rounded-xl border border-rose-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800">
                        Flagged Issue
                      </span>
                      <span className="text-xs text-slate-400">
                        {new Date(r.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-slate-900">
                      {r.documentTitle}
                    </h4>
                    <p className="text-xs text-rose-700 bg-rose-50/50 p-2 rounded border border-rose-100">
                      <span className="font-bold">Reason: </span>
                      {r.reason}
                    </p>
                    <div className="text-[11px] text-slate-500">
                      Reported by: <span className="font-medium">{r.reportedBy}</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 shrink-0">
                    <button
                      onClick={() => onDismissReport(r.id)}
                      className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold"
                    >
                      Dismiss Report
                    </button>
                    <button
                      onClick={() => onDeleteDocument(r.documentId)}
                      className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold"
                    >
                      Remove Document
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 5: ANALYTICS & INSIGHTS */}
      {activeTab === 'analytics' && (
        <div className="space-y-6">
          {/* Key Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 font-medium block">Total Library Papers</span>
              <span className="text-2xl font-bold text-slate-900 mt-1 block">{stats.total}</span>
              <span className="text-[10px] text-emerald-600 font-bold block mt-1">
                {stats.approved} Verified & Published
              </span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 font-medium block">Pending Approvals</span>
              <span className="text-2xl font-bold text-amber-600 mt-1 block">{stats.pending}</span>
              <span className="text-[10px] text-slate-500 block mt-1">SLA: Under 24 hrs</span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 font-medium block">Total Student Downloads</span>
              <span className="text-2xl font-bold text-blue-600 mt-1 block">{stats.totalDownloads}</span>
              <span className="text-[10px] text-blue-500 block mt-1">~{stats.totalViews} Views</span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 font-medium block">Registered University Students</span>
              <span className="text-2xl font-bold text-purple-600 mt-1 block">{users.length}</span>
              <span className="text-[10px] text-purple-500 block mt-1">Across 8 KMCLU Faculties</span>
            </div>
          </div>

          {/* Breakdown Charts / Distribution */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Faculty & Department Resources
              </h3>
              <div className="space-y-2.5">
                {KMCLU_FACULTIES.map((fac) => {
                  const count = stats.facultyCounts[fac.id] || 0;
                  const pct = stats.approved > 0 ? Math.round((count / stats.approved) * 100) : 0;
                  return (
                    <div key={fac.id} className="space-y-1">
                      <div className="flex justify-between text-xs font-medium text-slate-700">
                        <span>{fac.name}</span>
                        <span className="font-bold">{count} papers ({pct}%)</span>
                      </div>
                      <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          style={{ width: `${Math.max(5, pct)}%` }}
                          className="h-full bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full"
                        ></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Document Type Breakdown
              </h3>
              <div className="space-y-3">
                {Object.entries(stats.typeCounts).map(([type, count]) => {
                  const pct = stats.approved > 0 ? Math.round((count / stats.approved) * 100) : 0;
                  return (
                    <div key={type} className="space-y-1">
                      <div className="flex justify-between text-xs font-medium text-slate-700">
                        <span>{type}</span>
                        <span className="font-bold">{count} items ({pct}%)</span>
                      </div>
                      <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          style={{ width: `${Math.max(5, pct)}%` }}
                          className={`h-full rounded-full ${
                            type === 'PYQ'
                              ? 'bg-indigo-600'
                              : type === 'Mid-Sem'
                              ? 'bg-amber-500'
                              : type === 'Notes'
                              ? 'bg-emerald-600'
                              : 'bg-purple-600'
                          }`}
                        ></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: AUDIT LOGS */}
      {activeTab === 'audit' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-800">
              Administrative Action Trail
            </h2>
            <span className="text-xs text-slate-500">
              Immutable ledger of all approval, rejection, and moderation decisions.
            </span>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200 uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="p-3">Timestamp</th>
                  <th className="p-3">Admin</th>
                  <th className="p-3">Action</th>
                  <th className="p-3">Target Document</th>
                  <th className="p-3">Reason / Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3 font-mono text-[11px] text-slate-500">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td className="p-3 font-semibold text-slate-800">
                      {log.adminName}
                    </td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          log.action.includes('APPROVE')
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {log.action}
                      </span>
                    </td>
                    <td className="p-3 font-medium text-slate-900 max-w-xs truncate">
                      {log.documentTitle}
                    </td>
                    <td className="p-3 text-slate-600 max-w-xs truncate">
                      {log.details}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Rejection Modal with Feedback Presets */}
      {rejectionModalOpen && rejectionDoc && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95">
            <div className="bg-rose-600 text-white p-4 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <AlertCircle className="w-5 h-5" />
                <h3 className="font-bold text-sm">Reject Submission</h3>
              </div>
              <button
                onClick={() => setRejectionModalOpen(false)}
                className="text-white/80 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div>
                <span className="text-slate-500 block mb-1">Document:</span>
                <span className="font-bold text-slate-800 block text-sm">
                  {rejectionDoc.title}
                </span>
                <span className="text-slate-500 text-[11px]">
                  Submitted by {rejectionDoc.uploadedBy.name}
                </span>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Select Rejection Reason Preset:
                </label>
                <select
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs text-slate-800 focus:bg-white focus:outline-hidden focus:border-rose-500 font-medium"
                >
                  <option value="Document scan is blurry or unreadable.">
                    Scan is blurry, low resolution, or illegible
                  </option>
                  <option value="Exact duplicate paper already exists in library.">
                    Duplicate: This paper already exists in the library
                  </option>
                  <option value="Incorrect subject or semester tag.">
                    Incorrect branch, semester, or course code mapping
                  </option>
                  <option value="Incomplete paper (missing pages or sections).">
                    Incomplete: Pages or questions are missing
                  </option>
                  <option value="Content does not align with KMCLU B.Tech syllabus.">
                    Out of syllabus / not official KMCLU academic material
                  </option>
                  <option value="Watermark or copyright restriction violated.">
                    Copyright / Third-party commercial watermark present
                  </option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Additional Note for Student (Optional):
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Please re-scan pages 2 & 3 in higher resolution and re-upload."
                  value={customRejectionText}
                  onChange={(e) => setCustomRejectionText(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs text-slate-800 focus:bg-white focus:outline-hidden focus:border-rose-500"
                />
              </div>

              <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-[11px]">
                The student will receive an in-app notification detailing this reason so they can correct and resubmit.
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  onClick={() => setRejectionModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmRejection}
                  className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold"
                >
                  Confirm & Send Rejection
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

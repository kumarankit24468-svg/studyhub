import React, { useState } from 'react';
import {
  User,
  Upload,
  Bookmark,
  CheckCircle2,
  Clock,
  XCircle,
  Eye,
  FileText,
  Award,
  AlertTriangle,
  Download,
  Share2,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { UserProfile } from '../data/mockData';
import { DocumentItem } from '../utils/studyhub-logic';

interface StudentDashboardProps {
  currentUser: UserProfile;
  documents: DocumentItem[];
  bookmarkedIds: string[];
  onToggleBookmark: (docId: string) => void;
  onPreviewDoc: (doc: DocumentItem) => void;
  onOpenUpload: () => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  currentUser,
  documents,
  bookmarkedIds,
  onToggleBookmark,
  onPreviewDoc,
  onOpenUpload,
}) => {
  const [activeTab, setActiveTab] = useState<'uploads' | 'bookmarks'>('uploads');

  // Documents uploaded by current user
  const myUploads = documents.filter((d) => d.uploadedBy.id === currentUser.id);
  const myApproved = myUploads.filter((d) => d.status === 'approved');
  const myPending = myUploads.filter((d) => d.status === 'pending');
  const myRejected = myUploads.filter((d) => d.status === 'rejected');

  // Bookmarked documents
  const bookmarkedDocs = documents.filter((d) => bookmarkedIds.includes(d.id));

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Student Profile Card */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
        <div className="flex items-center space-x-4">
          <img
            src={currentUser.avatar}
            alt={currentUser.name}
            className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover ring-4 ring-white/20 shadow-lg"
          />
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-xl sm:text-2xl font-bold">{currentUser.name}</h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400 text-slate-950">
                Verified Student
              </span>
            </div>
            <p className="text-xs text-blue-200 mt-0.5">
              {currentUser.course || 'Degree'} {currentUser.branch ? `(${currentUser.branch})` : ''} • {currentUser.facultyName || 'KMCLU'} {currentUser.semester > 0 ? `• Semester ${currentUser.semester}` : ''}
            </p>
            {currentUser.rollNo && (
              <p className="text-[11px] font-mono text-blue-300 mt-0.5">
                University Roll No: {currentUser.rollNo}
              </p>
            )}
          </div>
        </div>

        {/* Stats Pill */}
        <div className="flex items-center space-x-3 bg-white/10 rounded-xl p-3 border border-white/15 shrink-0">
          <div className="text-center px-3 border-r border-white/10">
            <span className="text-lg font-bold text-amber-300 block">{currentUser.reputationPoints}</span>
            <span className="text-[10px] text-slate-300 uppercase">Reputation</span>
          </div>
          <div className="text-center px-3 border-r border-white/10">
            <span className="text-lg font-bold text-emerald-300 block">{myApproved.length}</span>
            <span className="text-[10px] text-slate-300 uppercase">Approved</span>
          </div>
          <div className="text-center px-3">
            <span className="text-lg font-bold text-amber-300 block">{myPending.length}</span>
            <span className="text-[10px] text-slate-300 uppercase">Pending</span>
          </div>
        </div>
      </div>

      {/* Tabs: My Uploads vs Bookmarks */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-2">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setActiveTab('uploads')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'uploads'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>My Submitted PDFs ({myUploads.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('bookmarks')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
              activeTab === 'bookmarks'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <Bookmark className="w-4 h-4" />
            <span>Saved Bookmarks ({bookmarkedDocs.length})</span>
          </button>
        </div>

        <button
          onClick={onOpenUpload}
          className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg shadow-xs flex items-center gap-1.5 transition-colors"
        >
          <Upload className="w-3.5 h-3.5" />
          <span>Upload Another PDF</span>
        </button>
      </div>

      {/* TAB 1: MY UPLOADS */}
      {activeTab === 'uploads' && (
        <div className="space-y-4">
          {/* Status summary banner */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center space-x-3">
              <Clock className="w-5 h-5 text-amber-600 shrink-0" />
              <div>
                <span className="font-bold block">{myPending.length} Pending Review</span>
                <span className="text-[11px] text-amber-700">Waiting for Admin check</span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center space-x-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <div>
                <span className="font-bold block">{myApproved.length} Approved & Live</span>
                <span className="text-[11px] text-emerald-700">Visible to all students</span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 text-xs flex items-center space-x-3">
              <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
              <div>
                <span className="font-bold block">{myRejected.length} Rejected</span>
                <span className="text-[11px] text-rose-700">Reason provided below</span>
              </div>
            </div>
          </div>

          {/* Uploads List */}
          {myUploads.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
              <Upload className="w-10 h-10 text-slate-300 mx-auto" />
              <h3 className="text-base font-bold text-slate-800">You haven't uploaded any PDFs yet</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Share your previous year question papers or lecture notes with fellow KMCLU students and earn academic contributor reputation points.
              </p>
              <button
                onClick={onOpenUpload}
                className="px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700"
              >
                Upload Your First Document
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {myUploads.map((doc) => {
                const isPending = doc.status === 'pending';
                const isApproved = doc.status === 'approved';
                const isRejected = doc.status === 'rejected';

                return (
                  <div
                    key={doc.id}
                    className={`bg-white rounded-xl border p-4 sm:p-5 shadow-xs transition-all space-y-3 ${
                      isPending
                        ? 'border-amber-200 bg-amber-50/10'
                        : isApproved
                        ? 'border-emerald-200'
                        : 'border-rose-200 bg-rose-50/15'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center space-x-2">
                        {isPending && (
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1">
                            <Clock className="w-3 h-3 text-amber-600" />
                            Pending Admin Review
                          </span>
                        )}
                        {isApproved && (
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-300 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            Approved & Published
                          </span>
                        )}
                        {isRejected && (
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-900 border border-rose-300 flex items-center gap-1">
                            <XCircle className="w-3 h-3 text-rose-600" />
                            Rejected by Admin
                          </span>
                        )}

                        <span className="text-[10px] font-mono text-slate-500 font-medium">
                          {doc.subjectCode} • {doc.course || 'Degree'} {doc.branch ? `(${doc.branch})` : ''} • Sem {doc.semester}
                        </span>
                      </div>

                      <span className="text-[11px] text-slate-400">
                        Submitted: {new Date(doc.createdAt).toLocaleDateString()}
                      </span>
                    </div>

                    <div>
                      <h3 className="text-sm sm:text-base font-bold text-slate-900">
                        {doc.title}
                      </h3>
                      <p className="text-xs text-slate-600 mt-1 line-clamp-2">
                        {doc.contentSummary}
                      </p>
                    </div>

                    {/* Rejection Reason Alert Box if rejected */}
                    {isRejected && (
                      <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-900 space-y-1">
                        <div className="font-bold flex items-center gap-1.5 text-rose-800">
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                          Admin Rejection Feedback:
                        </div>
                        <p className="leading-relaxed">
                          {doc.reviewReason || 'The uploaded file was illegible or not aligned with the KMCLU syllabus.'}
                        </p>
                        <div className="pt-1 text-[11px] text-rose-700">
                          Tip: You can re-scan or verify details and re-upload anytime!
                        </div>
                      </div>
                    )}

                    {/* Approved details if live */}
                    {isApproved && (
                      <div className="flex items-center space-x-4 text-xs text-slate-500 pt-1">
                        <span>Reviewed by: <strong className="text-slate-700">{doc.reviewedBy}</strong></span>
                        <span>•</span>
                        <span>Downloads: <strong className="text-slate-700">{doc.downloads}</strong></span>
                        <span>•</span>
                        <span>Views: <strong className="text-slate-700">{doc.views}</strong></span>
                      </div>
                    )}

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-end space-x-2">
                      <button
                        onClick={() => onPreviewDoc(doc)}
                        className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Preview Document</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: BOOKMARKS */}
      {activeTab === 'bookmarks' && (
        <div className="space-y-4">
          {bookmarkedDocs.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-2">
              <Bookmark className="w-10 h-10 text-slate-300 mx-auto" />
              <h3 className="text-base font-bold text-slate-800">No Bookmarks Saved</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Click the bookmark icon on any PYQ or lecture note in the library to save it for offline revision!
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {bookmarkedDocs.map((doc) => (
                <div
                  key={doc.id}
                  className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs hover:shadow-md transition-all space-y-2.5 flex flex-col justify-between"
                >
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-start">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-700">
                        {doc.documentType} ({doc.examYear})
                      </span>
                      <button
                        onClick={() => onToggleBookmark(doc.id)}
                        className="text-amber-500 hover:text-slate-400 p-1"
                        title="Remove bookmark"
                      >
                        <Bookmark className="w-4 h-4 fill-current" />
                      </button>
                    </div>

                    <h4 className="text-xs sm:text-sm font-bold text-slate-900 leading-snug">
                      {doc.title}
                    </h4>
                    <p className="text-[11px] text-slate-500 line-clamp-2">
                      {doc.contentSummary}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="font-mono text-[10px] text-blue-600 font-semibold">
                      {doc.subjectCode} • Sem {doc.semester}
                    </span>
                    <button
                      onClick={() => onPreviewDoc(doc)}
                      className="px-2.5 py-1 rounded bg-blue-50 text-blue-700 font-bold hover:bg-blue-100 text-xs flex items-center gap-1"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Read</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

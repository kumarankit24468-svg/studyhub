import React, { useState } from 'react';
import {
  Sparkles,
  X,
  Send,
  BookOpen,
  Bot,
  User,
  Loader2,
  HelpCircle,
  Copy,
  Check,
  RefreshCw,
  FileText,
} from 'lucide-react';
import { DocumentItem } from '../utils/studyhub-logic';

interface AIAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeDocument?: DocumentItem | null;
}

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  source?: string;
  timestamp: string;
}

export const AIAssistantModal: React.FC<AIAssistantModalProps> = ({
  isOpen,
  onClose,
  activeDocument,
}) => {
  if (!isOpen) return null;

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [languageMode, setLanguageMode] = useState<'english' | 'hinglish'>('english');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome-1',
      sender: 'assistant',
      text: activeDocument
        ? `Hello! I am your **KMCLU StudyHub AI Mentor**. I am loaded with the context of: **${activeDocument.title}** (${activeDocument.subjectCode}).\n\nAsk me to solve any question from this paper, explain complex derivations, or prepare a 1-night revision roadmap in English or Hinglish!`
        : `Welcome to **KMCLU StudyHub AI Mentor**! I'm here to assist with your B.Tech CSE, AI&DS, and AI&ML coursework. Ask me about algorithms, mathematics derivations, university paper solutions, or exam tips!`,
      source: 'KMCLU AI Academic Engine',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const handleSend = async (overridePrompt?: string) => {
    const promptToSend = (overridePrompt || input).trim();
    if (!promptToSend || loading) return;

    const userMsg: Message = {
      id: 'msg_' + Date.now().toString(36),
      sender: 'user',
      text: promptToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!overridePrompt) setInput('');
    setLoading(true);

    try {
      const docContext = activeDocument
        ? `University: Khwaja Moinuddin Chishti Language University, Lucknow
Branch: B.Tech ${activeDocument.branch} (Semester ${activeDocument.semester})
Subject: ${activeDocument.subject} [Code: ${activeDocument.subjectCode}]
Paper Type: ${activeDocument.documentType} (${activeDocument.examYear})
Summary: ${activeDocument.contentSummary || ''}
Sample Questions: ${(activeDocument.sampleQuestions || []).join(' | ')}`
        : 'KMCLU B.Tech Engineering Curriculum';

      const res = await fetch('/api/gemini/study-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `${promptToSend} (Please answer in ${languageMode === 'hinglish' ? 'Hinglish - clean conversational Hindi/English mix' : 'clear professional English with structured university exam headings'})`,
          documentContext: docContext,
          mode: 'exam-solution',
        }),
      });

      const data = await res.json();
      const botMsg: Message = {
        id: 'msg_res_' + Date.now().toString(36),
        sender: 'assistant',
        text: data.text || 'No response returned from AI engine.',
        source: data.source || 'Gemini 3.8 Flash • KMCLU StudyHub',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch (err: any) {
      const errorMsg: Message = {
        id: 'msg_err_' + Date.now().toString(36),
        sender: 'assistant',
        text: `### 🎓 KMCLU Exam Preparation Guide\n\nFor **${promptToSend}**, structure your response for 10-mark questions:\n1. **Formal Definition & Objective**\n2. **System Architecture / Schematic Block Diagram**\n3. **Step-by-Step Algorithm or Proof**\n4. **Complexity Analysis & 2 Real Applications**`,
        source: 'KMCLU Offline Knowledge Base',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const quickPrompts = activeDocument
    ? [
        'Explain Question 1 (Banker algorithm / Deadlock) with solved example',
        'Provide full 10-mark answer structure for Section B',
        'Summarize key formulas and theorems in simple Hinglish',
        'What are the top 3 high-weightage questions from this subject?',
      ]
    : [
        'Explain Banker Algorithm with 3 resource types',
        'How to solve Belady Anomaly in FIFO with step diagram',
        'Explain Soft Margin SVM slack variable and hyperparameter C',
        'Give a 3-day revision plan for B.Tech End-Sem',
      ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl h-[650px] flex flex-col overflow-hidden animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-700 via-indigo-700 to-blue-700 text-white px-5 py-3.5 flex items-center justify-between">
          <div className="flex items-center space-x-3 truncate">
            <div className="p-2 rounded-xl bg-white/10 text-white shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="truncate">
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold truncate">KMCLU AI Study Mentor</h3>
                <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-white/20 text-white">
                  Gemini 3.8
                </span>
              </div>
              <p className="text-[11px] text-purple-200 truncate">
                {activeDocument ? `Active Context: ${activeDocument.subjectCode} - ${activeDocument.title}` : 'Universal B.Tech Engineering Helper'}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Language toggle */}
            <div className="bg-white/10 rounded-lg p-0.5 flex text-[10px] font-bold">
              <button
                onClick={() => setLanguageMode('english')}
                className={`px-2 py-0.5 rounded transition-colors ${
                  languageMode === 'english' ? 'bg-white text-purple-900' : 'text-white/80 hover:text-white'
                }`}
              >
                English
              </button>
              <button
                onClick={() => setLanguageMode('hinglish')}
                className={`px-2 py-0.5 rounded transition-colors ${
                  languageMode === 'hinglish' ? 'bg-white text-purple-900' : 'text-white/80 hover:text-white'
                }`}
              >
                Hinglish
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-1 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50/60">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex items-start space-x-2 ${
                m.sender === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              {m.sender === 'assistant' && (
                <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-purple-600 to-indigo-600 text-white flex items-center justify-center shrink-0 mt-0.5 text-xs shadow-xs">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl p-3.5 text-xs leading-relaxed shadow-xs ${
                  m.sender === 'user'
                    ? 'bg-blue-600 text-white rounded-tr-xs'
                    : 'bg-white text-slate-800 border border-slate-200 rounded-tl-xs'
                }`}
              >
                <div className="whitespace-pre-wrap font-sans">
                  {m.text}
                </div>
                {m.source && (
                  <div className="mt-2 pt-1 border-t border-slate-100 text-[10px] text-slate-400 flex items-center justify-between">
                    <span>{m.source}</span>
                    <span>{m.timestamp}</span>
                  </div>
                )}
              </div>

              {m.sender === 'user' && (
                <div className="w-7 h-7 rounded-lg bg-blue-700 text-white flex items-center justify-center shrink-0 mt-0.5 text-xs shadow-xs">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex items-center space-x-2 text-xs text-purple-700 bg-purple-50 p-3 rounded-xl border border-purple-200 w-fit">
              <Loader2 className="w-4 h-4 animate-spin text-purple-600" />
              <span>Analyzing KMCLU curriculum & generating solution...</span>
            </div>
          )}
        </div>

        {/* Quick Prompts Bar */}
        <div className="bg-white border-t border-slate-200 px-3 py-2 flex items-center space-x-2 overflow-x-auto text-[11px]">
          <span className="text-slate-400 font-semibold shrink-0">Suggestions:</span>
          {quickPrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(p)}
              className="px-2.5 py-1 rounded-full bg-slate-100 hover:bg-purple-50 hover:text-purple-700 border border-slate-200 shrink-0 text-slate-700 transition-colors"
            >
              {p}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-white border-t border-slate-200 flex items-center space-x-2">
          <input
            type="text"
            placeholder={
              activeDocument
                ? `Ask anything about ${activeDocument.subjectCode} (${activeDocument.subject})...`
                : 'Ask about any B.Tech topic, question or formula...'
            }
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSend();
            }}
            className="flex-1 bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-xs text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-hidden focus:border-purple-500"
          />
          <button
            onClick={() => handleSend()}
            disabled={!input.trim() || loading}
            className="px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 disabled:opacity-40 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 transition-all"
          >
            <span>Ask</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  Brain,
  Clock,
  CheckCircle2,
  XCircle,
  HelpCircle,
  RotateCcw,
  Award,
  ChevronRight,
  BookOpen,
  ArrowRight,
  AlertCircle,
} from 'lucide-react';
import { PRACTICE_QUIZ_QUESTIONS } from '../data/mockData';
import { calculateQuizScore, QuizQuestion } from '../utils/studyhub-logic';

export const PYQPracticeMode: React.FC = () => {
  const [selectedSubject, setSelectedSubject] = useState<string>('ALL');
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [showExplanations, setShowExplanations] = useState<boolean>(false);

  const subjects = ['ALL', 'Operating Systems', 'Data Structures & Algorithms', 'Machine Learning', 'Database Management Systems'];

  const filteredQuestions = PRACTICE_QUIZ_QUESTIONS.filter((q) => {
    if (selectedSubject === 'ALL') return true;
    return q.subject === selectedSubject;
  });

  const handleSelectOption = (questionId: string, optionIdx: number) => {
    if (isSubmitted) return;
    setAnswers((prev) => ({
      ...prev,
      [questionId]: optionIdx,
    }));
  };

  const handleReset = () => {
    setAnswers({});
    setIsSubmitted(false);
    setShowExplanations(false);
  };

  const scoreResults = calculateQuizScore(filteredQuestions, answers);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-purple-800 via-indigo-900 to-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="bg-purple-400 text-purple-950 font-bold px-2 py-0.5 rounded text-[11px] uppercase tracking-wide">
              KMCLU Exam Mode
            </span>
            <span className="text-xs text-purple-200">B.Tech Engineering Objective Prep</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold mt-1 text-white">
            PYQ Practice Test & Knowledge Check
          </h1>
          <p className="text-xs text-purple-200 mt-1 max-w-xl">
            Practice actual university Section A multiple-choice questions curated from recent KMCLU End-Sem and Mid-Sem papers.
          </p>
        </div>

        <div className="flex items-center space-x-2 bg-white/10 p-3 rounded-xl border border-white/10 shrink-0">
          <Clock className="w-5 h-5 text-purple-300" />
          <div className="text-xs">
            <span className="block font-bold text-white">Standard Exam Mode</span>
            <span className="text-[11px] text-purple-200">{filteredQuestions.length} Questions</span>
          </div>
        </div>
      </div>

      {/* Subject Filter Bar */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-2">
        <span className="text-xs text-slate-500 font-bold shrink-0">Subject Filter:</span>
        {subjects.map((sub) => (
          <button
            key={sub}
            onClick={() => {
              setSelectedSubject(sub);
              handleReset();
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition-colors ${
              selectedSubject === sub
                ? 'bg-purple-600 text-white shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {sub}
          </button>
        ))}
      </div>

      {/* Quiz Questions List */}
      <div className="space-y-4">
        {filteredQuestions.map((q, index) => {
          const selectedIdx = answers[q.id];
          const isCorrect = selectedIdx === q.correctOptionIndex;

          return (
            <div
              key={q.id}
              className={`bg-white rounded-2xl border p-5 sm:p-6 shadow-xs transition-all ${
                isSubmitted
                  ? isCorrect
                    ? 'border-emerald-300 bg-emerald-50/20'
                    : 'border-rose-300 bg-rose-50/20'
                  : 'border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                  Question {index + 1} of {filteredQuestions.length} • {q.subject}
                </span>
                <span className="text-[11px] text-slate-400 capitalize">
                  Topic: {q.topic}
                </span>
              </div>

              <h3 className="text-sm sm:text-base font-bold text-slate-900 leading-snug mb-4">
                {q.question}
              </h3>

              {/* Options */}
              <div className="space-y-2">
                {q.options.map((option, optIdx) => {
                  let optStyle = 'border-slate-200 hover:border-slate-300 bg-slate-50/60 text-slate-700';

                  if (isSubmitted) {
                    if (optIdx === q.correctOptionIndex) {
                      optStyle = 'border-emerald-500 bg-emerald-100 text-emerald-950 font-bold';
                    } else if (selectedIdx === optIdx) {
                      optStyle = 'border-rose-500 bg-rose-100 text-rose-950 font-bold';
                    } else {
                      optStyle = 'border-slate-200 opacity-60 text-slate-500';
                    }
                  } else if (selectedIdx === optIdx) {
                    optStyle = 'border-purple-600 bg-purple-50 text-purple-900 font-bold shadow-xs';
                  }

                  return (
                    <button
                      key={optIdx}
                      disabled={isSubmitted}
                      onClick={() => handleSelectOption(q.id, optIdx)}
                      className={`w-full text-left p-3 rounded-xl border text-xs sm:text-sm transition-all flex items-center justify-between ${optStyle}`}
                    >
                      <div className="flex items-center space-x-3">
                        <span className="w-6 h-6 rounded-lg bg-white border border-slate-300 flex items-center justify-center font-bold text-xs text-slate-700 shrink-0">
                          {String.fromCharCode(65 + optIdx)}
                        </span>
                        <span>{option}</span>
                      </div>

                      {isSubmitted && optIdx === q.correctOptionIndex && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      )}
                      {isSubmitted && selectedIdx === optIdx && optIdx !== q.correctOptionIndex && (
                        <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Explanation after submission */}
              {isSubmitted && (
                <div className="mt-4 p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 space-y-1">
                  <div className="font-bold flex items-center gap-1.5 text-slate-900">
                    <HelpCircle className="w-3.5 h-3.5 text-purple-600" />
                    University Curriculum Explanation:
                  </div>
                  <p className="leading-relaxed">{q.explanation}</p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Quiz Bottom Controls */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-6 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        {!isSubmitted ? (
          <div className="w-full flex items-center justify-between">
            <span className="text-xs text-slate-600">
              Answered: <span className="font-bold text-slate-900">{Object.keys(answers).length}</span> of {filteredQuestions.length}
            </span>

            <button
              onClick={() => setIsSubmitted(true)}
              disabled={Object.keys(answers).length === 0}
              className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:opacity-40 text-white font-bold text-xs shadow-md transition-all flex items-center gap-2"
            >
              <span>Submit Practice Test</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="w-full space-y-4">
            {/* Scorecard banner */}
            <div className="p-4 rounded-xl bg-purple-50 border border-purple-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center space-x-3">
                <div className="p-3 rounded-xl bg-purple-600 text-white shadow-xs">
                  <Award className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-base font-bold text-purple-950">
                    Score: {scoreResults.correct} / {scoreResults.total} ({scoreResults.percentage}%)
                  </div>
                  <div className="text-xs text-purple-700">
                    KMCLU Grade Classification: <span className="font-bold">{scoreResults.grade}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">{scoreResults.remark}</p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={handleReset}
                  className="px-4 py-2 rounded-xl bg-white border border-purple-300 text-purple-700 text-xs font-bold hover:bg-purple-50 flex items-center gap-1.5"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Retake Test</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

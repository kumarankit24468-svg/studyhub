import React, { useState } from 'react';
import {
  X,
  Download,
  ZoomIn,
  ZoomOut,
  RotateCw,
  Bookmark,
  Share2,
  Sparkles,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  FileText,
  Search,
  CheckCircle,
  Eye,
  Printer,
  BookOpen,
} from 'lucide-react';
import { DocumentItem } from '../utils/studyhub-logic';

interface PDFViewerModalProps {
  document: DocumentItem | null;
  onClose: () => void;
  isBookmarked: boolean;
  onToggleBookmark: (docId: string) => void;
  onAskAI: (doc: DocumentItem) => void;
  onReport: (doc: DocumentItem) => void;
  onDownload: (doc: DocumentItem) => void;
}

export const PDFViewerModal: React.FC<PDFViewerModalProps> = ({
  document,
  onClose,
  isBookmarked,
  onToggleBookmark,
  onAskAI,
  onReport,
  onDownload,
}) => {
  if (!document) return null;

  const [zoomLevel, setZoomLevel] = useState(100);
  const [currentPage, setCurrentPage] = useState(1);
  const totalPages = document.pageCount || 3;
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [readerTheme, setReaderTheme] = useState<'paper' | 'sepia' | 'dark'>('paper');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);

  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const getThemeClass = () => {
    if (readerTheme === 'dark') return 'bg-slate-900 text-slate-100 border-slate-700';
    if (readerTheme === 'sepia') return 'bg-[#fbf0d9] text-[#433422] border-[#e8d5b5]';
    return 'bg-white text-slate-900 border-slate-200';
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
      <div
        className={`w-full max-w-5xl rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-slate-700 transition-all ${
          isFullscreen ? 'fixed inset-0 max-w-none rounded-none' : 'max-h-[92vh] h-[850px]'
        } bg-slate-900`}
      >
        {/* Top Control Bar */}
        <div className="bg-slate-900 text-white px-4 py-3 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center space-x-3 truncate">
            <div className="p-1.5 rounded-lg bg-blue-600/30 text-blue-400">
              <FileText className="w-5 h-5" />
            </div>
            <div className="truncate">
              <h2 className="text-sm font-bold text-white truncate max-w-md">
                {document.title}
              </h2>
              <div className="flex items-center space-x-2 text-xs text-slate-400">
                <span className="font-mono text-blue-400 font-semibold">
                  {document.subjectCode}
                </span>
                <span>•</span>
                <span>B.Tech {document.branch}</span>
                <span>•</span>
                <span>Semester {document.semester}</span>
                <span>•</span>
                <span>{document.documentType} ({document.examYear})</span>
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center space-x-1.5 sm:space-x-2">
            {/* Ask AI button */}
            <button
              onClick={() => onAskAI(document)}
              className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md transition-transform active:scale-95"
              title="Explain questions or solve with AI"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Ask AI Mentor</span>
            </button>

            {/* Bookmark button */}
            <button
              onClick={() => onToggleBookmark(document.id)}
              className={`p-1.5 rounded-lg text-xs font-medium transition-colors ${
                isBookmarked
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
              title={isBookmarked ? 'Remove Bookmark' : 'Save to Bookmarks'}
            >
              <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
            </button>

            {/* Download */}
            <button
              onClick={() => onDownload(document)}
              className="px-2.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1 transition-colors"
              title="Download Document"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Download</span>
            </button>

            {/* Share */}
            <button
              onClick={handleShare}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title="Share Link"
            >
              <Share2 className="w-4 h-4" />
            </button>

            {/* Report */}
            <button
              onClick={() => onReport(document)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
              title="Report issue with PDF"
            >
              <AlertTriangle className="w-4 h-4" />
            </button>

            {/* Fullscreen */}
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors hidden sm:block"
              title="Toggle Fullscreen"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            {/* Close */}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors ml-1"
              title="Close Viewer (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Secondary Toolbar: Zoom, Page Navigation, Themes */}
        <div className="bg-slate-850 px-4 py-2 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-300">
          <div className="flex items-center space-x-2">
            {/* Page navigation */}
            <div className="flex items-center bg-slate-800 rounded-lg p-0.5 border border-slate-700">
              <button
                disabled={currentPage <= 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                className="p-1 text-slate-300 hover:text-white disabled:opacity-30"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="px-2 font-mono text-slate-200">
                Page {currentPage} of {totalPages}
              </span>
              <button
                disabled={currentPage >= totalPages}
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                className="p-1 text-slate-300 hover:text-white disabled:opacity-30"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Zoom Controls */}
            <div className="flex items-center bg-slate-800 rounded-lg p-0.5 border border-slate-700">
              <button
                onClick={() => setZoomLevel((z) => Math.max(75, z - 15))}
                className="p-1 text-slate-300 hover:text-white"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="px-2 font-mono text-slate-300">{zoomLevel}%</span>
              <button
                onClick={() => setZoomLevel((z) => Math.min(150, z + 15))}
                className="p-1 text-slate-300 hover:text-white"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                onClick={() => setZoomLevel(100)}
                className="p-1 text-slate-300 hover:text-white"
                title="Reset Zoom"
              >
                <RotateCw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Theme & Search */}
          <div className="flex items-center space-x-3">
            {/* Quick Find In Document */}
            <div className="relative hidden sm:block">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-2 text-slate-400" />
              <input
                type="text"
                placeholder="Find in document..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-slate-800 border border-slate-700 rounded-lg pl-8 pr-2.5 py-1 text-xs text-slate-200 placeholder-slate-400 focus:outline-hidden focus:border-blue-500 w-44"
              />
            </div>

            {/* Reading Modes */}
            <div className="flex items-center space-x-1 bg-slate-800 rounded-lg p-0.5 border border-slate-700">
              <button
                onClick={() => setReaderTheme('paper')}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                  readerTheme === 'paper' ? 'bg-white text-slate-900 font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                Paper
              </button>
              <button
                onClick={() => setReaderTheme('sepia')}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                  readerTheme === 'sepia' ? 'bg-[#fbf0d9] text-[#433422] font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                Sepia
              </button>
              <button
                onClick={() => setReaderTheme('dark')}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                  readerTheme === 'dark' ? 'bg-slate-700 text-white font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                Dark
              </button>
            </div>
          </div>
        </div>

        {/* Document Reading Canvas */}
        <div className="flex-1 overflow-auto p-4 sm:p-8 flex justify-center bg-slate-950/60">
          <div
            style={{ transform: `scale(${zoomLevel / 100})`, transformOrigin: 'top center' }}
            className={`w-full max-w-3xl min-h-[900px] rounded-xl shadow-2xl p-8 sm:p-12 border transition-all ${getThemeClass()}`}
          >
            {/* Realistic KMCLU University Paper Header */}
            <div className="text-center border-b-2 border-slate-900 pb-4 mb-6">
              <div className="font-serif tracking-wide text-xs sm:text-sm font-semibold uppercase text-slate-700">
                Printed Pages: {totalPages} | Paper Id: [{document.subjectCode}]
              </div>
              <h1 className="text-lg sm:text-2xl font-bold font-serif tracking-tight mt-1 text-slate-950">
                KHWAJA MOINUDDIN CHISHTI LANGUAGE UNIVERSITY, LUCKNOW
              </h1>
              <p className="text-xs sm:text-sm font-serif font-medium mt-0.5 text-slate-800">
                {document.facultyName || 'University Academic Department'} • {document.department ? `Department of ${document.department}` : ''}
              </p>
              <p className="text-xs sm:text-sm font-serif font-bold uppercase mt-1 tracking-wider text-slate-900">
                {document.course || 'Degree Program'} ({document.branch}) • Semester {document.semester} Examination {document.examYear}
              </p>
              <div className="text-sm font-bold underline font-serif mt-1">
                {document.subject.toUpperCase()} [{document.subjectCode}]
              </div>

              <div className="flex justify-between items-center text-xs font-serif font-bold mt-4 pt-2 border-t border-slate-400">
                <span>Time: {document.documentType === 'Mid-Sem' ? '1.5 Hours' : '3 Hours'}</span>
                <span>Total Marks: {document.documentType === 'Mid-Sem' ? '30' : '70'}</span>
              </div>
            </div>

            {/* Instruction Banner */}
            <div className="text-xs font-serif italic mb-6 text-slate-700 border-b border-dashed border-slate-300 pb-2">
              Note: 1. Attempt all sections. If any data is missing, assume suitably.<br />
              2. Use of scientific non-programmable calculator is permitted.
            </div>

            {/* Paper Content: Multi-Page Display / Simulated Sections */}
            {currentPage === 1 && (
              <div className="space-y-6 font-serif">
                {/* SECTION A */}
                <div>
                  <div className="flex justify-between items-center font-bold text-sm bg-slate-100 p-1.5 border border-slate-300 rounded mb-3">
                    <span>SECTION A (Compulsory Short Answer Questions)</span>
                    <span>[{document.documentType === 'Mid-Sem' ? '5 x 2 = 10' : '10 x 2 = 20 Marks'}]</span>
                  </div>
                  <div className="space-y-3 pl-2 text-sm leading-relaxed">
                    <div className="flex items-start gap-2">
                      <span className="font-bold">1.(a)</span>
                      <div>
                        {document.sampleQuestions?.[0] || 'Define the fundamental objective and design trade-offs of this course.'}
                        <span className="float-right font-bold text-xs">[2]</span>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="font-bold">1.(b)</span>
                      <div>
                        {document.sampleQuestions?.[1] || 'State the essential mathematical assumptions or theorem statements governing this topic.'}
                        <span className="float-right font-bold text-xs">[2]</span>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="font-bold">1.(c)</span>
                      <div>
                        Differentiate between synchronous and asynchronous operation with an engineering example.
                        <span className="float-right font-bold text-xs">[2]</span>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="font-bold">1.(d)</span>
                      <div>
                        Explain the role of time and space complexity in evaluating optimal algorithm efficiency.
                        <span className="float-right font-bold text-xs">[2]</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* SECTION B */}
                <div className="pt-4 border-t border-slate-300">
                  <div className="flex justify-between items-center font-bold text-sm bg-slate-100 p-1.5 border border-slate-300 rounded mb-3">
                    <span>SECTION B (Analytical & Problem-Solving Questions)</span>
                    <span>[{document.documentType === 'Mid-Sem' ? '2 x 10 = 20' : '3 x 10 = 30 Marks'}]</span>
                  </div>
                  <div className="space-y-4 pl-2 text-sm leading-relaxed">
                    <div className="flex items-start gap-2">
                      <span className="font-bold">2.</span>
                      <div>
                        {document.sampleQuestions?.[2] || 'Derive the mathematical formulation and provide the step-by-step algorithm with an illustrative example.'}
                        <span className="float-right font-bold text-xs">[10]</span>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="font-bold">3.</span>
                      <div>
                        {document.sampleQuestions?.[3] || 'Compare the advantages, bottlenecks, and real-world industrial implementations of the given techniques.'}
                        <span className="float-right font-bold text-xs">[10]</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentPage === 2 && (
              <div className="space-y-6 font-serif">
                {/* SECTION C */}
                <div>
                  <div className="flex justify-between items-center font-bold text-sm bg-slate-100 p-1.5 border border-slate-300 rounded mb-3">
                    <span>SECTION C (Design, Implementation & Case Studies)</span>
                    <span>[2 x 10 = 20 Marks]</span>
                  </div>
                  <div className="space-y-4 pl-2 text-sm leading-relaxed">
                    <div className="flex items-start gap-2">
                      <span className="font-bold">4.</span>
                      <div>
                        {document.sampleQuestions?.[4] || 'Design a comprehensive system architecture diagram for the given scenario and formulate the state-transition matrix.'}
                        <span className="float-right font-bold text-xs">[10]</span>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="font-bold">5.</span>
                      <div>
                        Explain the error recovery, fault tolerance, and optimization heuristics utilized in modern large-scale computing environments.
                        <span className="float-right font-bold text-xs">[10]</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Content Summary & Key Notes */}
                <div className="mt-8 p-4 rounded-lg bg-blue-50/70 border border-blue-200 text-xs font-sans text-blue-900">
                  <div className="font-bold flex items-center gap-1.5 text-blue-800 mb-1">
                    <CheckCircle className="w-4 h-4 text-emerald-600" />
                    Verified KMCLU StudyHub Quality Review
                  </div>
                  <p className="leading-relaxed text-slate-700">
                    {document.contentSummary || 'This document has undergone administrative check for legibility, syllabus alignment, and duplicate prevention. Suitable for end-semester revision.'}
                  </p>
                </div>
              </div>
            )}

            {currentPage >= 3 && (
              <div className="space-y-6 font-serif">
                <div className="text-center py-8">
                  <h3 className="text-base font-bold font-sans text-slate-800">
                    Syllabus Mapping & Reference Recommendations
                  </h3>
                  <p className="text-xs text-slate-500 font-sans mt-1">
                    Prescribed textbooks & learning resources according to KMCLU FET Ordinance
                  </p>
                </div>

                <div className="space-y-3 font-sans text-xs">
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                    <span className="font-bold text-slate-800">Unit Coverage:</span> All 5 Units covered as per Board of Studies CBCS scheme.
                  </div>
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                    <span className="font-bold text-slate-800">Uploader Acknowledgement:</span> Submitted by {document.uploadedBy.name} ({document.uploadedBy.rollNo || 'KMCLU Student Contributor'}).
                  </div>
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                    <span className="font-bold text-slate-800">AI Assistant Prompt Tip:</span> Click the "Ask AI Mentor" button above to get step-by-step solved derivations for any question in this paper!
                  </div>
                </div>
              </div>
            )}

            {/* Footer page stamp */}
            <div className="mt-12 pt-4 border-t border-slate-300 text-center text-xs font-serif text-slate-500">
              --- Page {currentPage} of {totalPages} • KMCLU StudyHub Academic Repository ---
            </div>
          </div>
        </div>

        {/* Bottom Status bar */}
        <div className="bg-slate-900 border-t border-slate-800 px-4 py-2.5 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center space-x-3">
            <span className="flex items-center gap-1 text-emerald-400 font-medium">
              <CheckCircle className="w-3.5 h-3.5" />
              Verified by: {document.reviewedBy || 'Academic Dean Office'}
            </span>
            <span className="hidden sm:inline">•</span>
            <span className="hidden sm:inline">Views: {document.views}</span>
            <span className="hidden sm:inline">•</span>
            <span className="hidden sm:inline">Downloads: {document.downloads}</span>
          </div>

          <div className="flex items-center space-x-2">
            {copiedLink && (
              <span className="text-emerald-400 font-semibold animate-pulse">
                Link copied to clipboard!
              </span>
            )}
            <button
              onClick={() => onAskAI(document)}
              className="text-purple-400 hover:text-purple-300 font-semibold flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Solve with AI
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

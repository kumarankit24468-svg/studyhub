import React, { useEffect, useState } from 'react';
import { Users, History, RefreshCw, ShieldCheck, Clock3 } from 'lucide-react';

type UserRow = { id: string; name: string; email: string; role: 'student' | 'admin'; createdAt: string; lastLoginAt?: string; isSuspended: boolean; department?: string; branch?: string };
type LoginEvent = { id: string; userId: string; email: string; role: 'student' | 'admin'; timestamp: string; ip: string };
const dateText = (value?: string) => value ? new Date(value).toLocaleString() : 'Never';

export const AdminSecurityPanel: React.FC = () => {
  const [users, setUsers] = useState<UserRow[]>([]);
  const [events, setEvents] = useState<LoginEvent[]>([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState('');
  const load = async () => {
    setLoading(true); setError('');
    try {
      const [u, l] = await Promise.all([
        fetch('/api/admin/users', { credentials: 'same-origin' }),
        fetch('/api/admin/login-activity', { credentials: 'same-origin' }),
      ]);
      if (!u.ok || !l.ok) throw new Error('Admin permission could not be verified. Please sign in again.');
      const ud = await u.json(); const ld = await l.json(); setUsers(ud.users || []); setEvents(ld.events || []);
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not load admin data.'); }
    finally { setLoading(false); }
  };
  useEffect(() => { void load(); }, []);
  const toggleSuspend = async (user: UserRow) => {
    setBusyId(user.id); setError('');
    try {
      const response = await fetch(`/api/admin/users/${encodeURIComponent(user.id)}/suspend`, { method: 'POST', credentials: 'same-origin' });
      const data = await response.json(); if (!response.ok) throw new Error(data.error || 'Action failed.');
      setUsers(prev => prev.map(u => u.id === user.id ? data.user : u));
    } catch (e) { setError(e instanceof Error ? e.message : 'Action failed.'); }
    finally { setBusyId(''); }
  };
  return <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 space-y-5">
    <div className="flex flex-wrap items-center justify-between gap-3"><div><div className="flex items-center gap-2 text-slate-900"><ShieldCheck className="h-5 w-5 text-emerald-600"/><h2 className="text-xl font-extrabold">Private Admin Security</h2></div><p className="mt-1 text-sm text-slate-500">Registered accounts and recorded successful logins. This section is served by admin-protected API endpoints.</p></div><button onClick={() => void load()} className="inline-flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2 text-sm font-semibold hover:bg-slate-50"><RefreshCw className="h-4 w-4"/> Refresh</button></div>
    {error && <div role="alert" className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">{error}</div>}
    {loading ? <p className="rounded-xl bg-slate-50 p-5 text-sm text-slate-500">Loading secure admin data…</p> : <div className="grid gap-5 lg:grid-cols-2">
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white"><div className="flex items-center gap-2 border-b border-slate-100 p-4"><Users className="h-5 w-5 text-blue-600"/><h3 className="font-bold text-slate-900">Registered users ({users.length})</h3></div><div className="max-h-[440px] overflow-auto divide-y divide-slate-100">{users.map(u => <div key={u.id} className="flex items-center justify-between gap-3 p-4"><div className="min-w-0"><div className="truncate text-sm font-bold text-slate-900">{u.name} <span className={`ml-1 rounded-full px-2 py-0.5 text-[10px] ${u.role === 'admin' ? 'bg-amber-100 text-amber-800' : 'bg-blue-50 text-blue-700'}`}>{u.role}</span></div><div className="truncate text-xs text-slate-500">{u.email}</div><div className="mt-1 text-[11px] text-slate-400">Created: {dateText(u.createdAt)} · Last login: {dateText(u.lastLoginAt)}</div></div>{u.role === 'student' && <button disabled={busyId === u.id} onClick={() => void toggleSuspend(u)} className={`shrink-0 rounded-lg px-3 py-1.5 text-xs font-bold disabled:opacity-50 ${u.isSuspended ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'}`}>{busyId === u.id ? 'Wait…' : u.isSuspended ? 'Unsuspend' : 'Suspend'}</button>}</div>)}{users.length === 0 && <p className="p-4 text-sm text-slate-500">No registered accounts yet.</p>}</div></div>
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white"><div className="flex items-center gap-2 border-b border-slate-100 p-4"><History className="h-5 w-5 text-purple-600"/><h3 className="font-bold text-slate-900">Recent successful logins ({events.length})</h3></div><div className="max-h-[440px] overflow-auto divide-y divide-slate-100">{events.map(e => <div key={e.id} className="p-4"><div className="flex items-center gap-2 text-sm font-bold text-slate-900"><span className="truncate">{e.email}</span><span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px]">{e.role}</span></div><div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500"><span className="inline-flex items-center gap-1"><Clock3 className="h-3.5 w-3.5"/>{dateText(e.timestamp)}</span><span>IP: {e.ip}</span></div></div>)}{events.length === 0 && <p className="p-4 text-sm text-slate-500">No successful logins recorded yet.</p>}</div></div>
    </div>}
    <p className="text-xs leading-5 text-slate-400">Privacy note: IP addresses are included for security auditing. In a public deployment, configure trusted proxy handling and a retention policy appropriate for your institution.</p>
  </section>;
};
